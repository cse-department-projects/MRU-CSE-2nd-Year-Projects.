@echo off
title Trinetra AI — Sentinel Grid Launcher
echo.
echo  ████████╗██████╗ ██╗███╗   ██╗███████╗████████╗██████╗  █████╗      █████╗ ██╗
echo  ╚══██╔══╝██╔══██╗██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██╔══██╗    ██╔══██╗██║
echo     ██║   ██████╔╝██║██╔██╗ ██║█████╗     ██║   ██████╔╝███████║    ███████║██║
echo     ██║   ██╔══██╗██║██║╚██╗██║██╔══╝     ██║   ██╔══██╗██╔══██║    ██╔══██║██║
echo     ██║   ██║  ██║██║██║ ╚████║███████╗   ██║   ██║  ██║██║  ██║    ██║  ██║██║
echo     ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝
echo.
echo  Initializing Trinetra AI Full Stack Services...
echo.

:: ── First-run checks ─────────────────────────────────────────────────────────
if not exist "%~dp0backend-express\.env" (
  echo  [setup] No backend-express\.env found - creating one with fresh random secrets...
  node "%~dp0backend-express\scripts\init-env.js"
  echo.
  echo  ============================================================
  echo   ACTION NEEDED: open backend-express\.env and set DB_PASSWORD
  echo   to YOUR MySQL password, then run start.bat again.
  echo  ============================================================
  pause
  exit /b 1
)
if not exist "%~dp0backend-express\node_modules" (
  echo  [setup] Installing Express backend dependencies...
  pushd "%~dp0backend-express"
  call npm install
  popd
)
if not exist "%~dp0frontend\node_modules" (
  echo  [setup] Installing frontend dependencies...
  pushd "%~dp0frontend"
  call npm install
  popd
)
python -c "import fastapi, uvicorn, cv2, numpy, dotenv" 2>nul
if errorlevel 1 (
  echo  [setup] Installing Python dependencies for the CV engine...
  python -m pip install -r "%~dp0backend\requirements.txt"
)

:: ── Window 1: Express + MySQL Backend (Port 8000) ────────────────────────────
echo  [1/3] Starting Express.js + MySQL Backend + real-time alerts on port 8000...
start "Trinetra Express Backend [port 8000]" cmd /k "cd /d %~dp0backend-express && node server.js"

:: Wait for Express server to connect to MySQL and bind port 8000
timeout /t 3 /nobreak > nul

:: ── Window 2: Computer Vision & RTSP Engine (Port 8001) ──────────────────────
echo  [2/3] Starting Python CV & RTSP Engine on port 8001 (localhost only)...
start "Trinetra CV Engine [port 8001]" cmd /k "cd /d %~dp0backend && python -m uvicorn cv_main:app --host 127.0.0.1 --port 8001 --workers 1"

:: Wait a moment before starting frontend
timeout /t 2 /nobreak > nul

:: ── Window 3: React Frontend (Port 5173) ─────────────────────────────────────
echo  [3/3] Starting React Dashboard Frontend on port 5173...
start "Trinetra Frontend [port 5173]" cmd /k "cd /d %~dp0frontend && npm run dev"

:: Wait for Vite dev server to spin up, then launch default browser
timeout /t 3 /nobreak > nul
start http://localhost:5173

echo.
echo  ============================================================
echo   ALL TRINETRA AI SERVICES ARE RUNNING!
echo  ============================================================
echo   - Express Backend (MySQL) : http://localhost:8000
echo   - CV & RTSP Engine        : http://localhost:8001
echo   - React Web Dashboard     : http://localhost:5173
echo.
echo   Browser opened automatically to http://localhost:5173
echo.
echo   (Keep the 3 opened terminal windows running in the background)
echo  ============================================================
echo.
pause
