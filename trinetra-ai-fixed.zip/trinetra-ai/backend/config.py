"""
config.py — settings shared with the Express backend.

The CV engine and Express need the same INTERNAL_API_KEY, so both read
``backend-express/.env`` (created by ``npm run init-env``). Values may also be
provided as real environment variables, which take priority. An optional
``backend/.env`` overrides the shared file.

Only a whitelist of keys is read from those files — the MySQL password and the
JWT secret never enter this process.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import dotenv_values

_HERE = Path(__file__).resolve().parent
_EXPRESS_ENV = _HERE.parent / "backend-express" / ".env"
_LOCAL_ENV = _HERE / ".env"

_WHITELIST = {
    "INTERNAL_API_KEY",
    "SIMULATE_DETECTIONS",
    "ALERT_COOLDOWN_SECONDS",
    "EXPRESS_URL",
    "CV_CORS_ORIGINS",
}


def _read_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    return {k: v for k, v in dotenv_values(path).items() if v is not None}


_express_file = _read_file(_EXPRESS_ENV)
_file_values: dict[str, str] = {
    k: v for k, v in {**_express_file, **_read_file(_LOCAL_ENV)}.items() if k in _WHITELIST
}


def _get(name: str, default: str = "") -> str:
    return os.environ.get(name) or _file_values.get(name) or default


def _truthy(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


# Shared secret for server-to-server calls (Express <-> CV engine).
INTERNAL_API_KEY: str = _get("INTERNAL_API_KEY")

# Where to POST detections. Defaults to Express on the PORT in its own .env.
EXPRESS_URL: str = _get(
    "EXPRESS_URL", f"http://127.0.0.1:{_express_file.get('PORT', '8000')}"
).rstrip("/")

# Seconds between two forwarded alerts for the same camera.
try:
    ALERT_COOLDOWN_SECONDS: float = max(0.0, float(_get("ALERT_COOLDOWN_SECONDS", "60")))
except ValueError:
    ALERT_COOLDOWN_SECONDS = 60.0

# DEMO ONLY. No real model ships with this project; when True the placeholder
# classifier fabricates random hazards from motion. Default: off.
SIMULATE_DETECTIONS: bool = _truthy(_get("SIMULATE_DETECTIONS", "false"))

# Browsers should never call this service directly (Express does), so no
# cross-origin access is granted unless explicitly configured.
CV_CORS_ORIGINS: list[str] = [o.strip() for o in _get("CV_CORS_ORIGINS").split(",") if o.strip()]
