"""
cv_inference.py — Real-time computer vision inference pipeline.

Architecture:
  - Processes frames from an RTSPCapture queue in a background thread
  - Stage 1: Motion detection via frame-differencing (lightweight, always on)
  - Stage 2: Hazard classification (pluggable — swap in YOLO/TFLite/ONNX here)
  - Produces annotated JPEG frames + structured JSON events
  - Publishes the latest result (+ sequence number) for any number of readers

Plugging in a real model:
  - Replace `_classify_hazard()` with your ONNX/TFLite inference call
  - The rest of the pipeline (threading, queuing, annotation) stays unchanged
"""

from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Callable

import cv2
import numpy as np

import config

logger = logging.getLogger("trinetra.cv")


# ─────────────────────────────────────────────────────────────────────────────
# Types
# ─────────────────────────────────────────────────────────────────────────────

class HazardType(str, Enum):
    FIRE       = "fire"
    SMOKE      = "smoke"
    INTRUSION  = "intrusion"
    FALL       = "fall"
    CROWD      = "crowd_surge"
    NONE       = "none"


@dataclass
class InferenceResult:
    """
    Single-frame inference output consumed by the WebSocket router.

    Fields:
        camera_id:      Source camera identifier
        timestamp:      Unix epoch (seconds) when the frame was processed
        hazard:         Detected hazard type (HazardType.NONE if clear)
        confidence:     Model confidence score [0.0 – 1.0]
        motion_score:   Pixel-change ratio from frame-differencing [0.0 – 1.0]
        bbox:           Bounding box [x, y, w, h] in pixel coordinates, or None
        frame_jpeg:     JPEG-encoded annotated frame (bytes), or None if disabled
        alert:          True when confidence exceeds the detection threshold
    """
    camera_id: int
    timestamp: float
    hazard: HazardType = HazardType.NONE
    confidence: float = 0.0
    motion_score: float = 0.0
    bbox: Optional[list[int]] = None
    frame_jpeg: Optional[bytes] = None
    alert: bool = False

    def to_event_dict(self) -> dict:
        """JSON-serialisable dict for WebSocket event emission (no binary frame data)."""
        return {
            "event":        "INFERENCE_RESULT",
            "camera_id":    self.camera_id,
            "timestamp":    self.timestamp,
            "hazard":       self.hazard.value,
            "confidence":   round(self.confidence, 4),
            "motion_score": round(self.motion_score, 4),
            "bbox":         self.bbox,
            "alert":        self.alert,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class InferenceConfig:
    """
    Tunable parameters for the inference pipeline.

    Attributes:
        camera_id:              Camera this pipeline is attached to
        detection_threshold:    Minimum confidence to raise an alert [0–1]
        motion_threshold:       Minimum motion score to trigger hazard check [0–1]
        jpeg_quality:           JPEG encode quality for annotated frames [1–100]
        encode_frames:          Set False to skip JPEG encoding (JSON events only)
        inference_fps:          Max frames-per-second to run inference on
                                (independent of capture FPS — reduces GPU/CPU load)
    """
    camera_id: int
    detection_threshold: float = 0.75
    motion_threshold: float = 0.02       # 2% pixel change triggers a hazard check
    jpeg_quality: int = 70
    encode_frames: bool = True
    inference_fps: float = 5.0           # run inference at 5 fps regardless of capture fps


# ─────────────────────────────────────────────────────────────────────────────
# Motion detector (Stage 1)
# ─────────────────────────────────────────────────────────────────────────────

class MotionDetector:
    """
    Frame-differencing motion detector.

    Computes the fraction of pixels that changed significantly between
    consecutive frames. This is the cheapest possible first-pass filter —
    no point running a heavy model on a completely static scene.
    """

    def __init__(self, blur_ksize: int = 5, diff_threshold: int = 25) -> None:
        self._prev_gray: Optional[np.ndarray] = None
        self._blur_ksize = blur_ksize | 1   # must be odd
        self._diff_threshold = diff_threshold

    def update(self, frame: np.ndarray) -> float:
        """
        Feed a new frame and return a motion score in [0.0, 1.0].

        0.0 = identical to previous frame
        1.0 = every pixel changed
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (self._blur_ksize, self._blur_ksize), 0)

        if self._prev_gray is None:
            self._prev_gray = gray
            return 0.0

        diff = cv2.absdiff(self._prev_gray, gray)
        self._prev_gray = gray

        _, thresh = cv2.threshold(diff, self._diff_threshold, 255, cv2.THRESH_BINARY)
        motion_score = float(np.count_nonzero(thresh)) / float(thresh.size)
        return motion_score


# ─────────────────────────────────────────────────────────────────────────────
# Hazard classifier (Stage 2)
# ─────────────────────────────────────────────────────────────────────────────

def _classify_hazard(
    frame: np.ndarray,
    motion_score: float,
) -> tuple[HazardType, float, Optional[list[int]]]:
    """
    Hazard classification stub.

    ┌─────────────────────────────────────────────────────────────────────┐
    │  INTEGRATION POINT — Replace this function body with your model:    │
    │                                                                     │
    │  Option A — ONNX Runtime:                                           │
    │    net = cv2.dnn.readNetFromONNX("hazard_model.onnx")               │
    │    blob = cv2.dnn.blobFromImage(frame, 1/255, (640,640))            │
    │    net.setInput(blob)                                               │
    │    detections = net.forward()                                       │
    │    # parse detections -> (HazardType, confidence, [x,y,w,h])       │
    │                                                                     │
    │  Option B — YOLOv8 (ultralytics):                                   │
    │    results = model(frame, verbose=False)[0]                         │
    │    # map class_id -> HazardType                                     │
    │                                                                     │
    │  Option C — TensorFlow Lite:                                        │
    │    interpreter.set_tensor(input_details[0]["index"], input_data)    │
    │    interpreter.invoke()                                             │
    │    output = interpreter.get_tensor(output_details[0]["index"])      │
    └─────────────────────────────────────────────────────────────────────┘

    No model ships with this project. By default (SIMULATE_DETECTIONS=false)
    this function reports "no hazard" for every frame, so the pipeline never
    raises an alert on its own. For demos you can set SIMULATE_DETECTIONS=true
    in backend-express/.env: it then FABRICATES random hazards whenever there
    is motion. Those are NOT real detections.

    Returns:
        (HazardType, confidence [0–1], bounding_box [x, y, w, h] | None)
    """
    if not config.SIMULATE_DETECTIONS:
        return HazardType.NONE, 0.0, None

    # No motion → nothing to simulate
    if motion_score < 0.005:
        return HazardType.NONE, 0.0, None

    # ── SIMULATION (demo only) ────────────────────────────────────────────────
    # Higher motion → higher chance of a (fake) hazard.
    hazard_probability = min(motion_score * 8.0, 0.95)

    if random.random() > hazard_probability:
        return HazardType.NONE, motion_score * 0.3, None

    hazard = random.choice([
        HazardType.FIRE, HazardType.SMOKE,
        HazardType.INTRUSION, HazardType.FALL,
    ])
    confidence = 0.60 + random.random() * 0.35  # 0.60 – 0.95

    # Placeholder bounding box (centre of frame, 30% of width/height)
    h, w = frame.shape[:2]
    bx, by = int(w * 0.35), int(h * 0.35)
    bw, bh = int(w * 0.30), int(h * 0.30)
    bbox = [bx, by, bw, bh]

    return hazard, confidence, bbox


def detector_mode() -> str:
    """'simulated' (demo, random output) or 'none' (no model loaded)."""
    return "simulated" if config.SIMULATE_DETECTIONS else "none"


# ─────────────────────────────────────────────────────────────────────────────
# Frame annotation
# ─────────────────────────────────────────────────────────────────────────────

# Hazard → BGR colour for annotation overlays
_HAZARD_COLORS: dict[HazardType, tuple[int, int, int]] = {
    HazardType.FIRE:      (0,   60,  255),   # red-orange
    HazardType.SMOKE:     (180, 180, 180),   # grey
    HazardType.INTRUSION: (0,   165, 255),   # orange
    HazardType.FALL:      (255, 0,   200),   # magenta
    HazardType.CROWD:     (0,   0,   220),   # deep red
    HazardType.NONE:      (0,   255, 120),   # green
}


def _annotate_frame(
    frame: np.ndarray,
    result: InferenceResult,
) -> np.ndarray:
    """
    Draw detection overlay on a copy of the frame.

    Draws:
      - Bounding box with hazard label when a hazard is detected
      - HUD strip at the top: camera ID | timestamp | motion score
      - Status badge (CLEAR / ALERT) in the top-right corner
    """
    out = frame.copy()
    color = _HAZARD_COLORS.get(result.hazard, (0, 255, 120))
    h, w = out.shape[:2]

    # ── Bounding box ──────────────────────────────────────────────────────────
    if result.bbox and result.hazard != HazardType.NONE:
        x, y, bw, bh = result.bbox
        cv2.rectangle(out, (x, y), (x + bw, y + bh), color, 2)
        label = f"{result.hazard.value.upper()} {result.confidence:.0%}"
        (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
        cv2.rectangle(out, (x, y - lh - 8), (x + lw + 6, y), color, -1)
        cv2.putText(out, label, (x + 3, y - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)

    # ── Top HUD strip ─────────────────────────────────────────────────────────
    hud_text = (
        f"CAM#{result.camera_id} | "
        f"{time.strftime('%H:%M:%S', time.localtime(result.timestamp))} | "
        f"Motion: {result.motion_score:.1%}"
    )
    cv2.rectangle(out, (0, 0), (w, 26), (0, 0, 0), -1)
    cv2.putText(out, hud_text, (6, 18),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1, cv2.LINE_AA)

    # ── Status badge ──────────────────────────────────────────────────────────
    badge     = "⚠ ALERT" if result.alert else "● CLEAR"
    badge_col = (0, 0, 200) if result.alert else (0, 180, 0)
    (bw2, bh2), _ = cv2.getTextSize(badge, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
    bx2 = w - bw2 - 12
    cv2.rectangle(out, (bx2 - 4, 4), (w - 4, bh2 + 10), badge_col, -1)
    cv2.putText(out, badge, (bx2, bh2 + 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)

    return out


# ─────────────────────────────────────────────────────────────────────────────
# InferencePipeline — the orchestrator
# ─────────────────────────────────────────────────────────────────────────────

class InferencePipeline:
    """
    Runs motion detection + hazard classification in a background daemon thread.

    Consumes frames from an RTSPCapture queue, produces InferenceResult objects
    into an output queue consumed by the WebSocket router.

    Usage:
        pipeline = InferencePipeline(cfg, frame_source=capture.get_frame)
        pipeline.start()
        result = pipeline.get_result(timeout=0.5)
        pipeline.stop()
    """

    def __init__(
        self,
        cfg: InferenceConfig,
        frame_source: Callable[..., Optional[np.ndarray]],
        on_alert: Optional[Callable[[InferenceResult], None]] = None,
    ) -> None:
        """
        Args:
            cfg:          Inference configuration
            frame_source: Callable returning Optional[np.ndarray] (RTSPCapture.get_frame)
            on_alert:     Optional callback invoked synchronously when alert=True
                          (use for immediate WebSocket push or database writes)
        """
        self._cfg = cfg
        self._frame_source = frame_source
        self._on_alert = on_alert
        self._stop_event = threading.Event()
        # Latest result + monotonically increasing sequence number. Readers keep
        # their own `after_seq`, so any number of consumers (frame stream, event
        # stream, snapshot...) each see every result - none "steals" from another.
        self._cond = threading.Condition()
        self._latest: Optional[InferenceResult] = None
        self._seq: int = 0
        self._thread: Optional[threading.Thread] = None
        self._motion = MotionDetector()

        self.results_produced: int = 0
        self.alerts_raised: int = 0

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._inference_loop,
            name=f"cv-inference-{self._cfg.camera_id}",
            daemon=True,
        )
        self._thread.start()
        logger.info("[CV#%d] Inference pipeline started.", self._cfg.camera_id)

    def stop(self) -> None:
        self._stop_event.set()
        with self._cond:
            self._cond.notify_all()
        if self._thread:
            self._thread.join(timeout=5.0)
            self._thread = None
        logger.info("[CV#%d] Inference pipeline stopped.", self._cfg.camera_id)

    def get_result(self, timeout: float = 0.1) -> Optional[InferenceResult]:
        """Latest InferenceResult (NON-consuming), waiting up to `timeout` if none exists yet."""
        with self._cond:
            if self._latest is None and timeout > 0:
                self._cond.wait_for(
                    lambda: self._latest is not None or self._stop_event.is_set(), timeout
                )
            return self._latest

    def get_latest(
        self, after_seq: int = 0, timeout: float = 0.0
    ) -> tuple[Optional[InferenceResult], int]:
        """
        Return (result, seq) for the newest result whose seq > `after_seq`,
        or (None, after_seq) if nothing newer exists. With timeout > 0 it waits
        for one. Results are never consumed - every caller tracks its own seq.
        """
        with self._cond:
            if self._seq <= after_seq and timeout > 0:
                self._cond.wait_for(
                    lambda: self._seq > after_seq or self._stop_event.is_set(), timeout
                )
            if self._seq > after_seq:
                return self._latest, self._seq
            return None, after_seq

    @property
    def status(self) -> dict:
        return {
            "camera_id":      self._cfg.camera_id,
            "results_produced": self.results_produced,
            "alerts_raised":  self.alerts_raised,
            "detector":       detector_mode(),
        }

    # ── Internal inference loop ───────────────────────────────────────────────

    def _inference_loop(self) -> None:
        frame_interval = 1.0 / max(self._cfg.inference_fps, 1.0)
        logger.info("[CV#%d] Inference loop running at %.1f fps.", self._cfg.camera_id, self._cfg.inference_fps)

        while not self._stop_event.is_set():
            t_start = time.monotonic()

            # ── Grab latest frame ─────────────────────────────────────────────
            frame = self._frame_source(timeout=0.2)
            if frame is None:
                # No frame yet (stream starting or reconnecting) — idle wait
                self._stop_event.wait(timeout=0.1)
                continue

            try:
                result = self._process_frame(frame)
            except Exception as e:
                logger.error("[CV#%d] Frame processing error: %s", self._cfg.camera_id, e, exc_info=True)
                self._stop_event.wait(timeout=0.5)   # don't spin + flood the log on a persistent error
                continue

            # ── Publish result ────────────────────────────────────────────────
            with self._cond:
                self._latest = result
                self._seq += 1
                self._cond.notify_all()
            self.results_produced += 1

            # ── Fire alert callback ───────────────────────────────────────────
            if result.alert and self._on_alert:
                try:
                    self._on_alert(result)
                    self.alerts_raised += 1
                except Exception as e:
                    logger.error("[CV#%d] Alert callback error: %s", self._cfg.camera_id, e)

            # ── Throttle to inference_fps ─────────────────────────────────────
            elapsed = time.monotonic() - t_start
            sleep_for = frame_interval - elapsed
            if sleep_for > 0:
                self._stop_event.wait(timeout=sleep_for)

        logger.info("[CV#%d] Inference loop exited.", self._cfg.camera_id)

    def _process_frame(self, frame: np.ndarray) -> InferenceResult:
        """Run the full detection pipeline on a single frame."""
        ts = time.time()

        # Stage 1 — Motion detection (fast, always runs)
        motion_score = self._motion.update(frame)

        # Stage 2 — Hazard classification (only when motion detected)
        hazard, confidence, bbox = _classify_hazard(frame, motion_score)
        is_alert = (
            hazard != HazardType.NONE
            and confidence >= self._cfg.detection_threshold
        )

        result = InferenceResult(
            camera_id=self._cfg.camera_id,
            timestamp=ts,
            hazard=hazard,
            confidence=confidence,
            motion_score=motion_score,
            bbox=bbox,
            alert=is_alert,
        )

        # Stage 3 — Frame annotation + JPEG encode (optional)
        if self._cfg.encode_frames:
            annotated = _annotate_frame(frame, result)
            ok, buf = cv2.imencode(
                ".jpg",
                annotated,
                [cv2.IMWRITE_JPEG_QUALITY, self._cfg.jpeg_quality],
            )
            result.frame_jpeg = bytes(buf) if ok else None

        return result
