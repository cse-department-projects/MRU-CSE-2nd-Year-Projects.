"""
cv_main.py — Standalone FastAPI application for RTSP + Real-Time CV inference.

This file wires together:
  - StreamManager  (rtsp_capture + cv_inference threads)
  - AlertForwarder (pushes detections to the Express backend)
  - ws_router      (internal WebSocket endpoints for frames + events)
  - REST API       (camera start/stop/status, health)

Who talks to whom:
  Express (port 8000)  ──►  this service (port 8001)   start/stop camera streams
  this service         ──►  Express                    POST /api/internal/alerts
The browser never calls this service directly.

Security: every /api/* route and WebSocket requires the shared INTERNAL_API_KEY
(header ``X-Internal-Key``, or ``?token=`` for WebSockets). Bind it to
localhost (see start.bat) — it is not meant to face the network.

Run:
    uvicorn cv_main:app --host 127.0.0.1 --port 8001 --workers 1

    NOTE: Use exactly 1 worker. Multiple workers cannot share the in-process
    StreamManager.

API Summary:
    POST   /api/cameras          — Register and start a camera stream
    DELETE /api/cameras/{id}     — Stop and remove a camera stream
    GET    /api/cameras          — List all active camera sessions + status
    GET    /api/cameras/{id}     — Get status of a single camera
    GET    /api/cameras/{id}/snapshot — Latest annotated JPEG frame (HTTP)
    GET    /health               — Health (details only with the internal key)
    WS     /ws/stream/{id}       — Binary JPEG frame stream
    WS     /ws/events/{id}       — JSON inference event stream
    WS     /ws/alerts            — Multi-camera aggregated alert bus
"""

from __future__ import annotations

import logging
import sys
import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Path, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

import config
import ws_router
from alert_forwarder import AlertForwarder
from cv_inference import InferenceResult, detector_mode
from security import mask_url, safe_equal
from stream_manager import StreamManager

# ── Logging setup ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("trinetra.cv_main")

# ── Global StreamManager instance ─────────────────────────────────────────────
manager = StreamManager()


# ─────────────────────────────────────────────────────────────────────────────
# Alert callback — called from the inference thread on every hazard detection.
# This must be thread-safe (no async operations).
# ─────────────────────────────────────────────────────────────────────────────

forwarder = AlertForwarder(
    express_url=config.EXPRESS_URL,
    api_key=config.INTERNAL_API_KEY,
    cooldown_seconds=config.ALERT_COOLDOWN_SECONDS,
)


def on_hazard_alert(result: InferenceResult) -> None:
    """
    Invoked by the inference thread for each alert frame (up to ~5/s).

    Hands the detection to the AlertForwarder, which applies a per-camera
    cooldown and POSTs it to Express in a background thread. Express creates the
    incident, pops the alert up on the operator's dashboard and starts the
    10-second auto-dispatch countdown.

    DO NOT use asyncio.run() or await here — this runs inside a thread.
    """
    queued = forwarder.submit(result)
    if queued:
        logger.warning(
            "[ALERT] Camera #%d | Hazard: %s | Confidence: %.1f%% | Motion: %.1f%%",
            result.camera_id,
            result.hazard.value.upper(),
            result.confidence * 100,
            result.motion_score * 100,
        )


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI lifespan — startup / shutdown
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Modern lifespan handler (replaces on_event startup/shutdown).
    Initialises the WebSocket router and performs clean shutdown.
    """
    ws_router.init_router(manager)
    forwarder.start()

    if not config.INTERNAL_API_KEY:
        logger.error(
            "INTERNAL_API_KEY is not set: the REST API is DISABLED (503) and alerts cannot be "
            "forwarded. Run `npm run init-env` in backend-express/ and restart."
        )
    if config.SIMULATE_DETECTIONS:
        logger.warning(
            "SIMULATE_DETECTIONS=true: the detector FABRICATES random hazards from motion. "
            "Demo only — these are not real detections."
        )
    else:
        logger.warning(
            "No detection model is loaded (SIMULATE_DETECTIONS=false): cameras are captured and "
            "annotated but no hazard alerts will be raised by this engine. See cv_inference._classify_hazard()."
        )
    logger.info("[Startup] Trinetra CV Engine ready. Alerts -> %s", config.EXPRESS_URL)
    yield
    logger.info("[Shutdown] Stopping all camera streams...")
    await manager.stop_all()
    forwarder.stop()
    logger.info("[Shutdown] All streams stopped. Goodbye.")


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI app
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Trinetra AI — CV Stream API",
    description=(
        "Real-time RTSP capture, hazard inference, and WebSocket streaming engine. "
        "No model is bundled: implement `_classify_hazard()` in cv_inference.py to plug one in."
    ),
    version="2.1.0",
    lifespan=lifespan,
)

# Browsers never call this service (Express does), so CORS is off unless you
# explicitly list origins in CV_CORS_ORIGINS.
if config.CV_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.CV_CORS_ORIGINS,
        allow_credentials=False,
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["X-Internal-Key", "Content-Type"],
    )


async def require_internal_key(x_internal_key: Optional[str] = Header(default=None)) -> None:
    """FastAPI dependency: only callers holding the shared INTERNAL_API_KEY get in."""
    if not config.INTERNAL_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="CV engine not configured: INTERNAL_API_KEY is missing (run `npm run init-env`).",
        )
    if not safe_equal(x_internal_key, config.INTERNAL_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing X-Internal-Key.")


# Mount WebSocket routes
app.include_router(ws_router.router)


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic schemas
# ─────────────────────────────────────────────────────────────────────────────

class CameraRegisterRequest(BaseModel):
    """Payload for POST /api/cameras."""
    camera_id: int = Field(..., gt=0, description="Unique positive integer camera ID")
    stream_url: str = Field(..., min_length=7, max_length=500, description="Full stream URL")
    target_fps: float = Field(default=10.0, ge=1.0, le=30.0, description="Capture frame rate")
    inference_fps: float = Field(default=5.0, ge=1.0, le=15.0, description="Inference frame rate")
    detection_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    encode_frames: bool = Field(default=True, description="JPEG-encode annotated frames")

    @field_validator("stream_url")
    @classmethod
    def validate_rtsp_url(cls, v: str) -> str:
        if not v.lower().startswith(("rtsp://", "rtsps://", "rtmp://", "http://", "https://")):
            raise ValueError("stream_url must start with rtsp://, rtsps://, rtmp://, http:// or https://")
        return v

    model_config = {"json_schema_extra": {
        "example": {
            "camera_id": 1,
            "stream_url": "rtsp://admin:password@192.168.1.10:554/stream1",
            "target_fps": 10.0,
            "inference_fps": 5.0,
            "detection_threshold": 0.75,
            "encode_frames": True,
        }
    }}


class CameraResponse(BaseModel):
    """Response body for camera registration."""
    camera_id: int
    stream_url: str
    status: str
    message: str


# ─────────────────────────────────────────────────────────────────────────────
# REST routes
# ─────────────────────────────────────────────────────────────────────────────

@app.post(
    "/api/cameras",
    response_model=CameraResponse,
    status_code=201,
    summary="Register and start an RTSP camera stream",
    dependencies=[Depends(require_internal_key)],
)
async def register_camera(body: CameraRegisterRequest):
    """
    Register a camera and immediately begin RTSP capture + CV inference.

    The RTSP stream is opened asynchronously; if it is unreachable, the
    capture thread will retry with exponential backoff in the background.
    Check GET /api/cameras/{id} to monitor connection status.

    Error responses:
        422 — Invalid stream_url (validation error)
        409 — Camera ID already registered
    """
    if manager.is_active(body.camera_id):
        raise HTTPException(
            status_code=409,
            detail=f"Camera #{body.camera_id} is already registered. "
                   f"DELETE it first to re-register.",
        )

    await manager.start_camera(
        camera_id=body.camera_id,
        stream_url=body.stream_url,
        on_alert=on_hazard_alert,
        rtsp_cfg_overrides={"target_fps": body.target_fps},
        inference_cfg_overrides={
            "inference_fps": body.inference_fps,
            "detection_threshold": body.detection_threshold,
            "encode_frames": body.encode_frames,
        },
    )

    logger.info("[API] Camera #%d registered | URL: %s", body.camera_id, mask_url(body.stream_url))
    return CameraResponse(
        camera_id=body.camera_id,
        stream_url=mask_url(body.stream_url),
        status="starting",
        message=(
            f"Camera #{body.camera_id} is connecting. "
            f"Connect to ws://host/ws/stream/{body.camera_id} for the live feed."
        ),
    )


@app.delete(
    "/api/cameras/{camera_id}",
    status_code=204,
    summary="Stop and deregister a camera stream",
    dependencies=[Depends(require_internal_key)],
)
async def deregister_camera(
    camera_id: int = Path(..., gt=0, description="Camera ID to stop"),
):
    """
    Stop the RTSP capture + CV inference threads for this camera and
    remove it from the registry.

    Error responses:
        404 — Camera not found
    """
    stopped = await manager.stop_camera(camera_id)
    if not stopped:
        raise HTTPException(status_code=404, detail=f"Camera #{camera_id} not found.")
    logger.info("[API] Camera #%d stopped.", camera_id)
    return Response(status_code=204)


@app.get(
    "/api/cameras",
    summary="List all active camera sessions",
    dependencies=[Depends(require_internal_key)],
)
async def list_cameras():
    """Returns a list of all active camera IDs and their status snapshots."""
    return {
        "active_cameras": manager.active_camera_ids,
        "count": manager.active_count,
        "sessions": manager.health_report()["cameras"],
    }


@app.get(
    "/api/cameras/{camera_id}",
    summary="Get status of a single camera",
    dependencies=[Depends(require_internal_key)],
)
async def get_camera_status(
    camera_id: int = Path(..., gt=0),
):
    """
    Returns the full status snapshot for the given camera ID.

    Error responses:
        404 — Camera not registered
    """
    if not manager.is_active(camera_id):
        raise HTTPException(status_code=404, detail=f"Camera #{camera_id} not found.")
    # Access session directly for the full status dict
    session = manager._sessions.get(camera_id)
    return session.status if session else {}


@app.get(
    "/api/cameras/{camera_id}/snapshot",
    summary="Fetch the latest annotated JPEG frame over HTTP",
    dependencies=[Depends(require_internal_key)],
    responses={
        200: {"content": {"image/jpeg": {}}, "description": "JPEG-encoded annotated frame"},
        404: {"description": "Camera not registered"},
        503: {"description": "No frame available yet"},
    },
)
async def get_snapshot(
    camera_id: int = Path(..., gt=0),
):
    """
    HTTP GET alternative to the WebSocket stream.
    Returns the latest annotated JPEG frame as an image/jpeg response.
    Useful for HTML <img> tags refreshed by polling or for debugging.

    Error responses:
        404 — Camera not registered
        503 — Stream not yet producing frames (capture starting / reconnecting)
    """
    if not manager.is_active(camera_id):
        raise HTTPException(status_code=404, detail=f"Camera #{camera_id} not found.")

    result = await manager.get_latest_result(camera_id, timeout=0.5)
    if result is None or result.frame_jpeg is None:
        raise HTTPException(
            status_code=503,
            detail=f"Camera #{camera_id}: no frame available yet. "
                   f"The stream may still be connecting.",
        )

    return Response(
        content=result.frame_jpeg,
        media_type="image/jpeg",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "X-Camera-Id":   str(camera_id),
            "X-Hazard":      result.hazard.value,
            "X-Confidence":  str(round(result.confidence, 4)),
            "X-Alert":       str(result.alert).lower(),
        },
    )


@app.get("/health", summary="Health report")
async def health(x_internal_key: Optional[str] = Header(default=None)):
    """
    Public: liveness + detector mode. With a valid X-Internal-Key the per-camera
    detail is included as well (stream URLs are always credential-masked).
    """
    report = manager.health_report()
    body = {
        "status":         "operational",
        "timestamp":      time.time(),
        "engine":         "Trinetra AI CV Engine v2.1",
        "detector":       detector_mode(),
        "active_streams": report["active_streams"],
        "alerts":         {"sent": forwarder.sent, "failed": forwarder.failed, "suppressed": forwarder.suppressed},
    }
    if safe_equal(x_internal_key, config.INTERNAL_API_KEY):
        body["cameras"] = report["cameras"]
    return body


# ─────────────────────────────────────────────────────────────────────────────
# Entry point (for direct python cv_main.py execution in development)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "cv_main:app",
        host="127.0.0.1",   # internal service — Express is the public face
        port=8001,
        reload=False,   # reload=True is incompatible with in-process thread management
        workers=1,      # MUST be 1 — StreamManager is not cross-process safe
        log_level="info",
    )
