"""
stream_manager.py — Async-safe lifecycle manager for RTSP+CV pipelines.

This layer is the bridge between FastAPI's async world and the sync
threading world of OpenCV. It:

  - Creates and tracks one RTSPCapture + InferencePipeline pair per camera
  - Starts/stops them via asyncio.to_thread so the event loop is never blocked
  - Exposes a clean async API that FastAPI route handlers can await directly
  - Provides an aggregate health/status snapshot for monitoring endpoints
"""

from __future__ import annotations

import asyncio
import logging
from typing import Callable, Optional

from rtsp_capture import RTSPCapture, RTSPConfig
from cv_inference import InferencePipeline, InferenceConfig, InferenceResult

logger = logging.getLogger("trinetra.stream_manager")


# ─────────────────────────────────────────────────────────────────────────────
# Per-camera session
# ─────────────────────────────────────────────────────────────────────────────

class CameraSession:
    """
    Bundles an RTSPCapture and an InferencePipeline for a single camera.

    All I/O happens inside daemon threads; this object only holds handles.
    """

    def __init__(
        self,
        camera_id: int,
        stream_url: str,
        on_alert: Optional[Callable[[InferenceResult], None]] = None,
        rtsp_cfg_overrides: Optional[dict] = None,
        inference_cfg_overrides: Optional[dict] = None,
    ) -> None:
        rtsp_kw   = rtsp_cfg_overrides or {}
        infer_kw  = inference_cfg_overrides or {}

        rtsp_cfg  = RTSPConfig(stream_url=stream_url, camera_id=camera_id, **rtsp_kw)
        infer_cfg = InferenceConfig(camera_id=camera_id, **infer_kw)

        self.camera_id   = camera_id
        self.stream_url  = stream_url
        self.capture     = RTSPCapture(rtsp_cfg)
        self.pipeline    = InferencePipeline(
            cfg=infer_cfg,
            frame_source=self.capture.get_frame,
            on_alert=on_alert,
        )

    def start_sync(self) -> None:
        """Start both threads (called from asyncio.to_thread)."""
        self.capture.start()
        self.pipeline.start()
        logger.info("[Session #%d] Started (capture + inference).", self.camera_id)

    def stop_sync(self) -> None:
        """Stop both threads (called from asyncio.to_thread)."""
        self.pipeline.stop()
        self.capture.stop()
        logger.info("[Session #%d] Stopped (capture + inference).", self.camera_id)

    @property
    def status(self) -> dict:
        return {
            **self.capture.status,
            "inference": self.pipeline.status,
        }


# ─────────────────────────────────────────────────────────────────────────────
# StreamManager — the singleton used by FastAPI
# ─────────────────────────────────────────────────────────────────────────────

class StreamManager:
    """
    Async-safe registry of all active RTSP+CV sessions.

    Usage in FastAPI:
        # On startup:
        stream_manager = StreamManager()

        # Register a camera (from an async route handler):
        await stream_manager.start_camera(
            camera_id=1,
            stream_url="rtsp://...",
            on_alert=my_alert_callback,
        )

        # Pull the latest inference result:
        result = await stream_manager.get_latest_result(camera_id=1)

        # On shutdown:
        await stream_manager.stop_all()
    """

    def __init__(self) -> None:
        self._sessions: dict[int, CameraSession] = {}
        self._lock = asyncio.Lock()   # protects the sessions dict from concurrent mutation

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start_camera(
        self,
        camera_id: int,
        stream_url: str,
        on_alert: Optional[Callable[[InferenceResult], None]] = None,
        rtsp_cfg_overrides: Optional[dict] = None,
        inference_cfg_overrides: Optional[dict] = None,
    ) -> CameraSession:
        """
        Register and start an RTSP+CV session for the given camera.

        If a session already exists for `camera_id`, it is returned unchanged.
        The thread-blocking start_sync() is offloaded via asyncio.to_thread
        so the FastAPI event loop is never stalled.

        Raises:
            ValueError: if stream_url is empty/None
        """
        if not stream_url:
            raise ValueError(f"Camera #{camera_id}: stream_url cannot be empty.")

        async with self._lock:
            if camera_id in self._sessions:
                logger.debug("[StreamManager] Camera #%d already active.", camera_id)
                return self._sessions[camera_id]

            session = CameraSession(
                camera_id=camera_id,
                stream_url=stream_url,
                on_alert=on_alert,
                rtsp_cfg_overrides=rtsp_cfg_overrides,
                inference_cfg_overrides=inference_cfg_overrides,
            )

            # Offload blocking thread.start() calls to a thread pool
            await asyncio.to_thread(session.start_sync)
            self._sessions[camera_id] = session
            logger.info("[StreamManager] Camera #%d registered. Total: %d",
                        camera_id, len(self._sessions))
            return session

    async def stop_camera(self, camera_id: int) -> bool:
        """
        Stop and deregister the session for `camera_id`.

        Returns True if a session was found and stopped, False otherwise.
        """
        async with self._lock:
            session = self._sessions.pop(camera_id, None)
            if not session:
                logger.debug("[StreamManager] Camera #%d not found.", camera_id)
                return False
            await asyncio.to_thread(session.stop_sync)
            logger.info("[StreamManager] Camera #%d stopped. Remaining: %d",
                        camera_id, len(self._sessions))
            return True

    async def stop_all(self) -> None:
        """Stop all sessions. Call from FastAPI lifespan shutdown handler."""
        async with self._lock:
            camera_ids = list(self._sessions.keys())

        # Stop concurrently — no need for the lock while stopping
        await asyncio.gather(
            *(self.stop_camera(cid) for cid in camera_ids),
            return_exceptions=True,
        )
        logger.info("[StreamManager] All sessions stopped.")

    # ── Data access ───────────────────────────────────────────────────────────

    async def get_latest_result(
        self,
        camera_id: int,
        timeout: float = 0.2,
    ) -> Optional[InferenceResult]:
        """
        Latest inference result for a camera (non-consuming).

        Waiting for the first result happens in a worker thread so the async
        event loop is never blocked.
        """
        session = self._sessions.get(camera_id)
        if not session:
            return None
        return await asyncio.to_thread(session.pipeline.get_result, timeout)

    def peek_next_result(
        self, camera_id: int, after_seq: int
    ) -> tuple[Optional[InferenceResult], int]:
        """
        Non-blocking: (result, seq) if a result newer than `after_seq` exists, else
        (None, after_seq). Each WebSocket client keeps its own `after_seq`, so
        several viewers never take results away from each other.
        """
        session = self._sessions.get(camera_id)
        if not session:
            return None, after_seq
        return session.pipeline.get_latest(after_seq, timeout=0.0)

    def is_active(self, camera_id: int) -> bool:
        return camera_id in self._sessions

    @property
    def active_camera_ids(self) -> list[int]:
        return list(self._sessions.keys())

    @property
    def active_count(self) -> int:
        return len(self._sessions)

    def health_report(self) -> dict:
        """Full status snapshot for the /health endpoint."""
        return {
            "active_streams": self.active_count,
            "cameras": {
                str(cid): session.status
                for cid, session in self._sessions.items()
            },
        }
