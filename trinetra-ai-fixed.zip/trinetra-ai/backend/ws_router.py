"""
ws_router.py — FastAPI WebSocket router for real-time RTSP + CV streams.

Three INTERNAL WebSocket endpoints (debugging / server-side consumers):

  1. /ws/stream/{camera_id}  — annotated JPEG frames as binary messages
  2. /ws/events/{camera_id}  — JSON inference events (no binary data)
  3. /ws/alerts              — aggregated alert bus across all cameras

These are NOT used by the React dashboard: the dashboard receives alerts from
Express (/ws/alerts on port 8000), which owns users, incidents and the 112
countdown. This service is bound to localhost and only trusts callers that
present the shared INTERNAL_API_KEY as ``?token=``.

Authentication: the handshake is accepted first so the client can read the
close code, but NOTHING is sent and no camera data is touched until the token
has been verified; a bad token closes the socket with 4001 / 4003.

Polling model: every connection tracks the last result sequence number it has
seen (``stream_manager.peek_next_result``). Results are never consumed, so
several viewers never take frames or alerts away from each other, and a client
only receives each result once.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Optional

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

import config
from security import safe_equal
from stream_manager import StreamManager

logger = logging.getLogger("trinetra.ws_router")

router = APIRouter(tags=["WebSocket Streams"])

_manager: Optional[StreamManager] = None

POLL_INTERVAL_S = 0.04   # 25 Hz — well above the max inference rate (15 fps)


def init_router(manager: StreamManager) -> None:
    """Call this from cv_main.py after creating the StreamManager."""
    global _manager
    _manager = manager


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

async def _authenticate(websocket: WebSocket, token: Optional[str]) -> bool:
    """
    Accept the handshake, then verify the shared internal key.
    Closes the socket (4001 missing / 4003 invalid) and returns False on failure.
    """
    await websocket.accept()

    if not token:
        await websocket.close(code=4001, reason="Missing authentication token.")
        return False

    if not safe_equal(token, config.INTERNAL_API_KEY):
        await websocket.close(code=4003, reason="Invalid token.")
        return False

    return True


async def _send_error_json(ws: WebSocket, code: int, message: str) -> None:
    """Send a structured error JSON frame before closing."""
    try:
        await ws.send_text(json.dumps({
            "event": "ERROR",
            "code": code,
            "message": message,
            "timestamp": time.time(),
        }))
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 1 — Binary JPEG frame stream
# ─────────────────────────────────────────────────────────────────────────────

@router.websocket("/ws/stream/{camera_id}")
async def ws_frame_stream(
    websocket: WebSocket,
    camera_id: int,
    token: Optional[str] = Query(default=None, description="Shared internal key"),
):
    """
    Streams annotated JPEG frames as binary messages (one per new result).

    Close / error codes:
        4001 — Missing token
        4003 — Invalid token
        4040 — Camera not registered in StreamManager
        5030 — Inference pipeline not producing results
    """
    if not await _authenticate(websocket, token):
        return
    logger.info("[WS Stream] Client connected to Camera #%d", camera_id)

    if _manager is None or not _manager.is_active(camera_id):
        await _send_error_json(websocket, 4040,
            f"Camera #{camera_id} is not registered or not currently streaming.")
        await websocket.close(code=4040, reason="Camera not found.")
        return

    last_seq = 0
    idle_polls = 0
    warn_after = int(5.0 / POLL_INTERVAL_S)   # ~5 s without a new result
    warned = False

    try:
        while True:
            result, seq = _manager.peek_next_result(camera_id, last_seq)

            if result is None:
                if not _manager.is_active(camera_id):
                    await _send_error_json(websocket, 4040, f"Camera #{camera_id} was removed.")
                    await websocket.close(code=4040, reason="Camera removed.")
                    return
                idle_polls += 1
                if idle_polls >= warn_after and not warned:
                    warned = True
                    logger.warning("[WS Stream] Camera #%d: no frames for 5 s.", camera_id)
                    await _send_error_json(websocket, 5030,
                        f"Camera #{camera_id} stream appears to be down. Reconnecting...")
                await asyncio.sleep(POLL_INTERVAL_S)
                continue

            last_seq = seq
            idle_polls = 0
            warned = False

            if result.frame_jpeg:
                await websocket.send_bytes(result.frame_jpeg)
            else:
                await websocket.send_text(json.dumps(result.to_event_dict()))

            if result.alert:
                await websocket.send_text(json.dumps({
                    **result.to_event_dict(),
                    "event": "HAZARD_ALERT",
                }))

    except WebSocketDisconnect:
        logger.info("[WS Stream] Client disconnected from Camera #%d", camera_id)
    except Exception as e:
        logger.error("[WS Stream] Camera #%d error: %s", camera_id, e, exc_info=True)
        await _send_error_json(websocket, 5000, f"Internal stream error: {e}")
    finally:
        logger.info("[WS Stream] Camera #%d session closed.", camera_id)


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 2 — Lightweight JSON event stream
# ─────────────────────────────────────────────────────────────────────────────

@router.websocket("/ws/events/{camera_id}")
async def ws_event_stream(
    websocket: WebSocket,
    camera_id: int,
    token: Optional[str] = Query(default=None, description="Shared internal key"),
    alert_only: bool = Query(default=False, description="Only emit HAZARD_ALERT events"),
):
    """
    Streams JSON inference events (no binary data). With alert_only=true only
    results where alert=True are emitted.

    Event format:
        {"event": "INFERENCE_RESULT" | "HAZARD_ALERT", "camera_id": 1,
         "timestamp": 1723558747.123, "hazard": "fire" | "smoke" | "intrusion" |
         "fall" | "none", "confidence": 0.9123, "motion_score": 0.12,
         "bbox": [x, y, w, h] | null, "alert": true | false}
    """
    if not await _authenticate(websocket, token):
        return
    logger.info("[WS Events] Client connected to Camera #%d (alert_only=%s)", camera_id, alert_only)

    if _manager is None or not _manager.is_active(camera_id):
        await _send_error_json(websocket, 4040,
            f"Camera #{camera_id} is not registered or not currently streaming.")
        await websocket.close(code=4040, reason="Camera not found.")
        return

    await websocket.send_text(json.dumps({
        "event":      "CONNECTED",
        "camera_id":  camera_id,
        "message":    f"Event stream active for Camera #{camera_id}.",
        "alert_only": alert_only,
        "timestamp":  time.time(),
    }))

    last_seq = 0
    last_heartbeat = time.monotonic()

    try:
        while True:
            now = time.monotonic()
            if now - last_heartbeat >= 15.0:
                await websocket.send_text(json.dumps({
                    "event": "HEARTBEAT", "camera_id": camera_id, "timestamp": time.time(),
                }))
                last_heartbeat = now

            result, seq = _manager.peek_next_result(camera_id, last_seq)
            if result is None:
                if not _manager.is_active(camera_id):
                    await websocket.close(code=4040, reason="Camera removed.")
                    return
                await asyncio.sleep(POLL_INTERVAL_S)
                continue

            last_seq = seq
            if alert_only and not result.alert:
                continue

            event = result.to_event_dict()
            if result.alert:
                event["event"] = "HAZARD_ALERT"
            await websocket.send_text(json.dumps(event))

    except WebSocketDisconnect:
        logger.info("[WS Events] Client disconnected from Camera #%d", camera_id)
    except Exception as e:
        logger.error("[WS Events] Camera #%d error: %s", camera_id, e, exc_info=True)
    finally:
        logger.info("[WS Events] Camera #%d session closed.", camera_id)


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 3 — Multi-camera aggregated alert bus
# ─────────────────────────────────────────────────────────────────────────────

@router.websocket("/ws/alerts")
async def ws_alert_bus(
    websocket: WebSocket,
    token: Optional[str] = Query(default=None, description="Shared internal key"),
):
    """
    Aggregated alert bus — emits HAZARD_ALERT events from ALL registered
    cameras to this single connection (each result is delivered once).
    """
    if not await _authenticate(websocket, token):
        return
    logger.info("[WS AlertBus] Client connected.")

    if _manager is None:
        await _send_error_json(websocket, 5030, "StreamManager not initialised.")
        await websocket.close()
        return

    await websocket.send_text(json.dumps({
        "event":          "CONNECTED",
        "message":        "Alert bus active. Monitoring all registered cameras.",
        "active_cameras": _manager.active_camera_ids,
        "timestamp":      time.time(),
    }))

    last_seq: dict[int, int] = {}
    last_heartbeat = time.monotonic()

    try:
        while True:
            for cid in _manager.active_camera_ids:
                result, seq = _manager.peek_next_result(cid, last_seq.get(cid, 0))
                if result is None:
                    continue
                last_seq[cid] = seq
                if result.alert:
                    await websocket.send_text(json.dumps({
                        **result.to_event_dict(),
                        "event": "HAZARD_ALERT",
                    }))

            now = time.monotonic()
            if now - last_heartbeat >= 15.0:
                await websocket.send_text(json.dumps({
                    "event":           "HEARTBEAT",
                    "active_cameras":  _manager.active_camera_ids,
                    "active_scanners": _manager.active_count,
                    "timestamp":       time.time(),
                }))
                last_heartbeat = now

            await asyncio.sleep(0.1)

    except WebSocketDisconnect:
        logger.info("[WS AlertBus] Client disconnected.")
    except Exception as e:
        logger.error("[WS AlertBus] Error: %s", e, exc_info=True)
    finally:
        logger.info("[WS AlertBus] Session closed.")
