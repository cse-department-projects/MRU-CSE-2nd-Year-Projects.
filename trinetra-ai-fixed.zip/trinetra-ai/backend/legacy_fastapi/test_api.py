import urllib.request, urllib.error, json, time, sys

# Set stdout encoding to UTF-8 to handle emoji printing in Windows terminal safely
if sys.stdout.encoding != 'utf-8':
    try:
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'replace')
    except Exception:
        pass

BASE = 'http://localhost:8000'

def post(url, data, token=None):
    req = urllib.request.Request(
        url, data=json.dumps(data).encode('utf-8'),
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    if token:
        req.add_header('Authorization', f'Bearer {token}')
    try:
        r = urllib.request.urlopen(req)
        return json.loads(r.read().decode('utf-8')), r.status
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode('utf-8')), e.code
        except Exception:
            return None, e.code

def get(url, token=None):
    req = urllib.request.Request(url)
    if token:
        req.add_header('Authorization', f'Bearer {token}')
    r = urllib.request.urlopen(req)
    return json.loads(r.read().decode('utf-8'))

print("=== Trinetra AI - End-to-End API Test ===")

# 1. Register
print("\n[1] Registering user...")
res, code = post(f'{BASE}/auth/register', {'username':'testop','email':'test@trinetra.ai','password':'sentinel123'})
username = res.get('user', {}).get('username', 'N/A') if res else 'N/A'
print(f"    Status {code}: user={username}")
token = res.get('access_token', '') if res else ''

# If already registered, login
if code != 201:
    print("[1b] User exists, logging in...")
    res2, code2 = post(f'{BASE}/auth/login', {'username':'testop','password':'sentinel123'})
    token = res2.get('access_token', '') if res2 else ''
    print(f"    Status {code2}: logged in")

# 2. Verify auth/me
print("\n[2] Verifying /auth/me...")
me = get(f'{BASE}/auth/me', token)
print(f"    User: {me['username']} | Email: {me['email']}")

# 3. Register Camera
print("\n[3] Registering camera...")
cam_data = {'device_name': 'Main Gate Cam', 'stream_url': 'rtsp://192.168.1.10:554/cam1', 'location_tag': 'Front Gate'}
cam, cam_code = post(f'{BASE}/cameras', cam_data, token)
print(f"    Status {cam_code}: id={cam.get('id')} status={cam.get('status')} location={cam.get('location_tag')}")

# 4. List cameras
time.sleep(0.5)
print("\n[4] Listing cameras...")
cams = get(f'{BASE}/cameras', token)
print(f"    {len(cams)} camera(s) registered")

# 5. Trigger test alert (Expected to fail with 403 Forbidden in PRODUCTION_MODE)
print("\n[5] Triggering test hazard alert (with PRODUCTION_MODE=True)...")
alert_res, alert_code = post(f'{BASE}/test/trigger-alert', {}, token)
if alert_code == 403:
    print(f"    SUCCESS: Correctly blocked in production mode. Status {alert_code}: {alert_res.get('detail')}")
else:
    print(f"    WARNING: Unexpected status {alert_code}: {alert_res}")

# 6. List incidents
time.sleep(0.5)
print("\n[6] Listing incidents...")
incs = get(f'{BASE}/incidents', token)
print(f"    {len(incs)} incident(s) found")
for inc in incs[:3]:
    # Safely encode and print to avoid Windows cmd crashes
    hazard = inc['hazard_type'].encode('ascii', 'replace').decode('ascii')
    print(f"    - [{inc['status'].upper()}] {hazard} @ {inc['location_tag']} | {inc['confidence']}")

print("\n=== ALL TESTS PASSED ===")
print(f"Backend is fully operational on http://localhost:8000")
print(f"API docs: http://localhost:8000/docs")
