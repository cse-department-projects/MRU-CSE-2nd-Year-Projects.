"""
Trinetra AI — FastAPI Backend
Real-time smart city & domestic hazard detection system.

Configuration:
  PRODUCTION_MODE = False   — set True in production to block test endpoints

Auth Routes (dual-aliased — /api/* preferred):
  POST /api/register        — User registration (JSON: {username, email, password})
  POST /api/login           — Login → JWT token (JSON: {username, password})
  GET  /api/me              — Authenticated user profile
  POST /auth/register       — Legacy alias
  POST /auth/login          — Legacy alias
  GET  /auth/me             — Legacy alias

Camera Routes:
  GET  /cameras             — List user's cameras
  POST /cameras             — Register camera + spawn stream monitor
  DELETE /cameras/{id}      — Remove camera + stop monitor
  PUT  /cameras/{id}/status — Toggle active/inactive

Incident Routes:
  GET  /incidents                 — List user's incidents (newest first)
  POST /incidents/{id}/cancel     — Cancel (false alarm)
  POST /incidents/{id}/confirm    — Confirm & dispatch 112 call

WebSocket Gateway:
  WS   /ws/alerts           — Real-time alert stream (token via ?token=)

Test Endpoint (dev only — blocked when PRODUCTION_MODE = True):
  POST /api/alerts/test     — Inject a mock HAZARD_ALERT into WebSocket pipeline
  POST /test/trigger-alert  — Legacy alias

Utility:
  GET  /health              — Service health + active scanner count
"""

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional

from fastapi import (
    FastAPI, Depends, HTTPException, WebSocket,
    WebSocketDisconnect, status, Query
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

import models
import schemas
import auth as auth_utils
import mock_cv
import mock_twilio
from database import engine, get_db

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s — %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("trinetra.main")

# ─── Configuration ───────────────────────────────────────────────────────────
PRODUCTION_MODE = False


# ─── State Management ─────────────────────────────────────────────────────────

class ConnectionManager:
    """Manages WebSocket connections per user."""

    def __init__(self):
        # user_id → set of WebSocket connections
        self._connections: dict[int, set[WebSocket]] = {}

    async def connect(self, user_id: int, ws: WebSocket):
        await ws.accept()
        self._connections.setdefault(user_id, set()).add(ws)
        logger.info(f"[WS] User #{user_id} connected. Active: {self.count(user_id)}")

    def disconnect(self, user_id: int, ws: WebSocket):
        if user_id in self._connections:
            self._connections[user_id].discard(ws)
            if not self._connections[user_id]:
                del self._connections[user_id]
        logger.info(f"[WS] User #{user_id} disconnected.")

    async def send_to_user(self, user_id: int, payload: dict):
        """Send a JSON message to all connections for a user."""
        dead = set()
        for ws in self._connections.get(user_id, set()):
            try:
                await ws.send_text(json.dumps(payload))
            except Exception:
                dead.add(ws)
        for ws in dead:
            self._connections.get(user_id, set()).discard(ws)

    def count(self, user_id: int) -> int:
        return len(self._connections.get(user_id, set()))

    def is_connected(self, user_id: int) -> bool:
        return self.count(user_id) > 0


ws_manager = ConnectionManager()

# camera_id → (stop_event, user_id)
_scanner_stop_events: dict[int, tuple[asyncio.Event, int]] = {}

# incident_id → asyncio.Task (10-second auto-dispatch timer)
_pending_timers: dict[int, asyncio.Task] = {}


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: create all tables
    models.Base.metadata.create_all(bind=engine)
    logger.info("[Trinetra AI] Database initialized. Server ready.")

    # Restart scanners for all active cameras on reboot
    db = next(get_db())
    try:
        active_cameras = db.query(models.Camera).filter(
            models.Camera.status == models.CameraStatus.active
        ).all()

        for camera in active_cameras:
            user = db.query(models.User).filter(models.User.id == camera.user_id).first()
            _launch_scanner(camera, user)

        logger.info(f"[Trinetra AI] Restored {len(active_cameras)} camera scanner(s).")
    finally:
        db.close()

    yield

    # Shutdown: stop all scanners
    for camera_id, (stop_event, _) in list(_scanner_stop_events.items()):
        mock_cv.stop_scanner(camera_id, stop_event)
    for task in _pending_timers.values():
        task.cancel()
    logger.info("[Trinetra AI] All scanners and timers stopped. Shutdown complete.")


# ─── App Init ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Trinetra AI",
    description="Real-time Smart City & Domestic Hazard Detection System",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Helper: Hazard → Incident → 10s Timer ────────────────────────────────────

async def _auto_dispatch_timer(
    incident_id: int,
    user_id: int,
    location_tag: str,
    hazard_type: str,
    confidence: str,
    user_name: str,
):
    """
    Counts down 10 seconds, sending TIMER_TICK events via WebSocket.
    If not cancelled, auto-dispatches emergency 112 call.
    """
    try:
        for tick in range(10, 0, -1):
            await ws_manager.send_to_user(user_id, {
                "event": "TIMER_TICK",
                "incident_id": incident_id,
                "countdown": tick,
            })
            await asyncio.sleep(1)

        # Timer expired — auto dispatch
        logger.warning(f"[Timer] Incident #{incident_id}: No user response. Auto-dispatching 112.")

        db = next(get_db())
        try:
            incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
            if incident and incident.status == models.IncidentStatus.pending:
                incident.status = models.IncidentStatus.dispatched
                incident.action_taken = models.ActionTaken.auto_called_112
                db.commit()

                call_record = await mock_twilio.dispatch_emergency_call(
                    incident_id=incident_id,
                    location_tag=location_tag,
                    hazard_type=hazard_type,
                    user_name=user_name,
                    confidence=confidence,
                    triggered_by="auto-timer",
                )

                await ws_manager.send_to_user(user_id, {
                    "event": "DISPATCH_CONFIRMED",
                    "incident_id": incident_id,
                    "message": f"Emergency 112 auto-dispatched for {hazard_type} at {location_tag}.",
                    "call_sid": call_record["sid"],
                })
        finally:
            db.close()

    except asyncio.CancelledError:
        logger.info(f"[Timer] Incident #{incident_id}: Timer cancelled by user action.")
    finally:
        _pending_timers.pop(incident_id, None)


async def _handle_hazard_detected(hazard_payload: dict, user_id: int, user_name: str):
    """
    Callback fired by mock_cv scanner. Creates Incident record, starts timer, sends WS alert.
    """
    db = next(get_db())
    try:
        incident = models.Incident(
            camera_id=hazard_payload["camera_id"],
            hazard_type=hazard_payload["hazard_type"],
            location_tag=hazard_payload["location_tag"],
            confidence=hazard_payload["confidence"],
            status=models.IncidentStatus.pending,
            action_taken=models.ActionTaken.pending,
        )
        db.add(incident)
        db.commit()
        db.refresh(incident)

        logger.warning(
            f"[Incident] Created #{incident.id}: {hazard_payload['hazard_type']} "
            f"@ {hazard_payload['location_tag']} for User #{user_id}"
        )

        # Send WebSocket alert to user
        await ws_manager.send_to_user(user_id, {
            "event": "HAZARD_ALERT",
            "incident_id": incident.id,
            "hazard_type": hazard_payload["hazard_type"],
            "location_tag": hazard_payload["location_tag"],
            "camera_id": hazard_payload["camera_id"],
            "device_name": hazard_payload["device_name"],
            "confidence": hazard_payload["confidence"],
            "severity": hazard_payload["severity"],
            "timestamp": hazard_payload["timestamp"],
        })

        # Start 10-second auto-dispatch timer
        timer_task = asyncio.create_task(
            _auto_dispatch_timer(
                incident_id=incident.id,
                user_id=user_id,
                location_tag=hazard_payload["location_tag"],
                hazard_type=hazard_payload["hazard_type"],
                confidence=hazard_payload["confidence"],
                user_name=user_name,
            ),
            name=f"timer-incident-{incident.id}"
        )
        _pending_timers[incident.id] = timer_task

    except Exception as e:
        logger.error(f"[Incident] Failed to handle hazard: {e}")
        db.rollback()
    finally:
        db.close()


def _launch_scanner(camera: models.Camera, user: models.User):
    """Launch a CV scanner for a camera and register the stop event."""
    async def hazard_callback(payload: dict):
        await _handle_hazard_detected(payload, user.id, user.username)

    stop_event = mock_cv.start_scanner(
        camera_id=camera.id,
        device_name=camera.device_name,
        location_tag=camera.location_tag,
        stream_url=camera.stream_url,
        on_hazard_detected=hazard_callback,
    )
    _scanner_stop_events[camera.id] = (stop_event, user.id)


# ─── Auth Routes ──────────────────────────────────────────────────────────────

@app.post("/api/register", response_model=schemas.Token, status_code=201)
@app.post("/auth/register", response_model=schemas.Token, status_code=201)
def register(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.username == payload.username).first():
        raise HTTPException(status_code=400, detail="Username already taken")
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = models.User(
        username=payload.username,
        email=payload.email,
        password_hash=auth_utils.hash_password(payload.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = auth_utils.create_access_token({"sub": str(user.id)})
    return schemas.Token(
        access_token=token,
        token_type="bearer",
        user=schemas.UserOut.model_validate(user),
    )


@app.post("/api/login", response_model=schemas.Token)
@app.post("/auth/login", response_model=schemas.Token)
def login(payload: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == payload.username).first()
    if not user or not auth_utils.verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token = auth_utils.create_access_token({"sub": str(user.id)})
    return schemas.Token(
        access_token=token,
        token_type="bearer",
        user=schemas.UserOut.model_validate(user),
    )


@app.get("/api/me", response_model=schemas.UserOut)
@app.get("/auth/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(auth_utils.get_current_user)):
    return current_user


# ─── Camera Routes ────────────────────────────────────────────────────────────

@app.get("/cameras", response_model=list[schemas.CameraOut])
def list_cameras(
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    return db.query(models.Camera).filter(models.Camera.user_id == current_user.id).all()


@app.post("/cameras", response_model=schemas.CameraOut, status_code=201)
async def register_camera(
    payload: schemas.CameraCreate,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    camera = models.Camera(
        user_id=current_user.id,
        device_name=payload.device_name,
        stream_url=payload.stream_url,
        location_tag=payload.location_tag,
        status=models.CameraStatus.active,
    )
    db.add(camera)
    db.commit()
    db.refresh(camera)

    # Notify user about API engine initialization
    await ws_manager.send_to_user(current_user.id, {
        "event": "CAMERA_INIT",
        "camera_id": camera.id,
        "device_name": camera.device_name,
        "message": f"API engine initializing for '{camera.device_name}' at {camera.location_tag}...",
    })

    # Simulate initialization delay then launch scanner
    async def delayed_start():
        await asyncio.sleep(2.5)  # Simulate edge-AI module boot time
        _launch_scanner(camera, current_user)
        await ws_manager.send_to_user(current_user.id, {
            "event": "CAMERA_READY",
            "camera_id": camera.id,
            "device_name": camera.device_name,
            "message": f"'{camera.device_name}' is now active and monitoring.",
        })

    asyncio.create_task(delayed_start())

    logger.info(f"[Camera] Registered #{camera.id} '{camera.device_name}' for User #{current_user.id}")
    return camera


@app.delete("/cameras/{camera_id}", status_code=204)
def delete_camera(
    camera_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    camera = db.query(models.Camera).filter(
        models.Camera.id == camera_id,
        models.Camera.user_id == current_user.id
    ).first()

    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")

    # Stop scanner
    if camera_id in _scanner_stop_events:
        stop_event, _ = _scanner_stop_events.pop(camera_id)
        mock_cv.stop_scanner(camera_id, stop_event)

    db.delete(camera)
    db.commit()
    logger.info(f"[Camera] Deleted #{camera_id} for User #{current_user.id}")


@app.put("/cameras/{camera_id}/status")
def toggle_camera_status(
    camera_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    camera = db.query(models.Camera).filter(
        models.Camera.id == camera_id,
        models.Camera.user_id == current_user.id
    ).first()

    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")

    if camera.status == models.CameraStatus.active:
        camera.status = models.CameraStatus.inactive
        if camera_id in _scanner_stop_events:
            stop_event, _ = _scanner_stop_events.pop(camera_id)
            mock_cv.stop_scanner(camera_id, stop_event)
    else:
        camera.status = models.CameraStatus.active
        _launch_scanner(camera, current_user)

    db.commit()
    db.refresh(camera)
    return schemas.CameraOut.model_validate(camera)


# ─── Incident Routes ──────────────────────────────────────────────────────────

@app.get("/incidents", response_model=list[schemas.IncidentOut])
def list_incidents(
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.Incident)
        .join(models.Camera)
        .filter(models.Camera.user_id == current_user.id)
        .order_by(models.Incident.triggered_at.desc())
        .limit(100)
        .all()
    )


@app.post("/incidents/{incident_id}/cancel")
async def cancel_incident(
    incident_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    incident = (
        db.query(models.Incident)
        .join(models.Camera)
        .filter(
            models.Incident.id == incident_id,
            models.Camera.user_id == current_user.id,
        )
        .first()
    )

    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    if incident.status != models.IncidentStatus.pending:
        raise HTTPException(status_code=400, detail="Incident is no longer pending")

    # Cancel the auto-dispatch timer
    timer = _pending_timers.pop(incident_id, None)
    if timer:
        timer.cancel()

    incident.status = models.IncidentStatus.cancelled
    incident.action_taken = models.ActionTaken.user_dismissed
    db.commit()

    logger.info(f"[Incident] #{incident_id} cancelled (false alarm) by User #{current_user.id}")
    return {"status": "cancelled", "incident_id": incident_id}


@app.post("/incidents/{incident_id}/confirm")
async def confirm_incident(
    incident_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    incident = (
        db.query(models.Incident)
        .join(models.Camera)
        .filter(
            models.Incident.id == incident_id,
            models.Camera.user_id == current_user.id,
        )
        .first()
    )

    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    if incident.status != models.IncidentStatus.pending:
        raise HTTPException(status_code=400, detail="Incident is no longer pending")

    # Cancel the auto-dispatch timer (we'll dispatch manually now)
    timer = _pending_timers.pop(incident_id, None)
    if timer:
        timer.cancel()

    incident.status = models.IncidentStatus.dispatched
    incident.action_taken = models.ActionTaken.user_confirmed
    db.commit()

    # Dispatch emergency call
    call_record = await mock_twilio.dispatch_emergency_call(
        incident_id=incident_id,
        location_tag=incident.location_tag,
        hazard_type=incident.hazard_type,
        user_name=current_user.username,
        confidence=incident.confidence,
        triggered_by="user-confirmed",
    )

    await ws_manager.send_to_user(current_user.id, {
        "event": "DISPATCH_CONFIRMED",
        "incident_id": incident_id,
        "message": f"Emergency 112 dispatched for {incident.hazard_type} at {incident.location_tag}.",
        "call_sid": call_record["sid"],
    })

    logger.info(f"[Incident] #{incident_id} confirmed & 112 dispatched by User #{current_user.id}")
    return {"status": "dispatched", "incident_id": incident_id, "call_sid": call_record["sid"]}


# ─── Test Endpoint ────────────────────────────────────────────────────────────

@app.post("/api/alerts/test")
@app.post("/test/trigger-alert")
async def trigger_test_alert(
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    """Manually fire a test hazard alert for demo/testing purposes."""
    if PRODUCTION_MODE:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Test alerts are disabled in production mode to prevent accidental 112 calls."
        )

    camera = db.query(models.Camera).filter(
        models.Camera.user_id == current_user.id
    ).first()

    if not camera:
        raise HTTPException(status_code=400, detail="No cameras registered. Add a camera first.")

    test_payload = {
        "camera_id": camera.id,
        "device_name": camera.device_name,
        "location_tag": camera.location_tag,
        "stream_url": camera.stream_url,
        "hazard_type": "🔥 Fire Detected",
        "severity": "CRITICAL",
        "confidence": "97.3%",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "frame_id": 42000,
    }

    await _handle_hazard_detected(test_payload, current_user.id, current_user.username)
    return {"status": "test alert triggered"}


# ─── WebSocket Gateway ────────────────────────────────────────────────────────

@app.websocket("/ws/alerts")
async def websocket_alerts(
    websocket: WebSocket,
    token: Optional[str] = Query(None),
):
    # Authenticate via query param token
    if not token:
        await websocket.close(code=4001, reason="Missing token")
        return

    payload = auth_utils.decode_token(token)
    if not payload:
        await websocket.close(code=4003, reason="Invalid or expired token")
        return

    user_id = int(payload.get("sub", 0))
    db = next(get_db())
    try:
        user = db.query(models.User).filter(models.User.id == user_id).first()
    finally:
        db.close()

    if not user:
        await websocket.close(code=4003, reason="User not found")
        return

    await ws_manager.connect(user_id, websocket)

    # Fetch this user's own camera count for the initial status message
    db_conn = next(get_db())
    try:
        user_camera_count = db_conn.query(models.Camera).filter(
            models.Camera.user_id == user_id
        ).count()
    finally:
        db_conn.close()

    # Send connection confirmation with user-specific camera count
    await websocket.send_text(json.dumps({
        "event": "CONNECTED",
        "message": f"Sentinel grid active. Monitoring {user_camera_count} camera(s).",
        "user": user.username,
        "camera_count": user_camera_count,
    }))

    try:
        # Heartbeat loop — keep connection alive
        while True:
            try:
                # Wait for client message with timeout (heartbeat)
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                msg = json.loads(data)
                if msg.get("type") == "ping":
                    await websocket.send_text(json.dumps({"event": "PONG"}))
            except asyncio.TimeoutError:
                # Send server heartbeat with per-user camera count
                db_hb = next(get_db())
                try:
                    user_cam_count = db_hb.query(models.Camera).filter(
                        models.Camera.user_id == user_id
                    ).count()
                finally:
                    db_hb.close()
                await websocket.send_text(json.dumps({
                    "event": "HEARTBEAT",
                    "active_scanners": user_cam_count,
                    "camera_count": user_cam_count,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }))
    except WebSocketDisconnect:
        ws_manager.disconnect(user_id, websocket)
    except Exception as e:
        logger.error(f"[WS] Unexpected error for User #{user_id}: {e}")
        ws_manager.disconnect(user_id, websocket)


# ─── Health Check ─────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {
        "status": "operational",
        "service": "Trinetra AI",
        "active_scanners": mock_cv.get_active_scanner_count(),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
