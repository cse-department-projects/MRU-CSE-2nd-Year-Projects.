"""Verifies the camera count fix: DB starts at 0, count updates in real-time."""
import urllib.request, urllib.error, json, time

BASE = 'http://localhost:8000'

def post(url, data, token=None):
    req = urllib.request.Request(
        url, data=json.dumps(data).encode(),
        headers={'Content-Type': 'application/json'}, method='POST')
    if token:
        req.add_header('Authorization', 'Bearer ' + token)
    try:
        r = urllib.request.urlopen(req)
        return json.loads(r.read()), r.status
    except urllib.error.HTTPError as e:
        return json.loads(e.read()), e.code

def get(url, token=None):
    req = urllib.request.Request(url)
    if token:
        req.add_header('Authorization', 'Bearer ' + token)
    return json.loads(urllib.request.urlopen(req).read())

ok = True

def check(label, cond, note=''):
    global ok
    mark = 'PASS' if cond else 'FAIL'
    if not cond:
        ok = False
    suffix = '  (' + note + ')' if note else ''
    print('  [' + mark + '] ' + label + suffix)

print('=' * 58)
print('  CAMERA COUNT FIX -- Verification')
print('=' * 58)

# Step 1: Login
print('\n[1] Login')
res, code = post(BASE + '/api/login', {'username': 'testop', 'password': 'sentinel123'})
check('/api/login -> 200', code == 200, 'status ' + str(code))
token = res.get('access_token', '')
print('     user=' + str(res.get('user', {}).get('username')))

# Step 2: Cameras should be 0 (clean DB)
print('\n[2] Cameras before registration')
cams = get(BASE + '/cameras', token)
check('cameras.length == 0 on fresh DB', len(cams) == 0, 'got ' + str(len(cams)))
print('     StatusBar widget shows: Monitoring ' + str(len(cams)) + ' cameras')

# Step 3: Register a camera
print('\n[3] Register a camera')
cam, ccode = post(BASE + '/cameras',
    {'device_name': 'Front Door Cam', 'location_tag': 'Entrance', 'stream_url': 'rtsp://192.168.1.1/cam1'},
    token)
check('/cameras POST -> 201', ccode == 201, 'status ' + str(ccode))
print('     id=' + str(cam.get('id')) + ' | name=' + str(cam.get('device_name')))

# Step 4: cameras.length should now be 1
print('\n[4] Cameras after registration')
cams2 = get(BASE + '/cameras', token)
check('cameras.length == 1 after register', len(cams2) == 1, 'got ' + str(len(cams2)))
print('     StatusBar widget now shows: Monitoring ' + str(len(cams2)) + ' camera')

# Step 5: Health shows 1 active scanner
print('\n[5] Health / active scanners')
h = get(BASE + '/health')
check('active_scanners == 1', h.get('active_scanners') == 1, 'got ' + str(h.get('active_scanners')))
print('     active_scanners=' + str(h.get('active_scanners')))

# Step 6: Test alert now works (camera exists)
print('\n[6] Test alert (camera registered)')
time.sleep(0.3)
alert, acode = post(BASE + '/api/alerts/test', {}, token)
check('/api/alerts/test -> 200', acode == 200, 'status ' + str(acode) + ': ' + str(alert))

print()
print('=' * 58)
print('  ALL CHECKS PASSED' if ok else '  SOME CHECKS FAILED')
print('=' * 58)
print()
print('  Fix summary:')
print('  1. DB wiped of 3 stale test cameras -> starts at 0')
print('  2. StatusBar.jsx reads cameras.length (not global scanners)')
print('  3. Dashboard passes cameraCount={cameras.length} to StatusBar')
print('  4. Backend CONNECTED/HEARTBEAT sends per-user count')
print()
print('  Frontend: http://localhost:5173')
print('  Backend:  http://localhost:8000')
