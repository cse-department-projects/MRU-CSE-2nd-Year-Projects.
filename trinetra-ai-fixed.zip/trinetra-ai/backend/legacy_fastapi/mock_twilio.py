"""
mock_twilio.py — Simulated Twilio Voice API Emergency Dispatch Gateway.
Simulates placing an automated voice call to 112 (national emergency number).
In production, replace with actual Twilio Voice API calls.
"""

import asyncio
import logging
from datetime import datetime, timezone

logger = logging.getLogger("trinetra.twilio")

# Mock call registry for audit trail
_dispatched_calls: list[dict] = []


async def dispatch_emergency_call(
    incident_id: int,
    location_tag: str,
    hazard_type: str,
    user_name: str,
    confidence: str = "94.7%",
    triggered_by: str = "auto"
) -> dict:
    """
    Simulate dispatching an emergency voice call to 112.

    In production this would call:
        client = twilio.rest.Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        call = client.calls.create(
            twiml=f'<Response><Say>Emergency: {hazard_type} at {location_tag}. Dispatching responders.</Say></Response>',
            to="+91112",
            from_=TWILIO_PHONE_NUMBER
        )
    """
    # Simulate network latency for the API call
    await asyncio.sleep(0.8)

    mock_sid = f"MOCK-SID-{incident_id}-{int(datetime.now(timezone.utc).timestamp())}"
    timestamp = datetime.now(timezone.utc).isoformat()

    call_record = {
        "sid": mock_sid,
        "incident_id": incident_id,
        "emergency_number": "112",
        "location": location_tag,
        "hazard_type": hazard_type,
        "reported_by": user_name,
        "confidence": confidence,
        "triggered_by": triggered_by,
        "status": "COMPLETED",
        "duration_seconds": 14,
        "timestamp": timestamp,
        "message": (
            f"Trinetra AI Emergency Alert: {hazard_type} detected at {location_tag} "
            f"with {confidence} confidence. Auto-dispatched to 112. Incident #{incident_id}."
        )
    }

    _dispatched_calls.append(call_record)

    logger.warning(
        f"[MOCK 112 DISPATCH] Incident #{incident_id} | {hazard_type} @ {location_tag} | "
        f"SID: {mock_sid} | Triggered by: {triggered_by}"
    )

    return call_record


def get_dispatch_log() -> list[dict]:
    """Return all dispatched call records for audit purposes."""
    return _dispatched_calls
