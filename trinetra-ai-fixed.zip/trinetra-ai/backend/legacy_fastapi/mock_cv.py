"""
mock_cv.py — Mock YOLOv8 / OpenCV Computer Vision Scanner.

Simulates the output of a real-time object detection pipeline running on
RTSP/HTTP camera streams. In production, this would be replaced with:
    - Ultralytics YOLOv8 inference on decoded video frames
    - OpenCV frame capture via cv2.VideoCapture(stream_url)
    - GPU-accelerated CUDA inference

NOTE (v1.1 — Simulator Disabled):
    The autonomous random hazard generation loop has been intentionally
    removed. The scanner coroutine now runs as a passive stream-health
    monitor only. All hazard events must be injected via the manual
    test endpoint (when PRODUCTION_MODE = False) or by the real
    computer-vision inference layer in a production deployment.
"""

import asyncio
import random
import logging
from datetime import datetime, timezone
from typing import Callable, Awaitable

logger = logging.getLogger("trinetra.cv")

# ─── Hazard catalogue (used by manual test endpoint only) ─────────────────────

HAZARD_TYPES = [
    {"type": "🔥 Fire Detected",       "weight": 25, "severity": "CRITICAL"},
    {"type": "💨 Smoke Detected",       "weight": 30, "severity": "HIGH"},
    {"type": "🔫 Firearm / Intrusion",  "weight": 15, "severity": "CRITICAL"},
    {"type": "💥 Collision / Impact",   "weight": 20, "severity": "HIGH"},
    {"type": "⚠️ Unauthorized Access",  "weight": 10, "severity": "CRITICAL"},
]

# Confidence range used only when building a manual test payload
CONFIDENCE_RANGE = (88.2, 99.8)

# How often the passive stream-health loop checks the stop_event (seconds).
# This is NOT a hazard scan interval — no hazard logic runs here anymore.
STREAM_HEALTH_POLL_INTERVAL = 10.0

# Track active scanner tasks: camera_id -> asyncio.Task
_active_scanners: dict[int, asyncio.Task] = {}


# ─── Helpers (retained for use by the manual test endpoint) ───────────────────

def get_mock_confidence() -> str:
    """Return a plausible detection confidence string."""
    return f"{random.uniform(*CONFIDENCE_RANGE):.1f}%"


def pick_hazard() -> dict:
    """Pick a random hazard type weighted by rarity (for manual tests only)."""
    weights = [h["weight"] for h in HAZARD_TYPES]
    return random.choices(HAZARD_TYPES, weights=weights, k=1)[0]


# ─── Passive stream-health monitor ───────────────────────────────────────────

async def run_camera_scanner(
    camera_id: int,
    device_name: str,
    location_tag: str,
    stream_url: str,
    on_hazard_detected: Callable[[dict], Awaitable[None]],   # kept in signature for API compat
    stop_event: asyncio.Event,
):
    """
    Passive stream-health coroutine.

    Keeps the scanner slot alive so that:
      - The WebSocket HEARTBEAT can report an accurate active_scanners count.
      - Camera status toggling (active / inactive) still works correctly.
      - A future real CV inference layer can be dropped in here without
        any changes to main.py.

    IMPORTANT: This coroutine no longer generates any hazard events on its
    own. The `on_hazard_detected` callback is intentionally never invoked
    from within this loop. Hazard events are injected exclusively via
    POST /test/trigger-alert (when PRODUCTION_MODE = False) or by
    external real-time inference results.
    """
    logger.info(
        f"[CV Scanner] Stream monitor started for Camera #{camera_id} "
        f"'{device_name}' @ {location_tag}  |  URL: {stream_url}"
    )

    # Simulate stream initialization latency (kept for realism)
    await asyncio.sleep(random.uniform(0.5, 2.0))

    # ── Passive health-poll loop ──────────────────────────────────────────────
    # Wakes up every STREAM_HEALTH_POLL_INTERVAL seconds solely to check
    # whether the stop_event has been set. No hazard logic executes here.
    while not stop_event.is_set():
        try:
            await asyncio.sleep(STREAM_HEALTH_POLL_INTERVAL)

            if stop_event.is_set():
                break

            # Stream-health log (debug level — won't flood production logs)
            logger.debug(
                f"[CV Scanner] Camera #{camera_id} stream health OK "
                f"@ {datetime.now(timezone.utc).strftime('%H:%M:%S')} UTC"
            )

        except asyncio.CancelledError:
            logger.info(f"[CV Scanner] Camera #{camera_id} monitor cancelled.")
            break
        except Exception as exc:
            logger.error(f"[CV Scanner] Camera #{camera_id} monitor error: {exc}")
            await asyncio.sleep(2.0)  # Brief back-off before resuming health poll

    logger.info(f"[CV Scanner] Stream monitor stopped for Camera #{camera_id}.")


# ─── Lifecycle helpers ────────────────────────────────────────────────────────

def start_scanner(
    camera_id: int,
    device_name: str,
    location_tag: str,
    stream_url: str,
    on_hazard_detected: Callable[[dict], Awaitable[None]],
) -> asyncio.Event:
    """
    Spawn a passive stream-health monitor for a camera.
    Returns the stop_event used to halt the monitor cleanly.
    """
    stop_event = asyncio.Event()

    task = asyncio.create_task(
        run_camera_scanner(
            camera_id=camera_id,
            device_name=device_name,
            location_tag=location_tag,
            stream_url=stream_url,
            on_hazard_detected=on_hazard_detected,
            stop_event=stop_event,
        ),
        name=f"scanner-camera-{camera_id}",
    )

    _active_scanners[camera_id] = task
    logger.info(f"[CV Scanner] Monitor registered for Camera #{camera_id}.")
    return stop_event


def stop_scanner(camera_id: int, stop_event: asyncio.Event) -> None:
    """Signal a stream monitor to stop and cancel its asyncio task."""
    stop_event.set()
    task = _active_scanners.pop(camera_id, None)
    if task and not task.done():
        task.cancel()
    logger.info(f"[CV Scanner] Stop signal sent for Camera #{camera_id}.")


def get_active_scanner_count() -> int:
    """Return the number of currently active stream monitors."""
    return len(_active_scanners)
