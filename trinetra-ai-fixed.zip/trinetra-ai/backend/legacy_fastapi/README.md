# legacy_fastapi — NOT USED

This is the first version of the backend (FastAPI + SQLite + mock CV / mock Twilio).
It was replaced by `backend-express/` (Express + MySQL) and the CV engine in `backend/`.

Nothing in `start.bat` runs it, and the dashboard does not talk to it. It is kept only as a
reference — you can delete this folder. If you ever run it, set `SECRET_KEY` in the environment first.
