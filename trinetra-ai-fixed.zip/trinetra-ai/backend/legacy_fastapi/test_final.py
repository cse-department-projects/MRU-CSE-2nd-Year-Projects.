"""
Final integration test for Trinetra AI - Fixed version.
Tests all /api/* routes using the testop user who already has cameras.
"""
import urllib.request, urllib.error, json, sys

BASE = 'http://localhost:8000'
ORIGIN = 'http://localhost:5173'

def post(url, data=None, token=None, origin=None):
    req = urllib.request.Request(
        url,
        data=json.dumps(data or {}).encode('utf-8'),
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    if token:
        req.add_header('Authorization', f'Bearer {token}')
    if origin:
        req.add_header('Origin', origin)
    try:
        r = urllib.request.urlopen(req)
        return json.loads(r.read().decode('utf-8')), r.status
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode('utf-8'))
        except Exception:
            body = {'raw': str(e)}
        return body, e.code

def get(url, token=None, origin=None):
    req = urllib.request.Request(url)
    if token:
        req.add_header('Authorization', f'Bearer {token}')
    if origin:
        req.add_header('Origin', origin)
    r = urllib.request.urlopen(req)
    return json.loads(r.read().decode('utf-8'))

ok = True
def check(label, condition, note=''):
    global ok
    mark = 'PASS' if condition else 'FAIL'
    if not condition:
        ok = False
    suffix = f'  ({note})' if note and not condition else (f'  ({note})' if note else '')
    print(f'  [{mark}] {label}{suffix}')

print('=' * 62)
print('  TRINETRA AI -- Final Integration Test')
print('=' * 62)

# 1. Health
print('\n[1] Health check')
h = get(f'{BASE}/health')
check('/health returns operational', h.get('status') == 'operational')
print(f'     active_scanners={h.get("active_scanners")} | ts={str(h.get("timestamp",""))[:19]}')

# 2. Login via /api/login (existing testop user)
print('\n[2] POST /api/login (testop)')
res, code = post(f'{BASE}/api/login', {'username': 'testop', 'password': 'sentinel123'}, origin=ORIGIN)
check('/api/login -> 200', code == 200, f'status {code}')
token = res.get('access_token', '')
print(f'     token_type={res.get("token_type")} | user={res.get("user",{}).get("username")}')

# 3. GET /api/me
print('\n[3] GET /api/me')
me = get(f'{BASE}/api/me', token, ORIGIN)
check('/api/me returns username', 'username' in me)
print(f'     username={me.get("username")} | email={me.get("email")}')

# 4. CORS preflight
print('\n[4] CORS Allow-Origin header on /api/login')
req = urllib.request.Request(f'{BASE}/api/login', method='OPTIONS')
req.add_header('Origin', ORIGIN)
req.add_header('Access-Control-Request-Method', 'POST')
req.add_header('Access-Control-Request-Headers', 'content-type,authorization')
try:
    r = urllib.request.urlopen(req)
    acao = r.headers.get('Access-Control-Allow-Origin', '')
    check('CORS Allow-Origin = http://localhost:5173', acao == ORIGIN, acao)
except urllib.error.HTTPError as e:
    acao = e.headers.get('Access-Control-Allow-Origin', '')
    check('CORS Allow-Origin present', bool(acao), f'HTTP {e.code} | header={acao or "MISSING"}')

# 5. List cameras (testop already has cameras registered)
print('\n[5] GET /cameras')
cams = get(f'{BASE}/cameras', token)
check('Cameras list returned', isinstance(cams, list))
print(f'     {len(cams)} camera(s) registered for testop')
if cams:
    print(f'     First: id={cams[0].get("id")} | {cams[0].get("device_name")} @ {cams[0].get("location_tag")}')

# 6. POST /api/alerts/test  (PRODUCTION_MODE = False -> 200)
print('\n[6] POST /api/alerts/test  [PRODUCTION_MODE=False]')
alert_res, alert_code = post(f'{BASE}/api/alerts/test', {}, token, ORIGIN)
check('/api/alerts/test -> 200', alert_code == 200, f'status {alert_code}: {alert_res}')
print(f'     status={alert_code} | {alert_res}')

# 7. Incidents after alert
import time; time.sleep(1.2)
print('\n[7] GET /incidents')
incs = get(f'{BASE}/incidents', token)
check('Incidents list returned', isinstance(incs, list))
print(f'     {len(incs)} incident(s) on record')
if incs:
    i = incs[0]
    hz = i.get("hazard_type","").encode("ascii","replace").decode("ascii")
    print(f'     Latest: [{i.get("status","").upper()}] {hz} @ {i.get("location_tag")} | {i.get("confidence")}')

# 8. Legacy /auth/login still works
print('\n[8] POST /auth/login  [legacy alias]')
res2, code2 = post(f'{BASE}/auth/login', {'username': 'testop', 'password': 'sentinel123'})
check('/auth/login -> 200', code2 == 200, f'status {code2}')

# Summary
print()
print('=' * 62)
print('  ALL TESTS PASSED' if ok else '  SOME TESTS FAILED -- see [FAIL] above')
print('=' * 62)
print()
print('  Frontend : http://localhost:5173')
print('  Backend  : http://localhost:8000')
print('  API Docs : http://localhost:8000/docs')
sys.exit(0 if ok else 1)
