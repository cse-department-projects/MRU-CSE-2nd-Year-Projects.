from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
import enum

from database import Base


class CameraStatus(str, enum.Enum):
    active = "active"
    inactive = "inactive"


class IncidentStatus(str, enum.Enum):
    pending = "pending"
    dispatched = "dispatched"
    cancelled = "cancelled"


class ActionTaken(str, enum.Enum):
    auto_called_112 = "Auto-Called 112"
    user_confirmed = "User Confirmed & Called 112"
    user_dismissed = "User Dismissed"
    pending = "Pending"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    cameras = relationship("Camera", back_populates="owner", cascade="all, delete-orphan")


class Camera(Base):
    
    __tablename__ = "cameras"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    device_name = Column(String, nullable=False)
    stream_url = Column(String, nullable=False)
    location_tag = Column(String, nullable=False)
    status = Column(SAEnum(CameraStatus), default=CameraStatus.active)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    owner = relationship("User", back_populates="cameras")
    incidents = relationship("Incident", back_populates="camera", cascade="all, delete-orphan")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False)
    hazard_type = Column(String, nullable=False)
    status = Column(SAEnum(IncidentStatus), default=IncidentStatus.pending)
    triggered_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    action_taken = Column(SAEnum(ActionTaken), default=ActionTaken.pending)
    location_tag = Column(String, nullable=False)
    confidence = Column(String, default="94.7%")

    camera = relationship("Camera", back_populates="incidents")
