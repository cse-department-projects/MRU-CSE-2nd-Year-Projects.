from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from enum import Enum


# ─── Auth Schemas ────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    email: str
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserOut


# ─── Camera Schemas ───────────────────────────────────────────────────────────

class CameraCreate(BaseModel):
    device_name: str
    stream_url: str
    location_tag: str


class CameraOut(BaseModel):
    id: int
    device_name: str
    stream_url: str
    location_tag: str
    status: str
    created_at: datetime
    user_id: int

    class Config:
        from_attributes = True


# ─── Incident Schemas ─────────────────────────────────────────────────────────

class IncidentOut(BaseModel):
    id: int
    camera_id: int
    hazard_type: str
    status: str
    triggered_at: datetime
    action_taken: str
    location_tag: str
    confidence: str

    class Config:
        from_attributes = True


# ─── WebSocket Payload ────────────────────────────────────────────────────────

class AlertPayload(BaseModel):
    event: str                   # "HAZARD_ALERT" | "HEARTBEAT" | "TIMER_TICK" | "DISPATCH_CONFIRMED"
    incident_id: Optional[int] = None
    hazard_type: Optional[str] = None
    location_tag: Optional[str] = None
    camera_id: Optional[int] = None
    device_name: Optional[str] = None
    confidence: Optional[str] = None
    countdown: Optional[int] = None
    timestamp: Optional[str] = None
    message: Optional[str] = None
