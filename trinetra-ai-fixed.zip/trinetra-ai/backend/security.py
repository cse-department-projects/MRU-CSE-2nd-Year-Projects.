"""
security.py — small, dependency-free security helpers for the CV engine.
"""

from __future__ import annotations

import hmac
import re
from typing import Optional

# user:password@ inside a URL, e.g. rtsp://admin:hunter2@192.168.1.10/stream
_CREDENTIALS = re.compile(r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.\-]*://)(?P<creds>[^/@\s]+)@")


def mask_url(url: Optional[str]) -> str:
    """Hide credentials in a stream URL so they never reach logs or API responses."""
    if not url:
        return ""
    return _CREDENTIALS.sub(r"\g<scheme>***:***@", url)


def mask_text(text: str) -> str:
    """Same as mask_url, for free-form messages that embed a URL."""
    return _CREDENTIALS.sub(r"\g<scheme>***:***@", text)


def safe_equal(provided: Optional[str], expected: str) -> bool:
    """Constant-time comparison. False when either side is empty."""
    if not provided or not expected:
        return False
    return hmac.compare_digest(provided.encode(), expected.encode())
