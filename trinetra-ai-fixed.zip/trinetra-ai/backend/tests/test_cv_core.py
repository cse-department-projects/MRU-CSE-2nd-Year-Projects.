"""
Tests for the CV engine core (no FastAPI / camera hardware needed).

Run from the backend/ folder:
    python -m unittest discover -s tests -v
"""

import json
import os
import sys
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["INTERNAL_API_KEY"] = "k" * 64

import numpy as np  # noqa: E402

import config  # noqa: E402
from alert_forwarder import AlertForwarder  # noqa: E402
from cv_inference import (  # noqa: E402
    HazardType, InferenceConfig, InferencePipeline, InferenceResult, _classify_hazard, detector_mode,
)
from security import mask_text, mask_url, safe_equal  # noqa: E402


# ── helpers ───────────────────────────────────────────────────────────────────
class FlickerSource:
    """Frame source alternating black / white -> motion score ~1.0 on every frame."""
    def __init__(self):
        self.i = 0

    def __call__(self, timeout=0.1):
        self.i += 1
        time.sleep(0.002)
        value = 0 if self.i % 2 else 255
        return np.full((48, 64, 3), value, dtype=np.uint8)


def make_pipeline(on_alert=None):
    cfg = InferenceConfig(camera_id=7, inference_fps=500.0, encode_frames=False, detection_threshold=0.75)
    return InferencePipeline(cfg, frame_source=FlickerSource(), on_alert=on_alert)


class StubExpress:
    """Local HTTP server standing in for Express' /api/internal/alerts."""
    def __init__(self, statuses):
        self.statuses = list(statuses)
        self.calls = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                outer.calls.append({"path": self.path, "key": self.headers.get("X-Internal-Key"),
                                    "body": json.loads(body)})
                code = outer.statuses.pop(0) if outer.statuses else 201
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b"{}")

            def log_message(self, *a):
                pass

        self.httpd = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def wait_until(cond, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


def fake_result(camera_id=1, hazard=HazardType.FIRE, confidence=0.9):
    return InferenceResult(camera_id=camera_id, timestamp=time.time(), hazard=hazard,
                           confidence=confidence, motion_score=0.5, alert=True)


# ── security helpers ──────────────────────────────────────────────────────────
class SecurityTests(unittest.TestCase):
    def test_mask_url_hides_credentials(self):
        self.assertEqual(mask_url("rtsp://admin:hunter2@192.168.1.10:554/s1"), "rtsp://***:***@192.168.1.10:554/s1")
        self.assertEqual(mask_url("rtsp://192.168.1.10/s1"), "rtsp://192.168.1.10/s1")
        self.assertEqual(mask_url(None), "")

    def test_mask_text_inside_messages(self):
        out = mask_text("could not open rtsp://u:p@host/x (timeout)")
        self.assertNotIn("u:p", out)
        self.assertIn("rtsp://***:***@host/x", out)

    def test_safe_equal(self):
        self.assertTrue(safe_equal("abc", "abc"))
        self.assertFalse(safe_equal("abc", "abd"))
        self.assertFalse(safe_equal("", ""))        # empty never matches
        self.assertFalse(safe_equal(None, "abc"))
        self.assertFalse(safe_equal("abc", ""))


# ── detector honesty ──────────────────────────────────────────────────────────
class DetectorTests(unittest.TestCase):
    def setUp(self):
        self._orig = config.SIMULATE_DETECTIONS

    def tearDown(self):
        config.SIMULATE_DETECTIONS = self._orig

    def test_default_is_off_and_never_alerts(self):
        self.assertFalse(config.SIMULATE_DETECTIONS, "must default to OFF")
        config.SIMULATE_DETECTIONS = False
        self.assertEqual(detector_mode(), "none")
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        for score in (0.0, 0.01, 0.5, 1.0):
            self.assertEqual(_classify_hazard(frame, score)[0], HazardType.NONE)

    def test_pipeline_raises_no_alerts_without_a_model(self):
        config.SIMULATE_DETECTIONS = False
        alerts = []
        p = make_pipeline(on_alert=alerts.append)
        p.start()
        self.assertTrue(wait_until(lambda: p.results_produced > 30))
        p.stop()
        self.assertEqual(alerts, [])

    def test_simulation_mode_is_explicit_opt_in(self):
        config.SIMULATE_DETECTIONS = True
        self.assertEqual(detector_mode(), "simulated")
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        with mock.patch("cv_inference.random.random", return_value=0.9):
            hazard, conf, bbox = _classify_hazard(frame, 1.0)
        self.assertNotEqual(hazard, HazardType.NONE)
        self.assertGreaterEqual(conf, 0.75)
        self.assertIsNotNone(bbox)


# ── result delivery (the "stolen alerts" bug) ─────────────────────────────────
class ResultDeliveryTests(unittest.TestCase):
    def test_multiple_readers_each_see_every_result(self):
        p = make_pipeline()
        p.start()
        try:
            seen = {"a": [], "b": []}
            last = {"a": 0, "b": 0}
            end = time.time() + 1.0
            while time.time() < end:
                for name in ("a", "b"):
                    result, seq = p.get_latest(last[name], timeout=0.05)
                    if result is not None:
                        seen[name].append(seq)
                        last[name] = seq
            self.assertGreater(len(seen["a"]), 5)
            self.assertGreater(len(seen["b"]), 5)
            # strictly increasing -> no duplicates, nothing re-delivered
            for name in seen:
                self.assertEqual(seen[name], sorted(set(seen[name])))
        finally:
            p.stop()

    def test_get_result_does_not_consume(self):
        p = make_pipeline()
        p.start()
        try:
            self.assertTrue(wait_until(lambda: p.get_result(0.05) is not None))
            first = p.get_result(0.0)
            second = p.get_result(0.0)
            self.assertIsNotNone(first)
            self.assertIsNotNone(second)     # old queue-based version would have emptied here
        finally:
            p.stop()

    def test_snapshot_style_read_does_not_steal_from_stream_reader(self):
        p = make_pipeline()
        p.start()
        try:
            self.assertTrue(wait_until(lambda: p.results_produced > 3))
            last = 0
            got = 0
            end = time.time() + 0.8
            while time.time() < end:
                p.get_result(0.0)                                  # "snapshot" hammering the pipeline
                result, seq = p.get_latest(last, timeout=0.05)     # live stream reader
                if result is not None:
                    got += 1
                    last = seq
            self.assertGreater(got, 5)
        finally:
            p.stop()

    def test_stop_wakes_waiting_readers(self):
        p = make_pipeline()
        p.start()
        p.stop()
        t0 = time.time()
        result, seq = p.get_latest(10**9, timeout=3.0)
        self.assertLess(time.time() - t0, 1.0)
        self.assertIsNone(result)


# ── forwarding to Express ─────────────────────────────────────────────────────
class ForwarderTests(unittest.TestCase):
    def test_posts_with_key_and_applies_cooldown(self):
        srv = StubExpress([201])
        f = AlertForwarder(srv.url, "k" * 64, cooldown_seconds=60, retry_delay_seconds=0.01)
        f.start()
        try:
            self.assertTrue(f.submit(fake_result(camera_id=3)))
            for _ in range(20):                                   # a flood of per-frame alerts
                self.assertFalse(f.submit(fake_result(camera_id=3)))
            self.assertTrue(f.submit(fake_result(camera_id=4)))   # other camera is independent
            self.assertTrue(wait_until(lambda: f.sent == 2))
            self.assertEqual(len(srv.calls), 2)
            call = next(c for c in srv.calls if c["body"]["camera_id"] == 3)
            self.assertEqual(call["path"], "/api/internal/alerts")
            self.assertEqual(call["key"], "k" * 64)
            self.assertEqual(call["body"]["hazard"], "fire")
            self.assertAlmostEqual(call["body"]["confidence"], 0.9)
            self.assertEqual(f.suppressed, 20)
        finally:
            f.stop()
            srv.close()

    def test_retries_transient_server_errors(self):
        srv = StubExpress([500, 500, 201])
        f = AlertForwarder(srv.url, "k" * 64, cooldown_seconds=60, retries=2, retry_delay_seconds=0.01)
        f.start()
        try:
            f.submit(fake_result())
            self.assertTrue(wait_until(lambda: f.sent == 1))
            self.assertEqual(len(srv.calls), 3)
        finally:
            f.stop()
            srv.close()

    def test_does_not_retry_permanent_rejections_and_allows_retry_soon(self):
        srv = StubExpress([401])
        f = AlertForwarder(srv.url, "k" * 64, cooldown_seconds=60, retries=2,
                           retry_delay_seconds=0.01, failure_cooldown_seconds=0.2)
        f.start()
        try:
            f.submit(fake_result(camera_id=9))
            self.assertTrue(wait_until(lambda: f.failed == 1))
            self.assertEqual(len(srv.calls), 1, "401 is permanent - must not hammer Express")
            # cooldown was shortened so the next detection isn't swallowed for the full 60 s
            self.assertFalse(f.submit(fake_result(camera_id=9)), "still inside the short post-failure window")
            self.assertTrue(wait_until(lambda: f.submit(fake_result(camera_id=9)), timeout=2.0))
        finally:
            f.stop()
            srv.close()

    def test_unreachable_express_fails_gracefully(self):
        f = AlertForwarder("http://127.0.0.1:1", "k" * 64, cooldown_seconds=60,
                           timeout_seconds=0.5, retries=1, retry_delay_seconds=0.01)
        f.start()
        try:
            f.submit(fake_result())
            self.assertTrue(wait_until(lambda: f.failed == 1, timeout=8))
        finally:
            f.stop()

    def test_without_key_nothing_is_sent(self):
        srv = StubExpress([201])
        f = AlertForwarder(srv.url, "", cooldown_seconds=60)
        f.start()
        try:
            self.assertFalse(f.submit(fake_result()))
            time.sleep(0.2)
            self.assertEqual(srv.calls, [])
        finally:
            f.stop()
            srv.close()


# ── RTSP open path ────────────────────────────────────────────────────────────
class RtspOpenTests(unittest.TestCase):
    def test_unreachable_stream_raises_quickly_and_masks_credentials(self):
        from rtsp_capture import RTSPConfig, _open_capture
        cfg = RTSPConfig(stream_url="rtsp://admin:s3cret@127.0.0.1:9/live", camera_id=5)
        t0 = time.time()
        with self.assertRaises(ConnectionError) as ctx:
            _open_capture(cfg)
        self.assertLess(time.time() - t0, 15, "open timeout must apply at open time")
        self.assertNotIn("s3cret", str(ctx.exception))
        self.assertIn("***:***@", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
