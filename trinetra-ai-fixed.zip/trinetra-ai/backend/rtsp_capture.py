"""
rtsp_capture.py — Production-grade RTSP stream capture engine.

Features:
  - Forces TCP transport via FFmpeg options (prevents UDP packet loss on Windows/Linux)
  - Explicit open/read timeouts to prevent event-loop blocking
  - Exponential-backoff auto-reconnect (capped at 60 s)
  - Thread-safe frame queue consumed by the inference pipeline
  - Graceful shutdown via threading.Event
  - Detailed logging at every failure point
"""

from __future__ import annotations

import logging
import os
import time
import threading
import queue
from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np

from security import mask_url, mask_text

# ── Force TCP transport globally BEFORE any VideoCapture is created ──────────
# This is the single most important line for RTSP reliability on Windows/Linux.
# UDP (the default) causes silent packet loss; TCP is reliable but slightly slower.
os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp"

logger = logging.getLogger("trinetra.rtsp")


# ─────────────────────────────────────────────────────────────────────────────
# Configuration dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RTSPConfig:
    """
    All tunable parameters for a single RTSP capture session.

    Attributes:
        stream_url:         Full RTSP URL, e.g. "rtsp://user:pass@192.168.1.10:554/stream1"
        camera_id:          Unique integer identifier (used for logging and WebSocket routing)
        open_timeout_ms:    Max milliseconds to wait for the stream to open (default 5 s)
        read_timeout_ms:    Max milliseconds to wait for a single frame read (default 5 s)
        frame_queue_size:   Internal frame-buffer depth; older frames are dropped when full
        reconnect_base_s:   Initial reconnect delay in seconds (doubles on each failure)
        reconnect_max_s:    Hard ceiling on reconnect delay (seconds)
        target_fps:         Desired capture frame rate (caps CPU usage on high-FPS cameras)
    """
    stream_url: str
    camera_id: int
    open_timeout_ms: int = 5_000
    read_timeout_ms: int = 5_000
    frame_queue_size: int = 4        # small — we want the latest frame, not old ones
    reconnect_base_s: float = 2.0
    reconnect_max_s: float = 60.0
    target_fps: float = 10.0


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _open_capture(cfg: RTSPConfig) -> cv2.VideoCapture:
    """
    Open an RTSP stream and set all required capture properties.

    Raises:
        ConnectionError: if the stream cannot be opened within the timeout.
    """
    # CAP_FFMPEG backend — required for RTSP on all platforms.
    # The timeouts must be passed AT OPEN time: VideoCapture() starts connecting
    # inside its constructor, so setting them afterwards (as before) cannot
    # stop an unreachable camera from blocking the thread. Older OpenCV builds
    # don't accept the params list, hence the fallback.
    try:
        cap = cv2.VideoCapture(
            cfg.stream_url,
            cv2.CAP_FFMPEG,
            [
                cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, int(cfg.open_timeout_ms),
                cv2.CAP_PROP_READ_TIMEOUT_MSEC, int(cfg.read_timeout_ms),
            ],
        )
    except TypeError:
        cap = cv2.VideoCapture(cfg.stream_url, cv2.CAP_FFMPEG)
        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, cfg.open_timeout_ms)
    cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, cfg.read_timeout_ms)

    # Minimal internal buffer — we want near-real-time frames, not buffered ones
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():
        cap.release()   # don't leak a handle on every failed reconnect attempt
        raise ConnectionError(
            f"[Camera #{cfg.camera_id}] Could not open RTSP stream: {mask_url(cfg.stream_url)}"
        )

    logger.info(
        "[Camera #%d] Stream opened | %dx%d @ %.1f fps | URL: %s",
        cfg.camera_id,
        int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
        int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
        cap.get(cv2.CAP_PROP_FPS),
        mask_url(cfg.stream_url),
    )
    return cap


def _classify_cv_error(stream_url: str, e: Exception) -> tuple[int, str]:
    """
    Map a captured exception to an HTTP-style status code + human message.

    Returns:
        (http_status_code, message)
    """
    msg = str(e).lower()
    if "401" in msg or "unauthorized" in msg or "auth" in msg:
        return 401, "RTSP authentication failed — check username/password in URL."
    if "timed out" in msg or "timeout" in msg:
        return 504, f"Stream timed out: {mask_url(stream_url)}"
    if "connection refused" in msg or "no route" in msg:
        return 400, f"RTSP endpoint unreachable: {mask_url(stream_url)}"
    return 503, f"RTSP stream error: {mask_text(str(e))}"


# ─────────────────────────────────────────────────────────────────────────────
# RTSPCapture — the main capture engine
# ─────────────────────────────────────────────────────────────────────────────

class RTSPCapture:
    """
    Manages a single RTSP camera feed in a dedicated background thread.

    The thread continuously reads frames and puts them into a thread-safe
    queue consumed by the inference pipeline. Auto-reconnects with
    exponential backoff on any failure.

    Usage:
        cfg = RTSPConfig(stream_url="rtsp://...", camera_id=1)
        cap = RTSPCapture(cfg)
        cap.start()

        # In your inference loop:
        frame = cap.get_frame(timeout=0.1)

        # On shutdown:
        cap.stop()
    """

    def __init__(self, cfg: RTSPConfig) -> None:
        self._cfg = cfg
        self._stop_event = threading.Event()
        self._frame_q: queue.Queue[np.ndarray] = queue.Queue(maxsize=cfg.frame_queue_size)
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # Observable state
        self.is_connected: bool = False
        self.error_code: int = 0
        self.error_message: str = ""
        self.reconnect_count: int = 0
        self.frames_captured: int = 0

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the background capture thread. Idempotent."""
        with self._lock:
            if self._thread and self._thread.is_alive():
                logger.debug("[Camera #%d] Already running.", self._cfg.camera_id)
                return
            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._capture_loop,
                name=f"rtsp-capture-{self._cfg.camera_id}",
                daemon=True,
            )
            self._thread.start()
            logger.info("[Camera #%d] Capture thread started.", self._cfg.camera_id)

    def stop(self) -> None:
        """Signal the capture thread to stop and wait for it to exit."""
        logger.info("[Camera #%d] Stop requested.", self._cfg.camera_id)
        self._stop_event.set()
        with self._lock:
            if self._thread:
                self._thread.join(timeout=10.0)
                if self._thread.is_alive():
                    logger.warning(
                        "[Camera #%d] Thread did not exit cleanly after 10s.",
                        self._cfg.camera_id,
                    )
                self._thread = None
        self.is_connected = False
        logger.info("[Camera #%d] Capture thread stopped.", self._cfg.camera_id)

    def get_frame(self, timeout: float = 0.1) -> Optional[np.ndarray]:
        """
        Non-blocking frame retrieval from the internal queue.

        Returns the latest frame, or None if no frame is available within
        `timeout` seconds. Old frames are silently dropped when the queue
        is full, so callers always receive near-real-time data.
        """
        try:
            return self._frame_q.get(timeout=timeout)
        except queue.Empty:
            return None

    @property
    def status(self) -> dict:
        """Serialisable status snapshot for health endpoints."""
        return {
            "camera_id": self._cfg.camera_id,
            "stream_url": mask_url(self._cfg.stream_url),
            "connected": self.is_connected,
            "reconnect_count": self.reconnect_count,
            "frames_captured": self.frames_captured,
            "error_code": self.error_code,
            "error_message": self.error_message,
        }

    # ── Internal capture loop ─────────────────────────────────────────────────

    def _capture_loop(self) -> None:
        """
        Main thread body. Opens the stream and reads frames in a tight loop.
        On any failure, releases the capture object and waits before retrying
        with exponential backoff.
        """
        backoff = self._cfg.reconnect_base_s

        while not self._stop_event.is_set():
            cap: Optional[cv2.VideoCapture] = None
            try:
                logger.info(
                    "[Camera #%d] Attempting to open stream (attempt #%d)...",
                    self._cfg.camera_id,
                    self.reconnect_count + 1,
                )
                cap = _open_capture(self._cfg)
                self.is_connected = True
                self.error_code = 0
                self.error_message = ""
                backoff = self._cfg.reconnect_base_s  # reset on successful connect

                self._read_loop(cap)

            except ConnectionError as e:
                code, msg = _classify_cv_error(self._cfg.stream_url, e)
                self._set_error(code, msg)
                logger.error("[Camera #%d] Connection error (%d): %s", self._cfg.camera_id, code, msg)

            except Exception as e:
                code, msg = _classify_cv_error(self._cfg.stream_url, e)
                self._set_error(code, msg)
                logger.error("[Camera #%d] Unexpected error: %s", self._cfg.camera_id, mask_text(str(e)), exc_info=True)

            finally:
                # ALWAYS release — prevents RTSP session leaks and file-handle exhaustion
                if cap is not None:
                    cap.release()
                    logger.debug("[Camera #%d] VideoCapture released.", self._cfg.camera_id)
                self.is_connected = False

            if self._stop_event.is_set():
                break

            # Exponential backoff before reconnect
            self.reconnect_count += 1
            logger.info(
                "[Camera #%d] Reconnecting in %.1f s (attempt #%d)...",
                self._cfg.camera_id,
                backoff,
                self.reconnect_count,
            )
            self._stop_event.wait(timeout=backoff)
            backoff = min(backoff * 2, self._cfg.reconnect_max_s)

        logger.info("[Camera #%d] Capture loop exited.", self._cfg.camera_id)

    def _read_loop(self, cap: cv2.VideoCapture) -> None:
        """
        Inner frame-reading loop. Exits when the stream drops or stop is requested.
        Throttles to `target_fps` to prevent CPU saturation on high-FPS cameras.
        """
        frame_interval = 1.0 / max(self._cfg.target_fps, 1.0)
        consecutive_failures = 0
        max_consecutive_failures = 30  # ~3 s at 10 fps before treating as disconnect

        while not self._stop_event.is_set():
            t_start = time.monotonic()

            ret, frame = cap.read()
            if not ret or frame is None:
                consecutive_failures += 1
                logger.warning(
                    "[Camera #%d] Frame read failed (%d/%d).",
                    self._cfg.camera_id,
                    consecutive_failures,
                    max_consecutive_failures,
                )
                if consecutive_failures >= max_consecutive_failures:
                    raise ConnectionError(
                        f"[Camera #{self._cfg.camera_id}] Stream lost after "
                        f"{consecutive_failures} consecutive read failures."
                    )
                time.sleep(0.1)
                continue

            consecutive_failures = 0  # reset on successful read
            self.frames_captured += 1

            # Drop oldest frame if the consumer is slow (keeps queue near real-time)
            if self._frame_q.full():
                try:
                    self._frame_q.get_nowait()
                except queue.Empty:
                    pass
            self._frame_q.put_nowait(frame)

            # Throttle to target FPS
            elapsed = time.monotonic() - t_start
            sleep_for = frame_interval - elapsed
            if sleep_for > 0:
                time.sleep(sleep_for)

    def _set_error(self, code: int, message: str) -> None:
        self.error_code = code
        self.error_message = message
