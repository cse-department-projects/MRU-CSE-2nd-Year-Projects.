"""
alert_forwarder.py — push CV detections to the Express backend.

The inference thread calls ``submit(result)`` for EVERY alert frame (up to ~5
per second per camera). This class makes that safe:

  * per-camera cooldown   - one incident per camera per window, not a flood
  * background worker     - the inference thread never blocks on HTTP
  * retry with backoff    - a brief Express restart must not lose an alert
  * stdlib only (urllib)  - no extra dependency

Express then creates the incident, notifies the operator's dashboard over
WebSocket and starts the 10-second auto-dispatch countdown.
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
import urllib.error
import urllib.request
from typing import Optional

from cv_inference import InferenceResult

logger = logging.getLogger("trinetra.alerts")


class AlertForwarder:
    def __init__(
        self,
        express_url: str,
        api_key: str,
        cooldown_seconds: float = 60.0,
        timeout_seconds: float = 5.0,
        retries: int = 2,
        retry_delay_seconds: float = 1.0,
        failure_cooldown_seconds: float = 5.0,
    ) -> None:
        self._url = express_url.rstrip("/") + "/api/internal/alerts"
        self._key = api_key
        self._cooldown = cooldown_seconds
        self._timeout = timeout_seconds
        self._retries = retries
        self._retry_delay = retry_delay_seconds
        # After a FAILED delivery the camera may alert again this many seconds later
        # (instead of waiting out the full cooldown) so a brief Express outage can't swallow an alert.
        self._failure_cooldown = failure_cooldown_seconds

        self._last_attempt: dict[int, float] = {}
        self._lock = threading.Lock()
        self._queue: "queue.Queue[Optional[dict]]" = queue.Queue(maxsize=50)
        self._thread: Optional[threading.Thread] = None
        self._warned_no_key = False

        self.sent = 0
        self.failed = 0
        self.suppressed = 0

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._worker, name="alert-forwarder", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._thread:
            self._queue.put(None)
            self._thread.join(timeout=5.0)
            self._thread = None

    # ── public API ────────────────────────────────────────────────────────────

    def submit(self, result: InferenceResult) -> bool:
        """Queue an alert for delivery. Returns False if dropped (cooldown / misconfig)."""
        if not self._key:
            if not self._warned_no_key:
                logger.error(
                    "INTERNAL_API_KEY is not set - alerts cannot be forwarded to Express. "
                    "Run `npm run init-env` in backend-express/."
                )
                self._warned_no_key = True
            return False

        now = time.monotonic()
        with self._lock:
            last = self._last_attempt.get(result.camera_id)
            if last is not None and now - last < self._cooldown:
                self.suppressed += 1
                return False
            self._last_attempt[result.camera_id] = now

        payload = {
            "camera_id": result.camera_id,
            "hazard": result.hazard.value,
            "confidence": round(result.confidence, 4),
        }
        try:
            self._queue.put_nowait(payload)
        except queue.Full:
            logger.error("[Alerts] Forward queue full - dropping alert for camera #%d", result.camera_id)
            self._release_cooldown(result.camera_id)
            return False
        return True

    # ── internals ─────────────────────────────────────────────────────────────

    def _release_cooldown(self, camera_id: int) -> None:
        """Let the next detection retry soon after a delivery failure."""
        with self._lock:
            self._last_attempt[camera_id] = time.monotonic() - max(self._cooldown - self._failure_cooldown, 0.0)

    def _worker(self) -> None:
        while True:
            payload = self._queue.get()
            if payload is None:
                return
            ok = self._deliver(payload)
            if ok:
                self.sent += 1
            else:
                self.failed += 1
                self._release_cooldown(payload["camera_id"])

    def _deliver(self, payload: dict) -> bool:
        body = json.dumps(payload).encode()
        for attempt in range(self._retries + 1):
            req = urllib.request.Request(
                self._url,
                data=body,
                method="POST",
                headers={"Content-Type": "application/json", "X-Internal-Key": self._key},
            )
            try:
                with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                    logger.warning(
                        "[Alerts] Camera #%d %s forwarded to Express (HTTP %d)",
                        payload["camera_id"], payload["hazard"], resp.status,
                    )
                    return True
            except urllib.error.HTTPError as e:
                if 400 <= e.code < 500:
                    # Permanent (bad key, unknown camera, validation) - retrying won't help.
                    logger.error("[Alerts] Express rejected alert for camera #%d: HTTP %d",
                                 payload["camera_id"], e.code)
                    return False
                logger.error("[Alerts] Express error HTTP %d (attempt %d)", e.code, attempt + 1)
            except Exception as e:  # URLError, timeout, connection refused ...
                logger.error("[Alerts] Could not reach Express (attempt %d): %s", attempt + 1, e)

            if attempt < self._retries:
                time.sleep(self._retry_delay * (attempt + 1))
        return False
