import { useState, useEffect, useRef, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import { API_BASE } from '../api/client'

/**
 * WebSocket URL, built from the page's own host so it works through the Vite
 * proxy from any device (not just localhost). VITE_API_URL, if set, wins.
 */
function buildWsUrl() {
  if (API_BASE) return `${API_BASE.replace(/^http/, 'ws')}/ws/alerts`
  const scheme = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${scheme}://${window.location.host}/ws/alerts`
}

const MAX_RETRIES = 6
const INITIAL_BACKOFF = 1000 // ms

export function useWebSocket(onMessage) {
  const { token, isAuthenticated } = useAuth()
  const wsRef = useRef(null)
  const retriesRef = useRef(0)
  const backoffRef = useRef(INITIAL_BACKOFF)
  const heartbeatRef = useRef(null)
  const reconnectTimerRef = useRef(null)
  const mountedRef = useRef(true)
  const onMessageRef = useRef(onMessage)

  const [connectionState, setConnectionState] = useState('disconnected') // connecting | connected | disconnected | error

  // Keep latest callback ref
  useEffect(() => { onMessageRef.current = onMessage }, [onMessage])

  const clearTimers = useCallback(() => {
    if (heartbeatRef.current) clearInterval(heartbeatRef.current)
    if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current)
    heartbeatRef.current = null
    reconnectTimerRef.current = null
  }, [])

  const connect = useCallback(() => {
    if (!isAuthenticated || !token || !mountedRef.current) return
    const existing = wsRef.current
    if (existing && (existing.readyState === WebSocket.OPEN || existing.readyState === WebSocket.CONNECTING)) return

    setConnectionState('connecting')

    try {
      const ws = new WebSocket(`${buildWsUrl()}?token=${encodeURIComponent(token)}`)
      wsRef.current = ws

      // Every handler ignores sockets that are no longer the current one. Without
      // this, React StrictMode (dev) or a fast re-login lets a stale socket's
      // late `close` event wipe timers / trigger a duplicate reconnect.
      const isCurrent = () => wsRef.current === ws

      ws.onopen = () => {
        if (!isCurrent() || !mountedRef.current) { ws.close(); return }
        retriesRef.current = 0
        backoffRef.current = INITIAL_BACKOFF
        setConnectionState('connected')

        // Start heartbeat ping every 25s
        heartbeatRef.current = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping' }))
          }
        }, 25000)
      }

      ws.onmessage = (event) => {
        if (!isCurrent()) return
        try {
          const data = JSON.parse(event.data)
          if (data.event !== 'PONG' && onMessageRef.current) {
            onMessageRef.current(data)
          }
        } catch (e) {
          console.warn('[WS] Failed to parse message:', e)
        }
      }

      ws.onclose = (event) => {
        if (!isCurrent() || !mountedRef.current) return
        wsRef.current = null
        clearTimers()
        setConnectionState('disconnected')

        // 4001 = server rejected the token (expired / invalid): log the user out
        // instead of leaving a dead dashboard with a silent "error" badge.
        if (event.code === 4001 || event.code === 4003) {
          setConnectionState('error')
          window.dispatchEvent(new Event('auth:logout'))
          return
        }

        // Exponential backoff reconnect
        if (retriesRef.current < MAX_RETRIES) {
          retriesRef.current++
          const delay = backoffRef.current
          backoffRef.current = Math.min(backoffRef.current * 2, 30000)
          console.log(`[WS] Reconnecting in ${delay}ms (attempt ${retriesRef.current}/${MAX_RETRIES})`)
          reconnectTimerRef.current = setTimeout(connect, delay)
        } else {
          setConnectionState('error')
        }
      }

      ws.onerror = (error) => {
        console.error('[WS] Error:', error)
      }

    } catch (err) {
      console.error('[WS] Failed to create connection:', err)
      setConnectionState('error')
    }
  }, [isAuthenticated, token, clearTimers])

  const disconnect = useCallback(() => {
    clearTimers()
    const ws = wsRef.current
    wsRef.current = null          // detach first so its close event is treated as stale
    if (ws) ws.close(1000, 'User logged out')
    setConnectionState('disconnected')
  }, [clearTimers])

  // Manual "Reconnect" button: start from a clean slate.
  const reconnect = useCallback(() => {
    retriesRef.current = 0
    backoffRef.current = INITIAL_BACKOFF
    clearTimers()
    connect()
  }, [clearTimers, connect])

  useEffect(() => {
    mountedRef.current = true
    if (isAuthenticated && token) {
      connect()
    } else {
      disconnect()
    }
    return () => {
      mountedRef.current = false
      clearTimers()
      const ws = wsRef.current
      wsRef.current = null
      if (ws) ws.close(1000, 'Component unmounted')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, token])

  return { connectionState, reconnect, disconnect }
}
