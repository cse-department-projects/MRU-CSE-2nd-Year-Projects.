/**
 * client.js — Trinetra AI API Client
 *
 * Base URL: by default requests are RELATIVE ('/api/...'), so they go through
 * the Vite dev-server proxy (vite.config.js → http://localhost:8000). That
 * works from any device on the network (e.g. a phone or a second laptop during
 * a demo), unlike a hard-coded http://localhost:8000.
 * For a separately hosted build, set VITE_API_URL=https://your-api-host in
 * frontend/.env.
 *
 * Route map (both /api/* aliases and legacy paths are supported):
 *   POST /api/login            → Login
 *   POST /api/register         → Register
 *   GET  /api/me               → Authenticated user profile
 *   GET  /cameras              → List cameras
 *   POST /cameras              → Register camera
 *   DELETE /cameras/:id        → Delete camera
 *   PUT  /cameras/:id/status   → Toggle camera status
 *   GET  /incidents            → List incidents
 *   POST /incidents/:id/cancel → Cancel incident
 *   POST /incidents/:id/confirm → Confirm and dispatch 112
 *   POST /api/alerts/test      → Manual test hazard alert (dev only)
 */

import axios from 'axios'

export const API_BASE = import.meta.env.VITE_API_URL || ''

const client = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: false,
})

// ─── Request Interceptor: Inject JWT ─────────────────────────────────────────
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('trinetra_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// ─── Response Interceptor: Global 401 Handling ───────────────────────────────
client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('trinetra_token')
      localStorage.removeItem('trinetra_user')
      window.dispatchEvent(new Event('auth:logout'))
    }
    return Promise.reject(error)
  }
)

// ─── Auth API ─────────────────────────────────────────────────────────────────
export const authAPI = {
  /** POST /api/login — accepts { username, password } */
  login: (data) => client.post('/api/login', data),

  /** POST /api/register — accepts { username, email, password } */
  register: (data) => client.post('/api/register', data),

  /** GET /api/me — returns authenticated user profile */
  me: () => client.get('/api/me'),
}

// ─── Cameras API ──────────────────────────────────────────────────────────────
export const camerasAPI = {
  list: () => client.get('/cameras'),
  register: (data) => client.post('/cameras', data),
  delete: (id) => client.delete(`/cameras/${id}`),
  toggleStatus: (id) => client.put(`/cameras/${id}/status`),
}

// ─── Incidents API ────────────────────────────────────────────────────────────
export const incidentsAPI = {
  list: () => client.get('/incidents'),
  cancel: (id) => client.post(`/incidents/${id}/cancel`),
  confirm: (id) => client.post(`/incidents/${id}/confirm`),
}

// ─── Test / Dev API ───────────────────────────────────────────────────────────
export const testAPI = {
  /**
   * POST /api/alerts/test
   * Raises a simulated hazard through the real pipeline: the server stores the
   * incident, pushes HAZARD_ALERT over the WebSocket and starts the countdown.
   * Returns 403 when NODE_ENV=production on the server.
   */
  triggerAlert: () => client.post('/api/alerts/test'),
}

export default client
