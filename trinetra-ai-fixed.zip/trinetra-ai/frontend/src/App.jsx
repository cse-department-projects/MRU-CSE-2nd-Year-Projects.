import { useState, useEffect } from 'react'
import { AuthProvider, useAuth } from './context/AuthContext'
import SplashScreen from './components/SplashScreen'
import AuthPage from './components/AuthPage'
import Dashboard from './components/Dashboard'

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth()
  const [splashDone, setSplashDone] = useState(false)

  // If already authenticated (returning user), skip splash
  const skipSplash = isAuthenticated && !isLoading

  useEffect(() => {
    if (skipSplash) setSplashDone(true)
  }, [skipSplash])

  if (isLoading) {
    return (
      <div className="min-h-screen sentinel-grid flex items-center justify-center">
        <div className="text-cyan-600 font-mono text-sm animate-pulse">Loading sentinel...</div>
      </div>
    )
  }

  if (!splashDone && !skipSplash) {
    return <SplashScreen onComplete={() => setSplashDone(true)} />
  }

  if (!isAuthenticated) {
    return <AuthPage />
  }

  return <Dashboard />
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}
