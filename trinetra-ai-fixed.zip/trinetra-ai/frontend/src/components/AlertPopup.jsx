import { useEffect, useRef, useState, useCallback } from 'react'
import { Phone, X, AlertTriangle, MapPin, Camera, Shield, Zap } from 'lucide-react'
import { incidentsAPI } from '../api/client'

// Web Audio API — generates an urgent beeping alert sound
function playAlertSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)()

    const playBeep = (startTime, freq = 880, duration = 0.12) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.frequency.value = freq
      osc.type = 'square'
      gain.gain.setValueAtTime(0.15, startTime)
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration)
      osc.start(startTime)
      osc.stop(startTime + duration)
    }

    // Three urgent beeps
    const now = ctx.currentTime
    playBeep(now, 880, 0.1)
    playBeep(now + 0.15, 1100, 0.1)
    playBeep(now + 0.30, 880, 0.1)
    playBeep(now + 0.55, 1320, 0.2)
    playBeep(now + 0.85, 880, 0.1)
    playBeep(now + 1.00, 1100, 0.1)

    // Browsers allow only a handful of live AudioContexts; without closing, the
    // repeating alarm silently stops after ~6 repeats.
    setTimeout(() => { ctx.close().catch(() => {}) }, 1800)
  } catch (e) {
    console.warn('[Audio] Web Audio not available:', e)
  }
}

// SVG Countdown Ring
function CountdownRing({ countdown, total = 10 }) {
  const radius = 44
  const circumference = 2 * Math.PI * radius
  const progress = countdown / total
  const strokeDashoffset = circumference * (1 - progress)

  const color = countdown <= 3 ? '#dc1a1a' : countdown <= 6 ? '#f59e0b' : '#06b6d4'

  return (
    <div className="relative flex items-center justify-center" style={{ width: 110, height: 110 }}>
      <svg width="110" height="110" className="countdown-ring absolute">
        {/* Track */}
        <circle cx="55" cy="55" r={radius} fill="none" stroke="rgba(30,45,69,0.5)" strokeWidth="6" />
        {/* Progress */}
        <circle
          cx="55" cy="55" r={radius}
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          style={{
            filter: `drop-shadow(0 0 6px ${color})`,
            transition: 'stroke-dashoffset 1s linear, stroke 0.3s ease',
          }}
        />
      </svg>
      <div className="relative z-10 text-center">
        <div
          className="text-4xl font-black tabular-nums"
          style={{
            color,
            textShadow: `0 0 16px ${color}`,
            transition: 'color 0.3s ease',
          }}
        >
          {countdown}
        </div>
        <div className="text-xs font-mono text-slate-500 mt-0.5">SEC</div>
      </div>
    </div>
  )
}

export default function AlertPopup({ alert, countdown, onCancel, onConfirm, onStale }) {
  const busyRef = useRef(false)
  const [error, setError] = useState('')

  // Play sound on mount, repeat until the popup closes
  useEffect(() => {
    playAlertSound()
    const interval = setInterval(playAlertSound, 3500)
    return () => clearInterval(interval)
  }, [alert.incident_id])

  // Run a cancel/confirm API call. The popup only reports success to the dashboard
  // when the SERVER accepted it — previously a failed call still showed
  // "Call to 112 initiated successfully".
  const act = useCallback(async (apiCall, onSuccess) => {
    if (busyRef.current) return
    busyRef.current = true
    setError('')
    try {
      await apiCall(alert.incident_id)
      onSuccess()
    } catch (e) {
      busyRef.current = false
      const status = e.response?.status
      if (status === 400 || status === 404) {
        // Already auto-dispatched / handled in another tab.
        onStale()
        return
      }
      console.error('[Alert] Action failed:', e)
      setError(e.response?.data?.detail || 'Could not reach the server — try again.')
    }
  }, [alert.incident_id, onStale])

  const handleCancel = useCallback(() => act(incidentsAPI.cancel, onCancel), [act, onCancel])
  const handleConfirm = useCallback(() => act(incidentsAPI.confirm, onConfirm), [act, onConfirm])

  const hazardIcon = alert.hazard_type?.includes('Fire') ? '🔥'
    : alert.hazard_type?.includes('Smoke') ? '💨'
    : alert.hazard_type?.includes('Intrusion') ? '🚨'
    : alert.hazard_type?.includes('Fall') ? '🫸'
    : '⚠️'

  const isUrgent = countdown <= 3

  return (
    <div className="alert-overlay" role="alertdialog" aria-modal="true" aria-label="Hazard Alert">
      <div className={`alert-card alert-border-flash`} style={{ maxWidth: 560 }}>

        {/* Top strip */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-red-900/30"
          style={{ background: 'rgba(220,26,26,0.08)' }}>
          <div className="flex items-center gap-2">
            <div className="pulse-dot-red w-2.5 h-2.5" />
            <span className="text-xs font-mono font-bold text-red-400 tracking-widest">CRITICAL HAZARD DETECTED</span>
          </div>
          <span className="text-xs font-mono text-slate-500">INC-{String(alert.incident_id).padStart(4, '0')}</span>
        </div>

        <div className="p-6 space-y-5">
          {/* Main alert info */}
          <div className="flex items-start gap-4">
            <div className="text-5xl leading-none" role="img" aria-label={alert.hazard_type}>
              {hazardIcon}
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-black text-white mb-1 leading-tight">
                {alert.hazard_type}
              </h2>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 text-sm text-slate-400">
                  <MapPin className="w-3.5 h-3.5 text-red-400" />
                  <span>{alert.location_tag}</span>
                </div>
                <div className="flex items-center gap-1.5 text-sm text-slate-400">
                  <Camera className="w-3.5 h-3.5 text-slate-500" />
                  <span>{alert.device_name}</span>
                </div>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-xs px-2 py-0.5 rounded font-mono font-semibold text-red-400"
                  style={{ background: 'rgba(220,26,26,0.15)', border: '1px solid rgba(220,26,26,0.3)' }}>
                  SEVERITY: CRITICAL
                </span>
                <span className="text-xs px-2 py-0.5 rounded font-mono text-amber-400"
                  style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)' }}>
                  {alert.confidence} confidence
                </span>
              </div>
            </div>
          </div>

          {/* Countdown + message */}
          <div className="flex items-center gap-5 p-4 rounded-xl"
            style={{ background: 'rgba(220,26,26,0.06)', border: '1px solid rgba(220,26,26,0.2)' }}>
            <CountdownRing countdown={countdown} total={alert.timeout_seconds || 10} />
            <div className="flex-1">
              <div className={`text-sm font-bold mb-1 ${isUrgent ? 'text-red-400' : 'text-amber-400'}`}>
                {isUrgent ? '⚡ AUTO-DISPATCHING NOW' : '⏱ Auto-Dispatch in...'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Emergency call to <span className="text-red-400 font-mono font-bold">112</span> will be
                auto-dispatched if no action is taken. Location and hazard telemetry will be transmitted.
              </p>
              {countdown <= 3 && (
                <div className="mt-2 text-xs font-mono text-red-500 animate-pulse">
                  DISPATCHING IN {countdown}...
                </div>
              )}
            </div>
          </div>

          {error && (
            <div role="alert" className="text-xs font-semibold text-red-400 px-3 py-2 rounded-lg"
              style={{ background: 'rgba(220,26,26,0.1)', border: '1px solid rgba(220,26,26,0.3)' }}>
              {error}
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              id="alert-cancel-btn"
              onClick={handleCancel}
              className="btn-ghost flex-1 py-3 flex items-center justify-center gap-2 text-sm"
            >
              <X className="w-4 h-4" />
              False Alarm
            </button>
            <button
              id="alert-confirm-btn"
              onClick={handleConfirm}
              className="btn-danger flex-1 py-3 flex items-center justify-center gap-2 text-sm font-bold glow-crimson"
              style={{ boxShadow: '0 0 20px rgba(220,26,26,0.4)' }}
            >
              <Phone className="w-4 h-4" />
              Call 112 Now
              <Zap className="w-4 h-4" />
            </button>
          </div>

          {/* Warning */}
          <div className="flex items-start gap-2 text-xs text-slate-600">
            <Shield className="w-3.5 h-3.5 mt-0.5 shrink-0 text-slate-700" />
            <span>
              Trinetra AI will log all actions. A false-alarm dismissal is recorded as a dismissed incident.
              Emergency dispatch is coordinate-aware and includes full telemetry.
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
