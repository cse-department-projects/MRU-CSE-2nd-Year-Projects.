import { useState } from 'react'
import { Eye, EyeOff, Shield, AlertTriangle, User, Mail, Lock, ChevronRight } from 'lucide-react'
import { authAPI } from '../api/client'
import { useAuth } from '../context/AuthContext'

export default function AuthPage() {
  const { login } = useAuth()
  const [mode, setMode] = useState('login') // 'login' | 'register'
  const [form, setForm] = useState({ username: '', email: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e) => {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))
    if (error) setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      let res
      if (mode === 'login') {
        res = await authAPI.login({ username: form.username, password: form.password })
      } else {
        if (!form.email) { setError('Email is required for registration.'); setLoading(false); return }
        res = await authAPI.register({ username: form.username, email: form.email, password: form.password })
      }
      login(res.data.access_token, res.data.user)
    } catch (err) {
      const msg = err.response?.data?.detail
      setError(Array.isArray(msg) ? msg[0]?.msg || 'An error occurred.' : msg || 'An error occurred.')
    } finally {
      setLoading(false)
    }
  }

  const switchMode = (newMode) => {
    setMode(newMode)
    setError('')
    setForm({ username: '', email: '', password: '' })
  }

  return (
    <div className="min-h-screen sentinel-grid flex items-center justify-center p-4 relative">
      {/* Scan line */}
      <div className="scan-line" />

      {/* Ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(6,182,212,0.06) 0%, transparent 70%)',
        }}
      />

      {/* Corner decorations */}
      <div className="absolute top-6 left-6 w-8 h-8 border-t-2 border-l-2 border-cyan-500/30" />
      <div className="absolute top-6 right-6 w-8 h-8 border-t-2 border-r-2 border-cyan-500/30" />
      <div className="absolute bottom-6 left-6 w-8 h-8 border-b-2 border-l-2 border-cyan-500/30" />
      <div className="absolute bottom-6 right-6 w-8 h-8 border-b-2 border-r-2 border-cyan-500/30" />

      <div className="w-full max-w-md animate-slide-up z-10">

        {/* Logo + Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full mb-4"
            style={{ background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.3)' }}>
            <svg width="36" height="36" viewBox="0 0 120 120" fill="none" style={{ filter: 'drop-shadow(0 0 8px rgba(6,182,212,0.8))' }}>
              <path d="M60 30 C30 30 8 60 8 60 C8 60 30 90 60 90 C90 90 112 60 112 60 C112 60 90 30 60 30Z" fill="none" stroke="#06b6d4" strokeWidth="2" />
              <circle cx="60" cy="60" r="20" fill="none" stroke="#06b6d4" strokeWidth="2" />
              <circle cx="60" cy="60" r="8" fill="#06b6d4" />
            </svg>
          </div>
          <h1 className="text-3xl font-black text-cyan-400 tracking-widest text-glow-teal">TRINETRA AI</h1>
          <p className="text-slate-500 text-sm mt-1 font-mono tracking-wide">
            {mode === 'login' ? 'Access the Sentinel Grid' : 'Initialize your Sentinel Node'}
          </p>
        </div>

        {/* Card */}
        <div className="glass rounded-2xl p-8"
          style={{ boxShadow: '0 0 40px rgba(6,182,212,0.08), 0 0 80px rgba(6,182,212,0.03)' }}>

          {/* Tab switcher */}
          <div className="flex rounded-lg overflow-hidden mb-6 bg-sentinel-bg p-1 gap-1">
            {['login', 'register'].map(m => (
              <button
                key={m}
                id={`auth-tab-${m}`}
                onClick={() => switchMode(m)}
                className={`flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-all duration-200 ${
                  mode === m
                    ? 'bg-cyan-900/40 text-cyan-400 shadow-sm'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {m === 'login' ? 'Login' : 'Sign Up'}
              </button>
            ))}
          </div>

          {/* Form */}
          <form id="auth-form" onSubmit={handleSubmit} className="space-y-4">

            {/* Username */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="auth-username"
                  type="text"
                  name="username"
                  value={form.username}
                  onChange={handleChange}
                  placeholder="operator_1"
                  required
                  autoComplete="username"
                  className="sentinel-input w-full pl-10 pr-4 py-2.5 text-sm"
                />
              </div>
            </div>

            {/* Email (register only) */}
            {mode === 'register' && (
              <div className="animate-slide-up">
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="auth-email"
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="operator@trinetra.ai"
                    required
                    className="sentinel-input w-full pl-10 pr-4 py-2.5 text-sm"
                  />
                </div>
              </div>
            )}

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="auth-password"
                  type={showPw ? 'text' : 'password'}
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  className="sentinel-input w-full pl-10 pr-10 py-2.5 text-sm"
                />
                <button
                  type="button"
                  id="toggle-password"
                  onClick={() => setShowPw(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-400 text-sm animate-slide-up">
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Submit */}
            <button
              id="auth-submit"
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-3 flex items-center justify-center gap-2 text-sm mt-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  {mode === 'login' ? 'Authenticating...' : 'Creating Node...'}
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4" />
                  {mode === 'login' ? 'Access Dashboard' : 'Create Account'}
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Footer */}
        <p className="text-center text-slate-600 text-xs font-mono mt-6 tracking-wide">
          Trinetra AI Sentinel Grid &mdash; Secured & Encrypted
        </p>
      </div>
    </div>
  )
}
