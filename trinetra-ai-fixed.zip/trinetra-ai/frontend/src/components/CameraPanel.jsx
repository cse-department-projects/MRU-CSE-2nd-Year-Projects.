import { useState } from 'react'
import { Plus, Camera, Trash2, Wifi, WifiOff, Zap, MapPin, Link, X, CheckCircle, AlertCircle, Loader } from 'lucide-react'
import { camerasAPI } from '../api/client'

function CameraFeed({ camera }) {
  const isActive = camera.status === 'active'
  return (
    <div className="camera-feed rounded-xl overflow-hidden aspect-video relative">
      {/* Static noise background */}
      <div className="camera-noise" />
      <div className="camera-scanlines" />

      {/* Content overlay */}
      <div className="absolute inset-0 flex flex-col justify-between p-3 z-10">
        {/* Top bar */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 bg-black/60 rounded px-2 py-0.5">
            {isActive ? (
              <>
                <div className="pulse-dot-red w-2 h-2" />
                <span className="text-xs font-mono text-red-400 font-semibold">REC</span>
              </>
            ) : (
              <>
                <div className="w-2 h-2 rounded-full bg-slate-600" />
                <span className="text-xs font-mono text-slate-500">OFFLINE</span>
              </>
            )}
          </div>
          <div className="bg-black/60 rounded px-2 py-0.5">
            <span className="text-xs font-mono text-slate-400">CAM-{String(camera.id).padStart(2, '0')}</span>
          </div>
        </div>

        {/* Center: grid lines */}
        {isActive && (
          <div className="flex items-center justify-center opacity-20">
            <div className="w-full h-px bg-cyan-500/30" />
            <div className="absolute h-full w-px bg-cyan-500/20" />
          </div>
        )}

        {/* Bottom: location */}
        <div className="flex items-center justify-between">
          <div className="bg-black/70 rounded px-2 py-0.5 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-cyan-500" />
            <span className="text-xs font-mono text-cyan-400">{camera.location_tag}</span>
          </div>
          {isActive && (
            <div className="bg-black/60 rounded px-2 py-0.5">
              <span className="text-xs font-mono text-green-400">LIVE</span>
            </div>
          )}
        </div>
      </div>

      {/* Inactive overlay */}
      {!isActive && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/60 z-20">
          <div className="text-center">
            <WifiOff className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <div className="text-xs font-mono text-slate-600">SIGNAL LOST</div>
          </div>
        </div>
      )}
    </div>
  )
}

function AddCameraModal({ onClose, onSuccess }) {
  const [form, setForm] = useState({ device_name: '', stream_url: '', location_tag: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await camerasAPI.register(form)
      onSuccess(res.data)
    } catch (err) {
      const msg = err.response?.data?.detail
      setError(Array.isArray(msg) ? msg[0]?.msg : msg || 'Failed to register camera.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="glass rounded-2xl p-6 w-full max-w-md mx-4 animate-scale-in" onClick={e => e.stopPropagation()}
        style={{ boxShadow: '0 0 40px rgba(6,182,212,0.15)' }}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">Register Camera</h3>
          </div>
          <button id="close-camera-modal" onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form id="add-camera-form" onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">Device Name</label>
            <input
              id="camera-device-name"
              type="text"
              value={form.device_name}
              onChange={e => setForm(f => ({ ...f, device_name: e.target.value }))}
              placeholder="e.g., Main Entrance Camera"
              required
              className="sentinel-input w-full px-3 py-2.5 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">Location Tag</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="camera-location"
                type="text"
                value={form.location_tag}
                onChange={e => setForm(f => ({ ...f, location_tag: e.target.value }))}
                placeholder="e.g., Living Room, Office Warehouse"
                required
                className="sentinel-input w-full pl-10 pr-3 py-2.5 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5 tracking-wider uppercase">Stream URL</label>
            <div className="relative">
              <Link className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="camera-stream-url"
                type="text"
                value={form.stream_url}
                onChange={e => setForm(f => ({ ...f, stream_url: e.target.value }))}
                placeholder="rtsp://192.168.1.x:554/stream"
                required
                className="sentinel-input w-full pl-10 pr-3 py-2.5 text-sm font-mono"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-red-950/40 border border-red-900/50 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <button type="button" id="cancel-camera-modal" onClick={onClose} className="btn-ghost flex-1 py-2.5 text-sm">Cancel</button>
            <button id="submit-camera" type="submit" disabled={loading} className="btn-primary flex-1 py-2.5 text-sm flex items-center justify-center gap-2">
              {loading ? <><Loader className="w-4 h-4 animate-spin" />Linking...</> : <><Zap className="w-4 h-4" />Deploy Edge AI</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function CameraPanel({ cameras, onCamerasChange, notifications = [] }) {
  const [showModal, setShowModal] = useState(false)
  const [deletingId, setDeletingId] = useState(null)
  const [togglingId, setTogglingId] = useState(null)

  const handleCameraAdded = (camera) => {
    onCamerasChange(prev => [...prev, camera])
    setShowModal(false)
  }

  const handleDelete = async (id) => {
    setDeletingId(id)
    try {
      await camerasAPI.delete(id)
      onCamerasChange(prev => prev.filter(c => c.id !== id))
    } catch (err) {
      console.error('Delete failed:', err)
    } finally {
      setDeletingId(null)
    }
  }

  const handleToggle = async (id) => {
    setTogglingId(id)
    try {
      const res = await camerasAPI.toggleStatus(id)
      onCamerasChange(prev => prev.map(c => c.id === id ? res.data : c))
    } catch (err) {
      console.error('Toggle failed:', err)
    } finally {
      setTogglingId(null)
    }
  }

  // Filter init notifications for cameras
  const cameraNotifs = notifications.filter(n => n.event === 'CAMERA_INIT' || n.event === 'CAMERA_READY' || n.event === 'CAMERA_ERROR')

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-cyan-400" />
            Camera Network
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">{cameras.length} device{cameras.length !== 1 ? 's' : ''} registered</p>
        </div>
        <button
          id="add-camera-btn"
          onClick={() => setShowModal(true)}
          className="btn-primary px-4 py-2.5 flex items-center gap-2 text-sm"
        >
          <Plus className="w-4 h-4" />
          Add Camera
        </button>
      </div>

      {/* Init notifications */}
      {cameraNotifs.length > 0 && (
        <div className="space-y-2">
          {cameraNotifs.slice(-3).map((n, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg text-sm animate-slide-up"
              style={{
                background: n.event === 'CAMERA_ERROR' ? 'rgba(220,26,26,0.08)' : n.event === 'CAMERA_READY' ? 'rgba(6,182,212,0.08)' : 'rgba(245,158,11,0.08)',
                border: `1px solid ${n.event === 'CAMERA_ERROR' ? 'rgba(220,26,26,0.3)' : n.event === 'CAMERA_READY' ? 'rgba(6,182,212,0.2)' : 'rgba(245,158,11,0.2)'}`,
              }}>
              {n.event === 'CAMERA_READY'
                ? <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                : n.event === 'CAMERA_ERROR'
                  ? <span className="shrink-0">⚠️</span>
                  : <Loader className="w-4 h-4 text-amber-400 shrink-0 animate-spin" />}
              <span className={n.event === 'CAMERA_ERROR' ? 'text-red-300' : n.event === 'CAMERA_READY' ? 'text-cyan-300' : 'text-amber-300'}>
                {n.message}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Camera grid */}
      {cameras.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
            style={{ background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.15)' }}>
            <Camera className="w-7 h-7 text-slate-600" />
          </div>
          <h3 className="text-lg font-semibold text-slate-400">No cameras registered</h3>
          <p className="text-sm text-slate-600 mt-1 max-w-xs">
            Add your first CCTV camera to activate the Trinetra sentinel grid.
          </p>
          <button id="add-first-camera" onClick={() => setShowModal(true)} className="btn-primary mt-4 px-4 py-2 text-sm flex items-center gap-2">
            <Plus className="w-4 h-4" /> Register First Camera
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {cameras.map((cam) => (
            <div key={cam.id} className="rounded-xl overflow-hidden border border-sentinel-border/60 hover:border-cyan-800/40 transition-all duration-200"
              style={{ background: '#0d1220' }}>
              <CameraFeed camera={cam} />
              <div className="p-3">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm text-white truncate">{cam.device_name}</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      <span className="text-xs text-slate-500 truncate">{cam.location_tag}</span>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold shrink-0 ${cam.status === 'active' ? 'badge-active' : 'badge-inactive'}`}>
                    {cam.status}
                  </span>
                </div>
                <div className="text-xs text-slate-600 font-mono truncate mb-3">{cam.stream_url}</div>
                <div className="flex gap-2">
                  <button
                    id={`toggle-camera-${cam.id}`}
                    onClick={() => handleToggle(cam.id)}
                    disabled={togglingId === cam.id}
                    className="btn-ghost flex-1 py-1.5 flex items-center justify-center gap-1.5 text-xs"
                  >
                    {togglingId === cam.id ? <Loader className="w-3 h-3 animate-spin" /> : cam.status === 'active' ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
                    {cam.status === 'active' ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    id={`delete-camera-${cam.id}`}
                    onClick={() => handleDelete(cam.id)}
                    disabled={deletingId === cam.id}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-red-500 hover:bg-red-950/30 hover:text-red-400 transition-all border border-red-900/30 hover:border-red-800/40 flex items-center gap-1"
                  >
                    {deletingId === cam.id ? <Loader className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && <AddCameraModal onClose={() => setShowModal(false)} onSuccess={handleCameraAdded} />}
    </div>
  )
}
