import { LayoutDashboard, Camera, Bell, LogOut, Activity, Shield, ChevronRight } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'cameras', label: 'Cameras', icon: Camera },
  { id: 'incidents', label: 'Incidents', icon: Bell },
]

export default function Sidebar({ activeTab, onTabChange, incidentCount = 0 }) {
  const { user, logout } = useAuth()

  return (
    <aside className="w-64 flex-shrink-0 flex flex-col h-full glass border-r border-sentinel-border/60">

      {/* Logo */}
      <div className="px-6 py-5 border-b border-sentinel-border/40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(6,182,212,0.12)', border: '1px solid rgba(6,182,212,0.3)' }}>
            <svg width="20" height="20" viewBox="0 0 120 120" fill="none"
              style={{ filter: 'drop-shadow(0 0 5px rgba(6,182,212,0.8))' }}>
              <path d="M60 30 C30 30 8 60 8 60 C8 60 30 90 60 90 C90 90 112 60 112 60 C112 60 90 30 60 30Z"
                fill="none" stroke="#06b6d4" strokeWidth="3" />
              <circle cx="60" cy="60" r="20" fill="none" stroke="#06b6d4" strokeWidth="2.5" />
              <circle cx="60" cy="60" r="9" fill="#06b6d4" />
            </svg>
          </div>
          <div>
            <div className="text-sm font-black tracking-widest text-cyan-400">TRINETRA</div>
            <div className="text-xs text-slate-600 font-mono">AI Sentinel</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            id={`nav-${id}`}
            onClick={() => onTabChange(id)}
            className={`sidebar-item w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
              activeTab === id ? 'active' : 'text-slate-400'
            }`}
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            <span className="flex-1 text-left">{label}</span>
            {id === 'incidents' && incidentCount > 0 && (
              <span className="flex items-center justify-center w-5 h-5 rounded-full text-xs font-bold bg-red-900/60 text-red-400 border border-red-800/60">
                {incidentCount > 9 ? '9+' : incidentCount}
              </span>
            )}
            {activeTab === id && <ChevronRight className="w-3 h-3 opacity-60" />}
          </button>
        ))}
      </nav>

      {/* System Status */}
      <div className="px-3 py-3 mx-3 mb-3 rounded-lg" style={{ background: 'rgba(6,182,212,0.05)', border: '1px solid rgba(6,182,212,0.1)' }}>
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-3 h-3 text-cyan-500" />
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">System Status</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="pulse-dot w-2 h-2" />
          <span className="text-xs text-cyan-400 font-mono">SENTINEL ACTIVE</span>
        </div>
      </div>

      {/* User Profile */}
      <div className="px-3 pb-4 border-t border-sentinel-border/40 pt-4">
        <div className="flex items-center gap-3 mb-3 px-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center bg-cyan-900/40 border border-cyan-800/40 flex-shrink-0">
            <Shield className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{user?.username}</div>
            <div className="text-xs text-slate-500 truncate">{user?.email}</div>
          </div>
        </div>
        <button
          id="logout-btn"
          onClick={logout}
          className="btn-ghost w-full py-2 flex items-center justify-center gap-2 text-xs"
        >
          <LogOut className="w-3.5 h-3.5" />
          Logout
        </button>
      </div>
    </aside>
  )
}
