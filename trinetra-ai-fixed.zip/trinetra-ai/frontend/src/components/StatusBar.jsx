import { Wifi, WifiOff, RefreshCw, Activity, Camera } from 'lucide-react'

/**
 * StatusBar — top ribbon showing WebSocket status + live camera count.
 *
 * Props:
 *   connectionState  — 'connected' | 'connecting' | 'disconnected' | 'error'
 *   onReconnect      — callback to trigger WS reconnect
 *   activeScanners   — number of backend CV scanner processes (from HEARTBEAT)
 *   cameraCount      — user's registered camera count (cameras.length from Dashboard state)
 */
export default function StatusBar({ connectionState, onReconnect, activeScanners = 0, cameraCount = 0 }) {
  const isConnected  = connectionState === 'connected'
  const isConnecting = connectionState === 'connecting'
  const isError      = connectionState === 'error'

  return (
    <div
      className="h-9 flex items-center justify-between px-4 border-b border-sentinel-border/40 bg-sentinel-surface/60"
      style={{ minHeight: '36px' }}
    >
      {/* ── Left: WS status + camera count ───────────────────────── */}
      <div className="flex items-center gap-3">

        {/* WebSocket connection pill */}
        <div className="flex items-center gap-1.5">
          {isConnected ? (
            <>
              <div className="pulse-dot w-2 h-2" />
              <span className="text-xs font-mono text-cyan-400">LIVE</span>
            </>
          ) : isConnecting ? (
            <>
              <RefreshCw className="w-3 h-3 text-amber-400 animate-spin" />
              <span className="text-xs font-mono text-amber-400">CONNECTING...</span>
            </>
          ) : isError ? (
            <>
              <div className="w-2 h-2 rounded-full bg-red-500" />
              <span className="text-xs font-mono text-red-400">DISCONNECTED</span>
              <button
                id="ws-reconnect-btn"
                onClick={onReconnect}
                className="ml-1 text-xs text-slate-400 hover:text-cyan-400 underline underline-offset-2 transition-colors"
              >
                Retry
              </button>
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3 text-slate-600" />
              <span className="text-xs font-mono text-slate-600">OFFLINE</span>
            </>
          )}
        </div>

        <span className="text-slate-700 text-xs">|</span>

        {/* ── Dynamic camera count — always reflects cameras.length from Dashboard state */}
        <div className="flex items-center gap-1.5">
          <Camera className="w-3 h-3 text-slate-500" />
          <span className="text-xs font-mono text-slate-500">
            Monitoring {cameraCount} camera{cameraCount !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Active scanners badge — only shown when > 0 */}
        {activeScanners > 0 && (
          <>
            <span className="text-slate-700 text-xs">|</span>
            <div className="flex items-center gap-1.5">
              <Activity className="w-3 h-3 text-emerald-600" />
              <span className="text-xs font-mono text-emerald-600">
                {activeScanners} scanner{activeScanners !== 1 ? 's' : ''} active
              </span>
            </div>
          </>
        )}
      </div>

      {/* ── Right: Branding ───────────────────────────────────────── */}
      <div className="text-xs font-mono text-slate-700 tracking-widest hidden sm:block">
        TRINETRA AI — SENTINEL GRID
      </div>
    </div>
  )
}
