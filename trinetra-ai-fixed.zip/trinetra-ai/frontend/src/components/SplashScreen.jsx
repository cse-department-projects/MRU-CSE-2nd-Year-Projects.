import { useState, useEffect } from 'react'

const PHASES = [
  { text: 'Initializing Sentinel Grid...', delay: 600 },
  { text: 'Calibrating Detection Modules...', delay: 1400 },
  { text: 'Establishing Secure Channel...', delay: 2200 },
  { text: 'System Online.', delay: 3000 },
]

export default function SplashScreen({ onComplete }) {
  const [phase, setPhase] = useState(0)
  const [logoVisible, setLogoVisible] = useState(false)
  const [textVisible, setTextVisible] = useState(false)
  const [exiting, setExiting] = useState(false)

  useEffect(() => {
    const t1 = setTimeout(() => setLogoVisible(true), 300)
    const t2 = setTimeout(() => setTextVisible(true), 800)

    const phaseTimers = PHASES.map((p, i) =>
      setTimeout(() => setPhase(i), p.delay)
    )

    const exitTimer = setTimeout(() => {
      setExiting(true)
      setTimeout(onComplete, 600)
    }, 3800)

    return () => {
      clearTimeout(t1); clearTimeout(t2); clearTimeout(exitTimer)
      phaseTimers.forEach(clearTimeout)
    }
  }, [onComplete])

  return (
    <div
      className="splash-container"
      style={{
        opacity: exiting ? 0 : 1,
        transition: 'opacity 0.6s ease-in-out',
      }}
    >
      {/* Scan line */}
      <div className="scan-line" />

      {/* Corner decorations */}
      <div className="absolute top-6 left-6 w-8 h-8 border-t-2 border-l-2 border-cyan-500/40" />
      <div className="absolute top-6 right-6 w-8 h-8 border-t-2 border-r-2 border-cyan-500/40" />
      <div className="absolute bottom-6 left-6 w-8 h-8 border-b-2 border-l-2 border-cyan-500/40" />
      <div className="absolute bottom-6 right-6 w-8 h-8 border-b-2 border-r-2 border-cyan-500/40" />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 sentinel-grid opacity-40"
        style={{ backgroundSize: '60px 60px' }}
      />

      {/* Centered content */}
      <div className="relative flex flex-col items-center gap-8 z-10">

        {/* Trinetra Eye Logo */}
        <div
          className="eye-svg"
          style={{
            opacity: logoVisible ? 1 : 0,
            transform: logoVisible ? 'scale(1)' : 'scale(0.6)',
            transition: 'opacity 0.8s ease-out, transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)',
          }}
        >
          <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Outer ring */}
            <circle cx="60" cy="60" r="58" stroke="#06b6d4" strokeWidth="1" strokeDasharray="4 3" opacity="0.5">
              <animateTransform attributeName="transform" type="rotate" from="0 60 60" to="360 60 60" dur="20s" repeatCount="indefinite" />
            </circle>

            {/* Mid ring */}
            <circle cx="60" cy="60" r="48" stroke="#06b6d4" strokeWidth="0.5" opacity="0.3">
              <animateTransform attributeName="transform" type="rotate" from="360 60 60" to="0 60 60" dur="12s" repeatCount="indefinite" />
            </circle>

            {/* Eye shape outer */}
            <path
              d="M60 30 C30 30 8 60 8 60 C8 60 30 90 60 90 C90 90 112 60 112 60 C112 60 90 30 60 30Z"
              fill="none"
              stroke="#06b6d4"
              strokeWidth="1.5"
              opacity="0.7"
            />

            {/* Iris */}
            <circle cx="60" cy="60" r="20" fill="none" stroke="#06b6d4" strokeWidth="1.5" opacity="0.9" />

            {/* Iris gradient fill */}
            <circle cx="60" cy="60" r="18" fill="url(#irisGrad)" opacity="0.4" />

            {/* Pupil */}
            <circle cx="60" cy="60" r="8" fill="#06b6d4" opacity="0.9">
              <animate attributeName="r" values="8;9;8" dur="2s" repeatCount="indefinite" />
            </circle>

            {/* Pupil shine */}
            <circle cx="63" cy="57" r="2.5" fill="white" opacity="0.6" />

            {/* Eyelid lines */}
            <path d="M20 60 Q60 35 100 60" stroke="#0891b2" strokeWidth="0.5" fill="none" opacity="0.4" />
            <path d="M20 60 Q60 85 100 60" stroke="#0891b2" strokeWidth="0.5" fill="none" opacity="0.4" />

            {/* Third eye accent lines (Trinetra) */}
            <line x1="60" y1="2" x2="60" y2="20" stroke="#f59e0b" strokeWidth="1.5" opacity="0.7">
              <animate attributeName="opacity" values="0.7;1;0.7" dur="1.5s" repeatCount="indefinite" />
            </line>
            <line x1="60" y1="100" x2="60" y2="118" stroke="#06b6d4" strokeWidth="1" opacity="0.4" />
            <line x1="2" y1="60" x2="18" y2="60" stroke="#06b6d4" strokeWidth="1" opacity="0.4" />
            <line x1="102" y1="60" x2="118" y2="60" stroke="#06b6d4" strokeWidth="1" opacity="0.4" />

            <defs>
              <radialGradient id="irisGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#0c4a6e" />
              </radialGradient>
            </defs>
          </svg>
        </div>

        {/* Brand Name */}
        <div
          className="text-center"
          style={{
            opacity: textVisible ? 1 : 0,
            transform: textVisible ? 'translateY(0)' : 'translateY(16px)',
            transition: 'opacity 0.6s ease-out, transform 0.6s ease-out',
          }}
        >
          <h1 className="text-5xl font-black tracking-wider text-glow-teal text-cyan-400 mb-1"
            style={{ letterSpacing: '0.15em' }}>
            TRINETRA
          </h1>
          <div className="text-sm font-mono text-cyan-600 tracking-widest uppercase">
            AI Sentinel Grid v1.0
          </div>
        </div>

        {/* Loading Status */}
        <div
          className="flex flex-col items-center gap-3"
          style={{
            opacity: textVisible ? 1 : 0,
            transition: 'opacity 0.6s ease-out 0.3s',
          }}
        >
          {/* Progress bar */}
          <div className="w-64 h-px bg-sentinel-border relative overflow-hidden">
            <div
              className="absolute left-0 top-0 h-full bg-cyan-500"
              style={{
                width: `${((phase + 1) / PHASES.length) * 100}%`,
                transition: 'width 0.6s ease-out',
                boxShadow: '0 0 8px rgba(6, 182, 212, 0.8)',
              }}
            />
          </div>

          {/* Status text */}
          <div className="font-mono text-xs text-cyan-600 tracking-wide min-h-5">
            <span className="text-cyan-400">&gt;</span>{' '}
            {PHASES[phase]?.text}
            <span className="animate-blink ml-0.5">_</span>
          </div>
        </div>
      </div>

      {/* Bottom info */}
      <div
        className="absolute bottom-8 font-mono text-xs text-slate-600 tracking-widest"
        style={{ opacity: textVisible ? 1 : 0, transition: 'opacity 1s ease-out 1s' }}
      >
        REAL-TIME HAZARD DETECTION & EMERGENCY DISPATCH
      </div>
    </div>
  )
}
