import { useEffect, useState } from 'react'
import { Bell, Clock, MapPin, Camera, CheckCircle, XCircle, Phone, AlertTriangle, RefreshCw } from 'lucide-react'
import { incidentsAPI } from '../api/client'

const STATUS_CONFIG = {
  pending: { label: 'Pending', cls: 'badge-pending', icon: AlertTriangle },
  dispatched: { label: 'Dispatched', cls: 'badge-dispatched', icon: Phone },
  cancelled: { label: 'False Alarm', cls: 'badge-cancelled', icon: XCircle },
}

function formatTime(iso) {
  const d = new Date(iso)
  return d.toLocaleString('en-IN', {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: true,
  })
}

export default function IncidentLog({ recentEvent }) {
  const [incidents, setIncidents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchIncidents = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await incidentsAPI.list()
      setIncidents(res.data)
    } catch (err) {
      setError('Failed to load incidents.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchIncidents() }, [])

  // Refresh when new event arrives
  useEffect(() => {
    if (recentEvent && (recentEvent.event === 'HAZARD_ALERT' || recentEvent.event === 'DISPATCH_CONFIRMED' || recentEvent.event === 'INCIDENT_UPDATED')) {
      setTimeout(fetchIncidents, 500)
    }
  }, [recentEvent])

  const counts = {
    total: incidents.length,
    dispatched: incidents.filter(i => i.status === 'dispatched').length,
    cancelled: incidents.filter(i => i.status === 'cancelled').length,
    pending: incidents.filter(i => i.status === 'pending').length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-cyan-400" />
            Incident Log
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">{counts.total} total events recorded</p>
        </div>
        <button id="refresh-incidents" onClick={fetchIncidents} className="btn-ghost px-3 py-2 flex items-center gap-1.5 text-xs">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Dispatched', count: counts.dispatched, color: '#dc1a1a', bg: 'rgba(220,26,26,0.08)', border: 'rgba(220,26,26,0.2)', icon: Phone },
          { label: 'False Alarms', count: counts.cancelled, color: '#f59e0b', bg: 'rgba(245,158,11,0.08)', border: 'rgba(245,158,11,0.2)', icon: XCircle },
          { label: 'Pending', count: counts.pending, color: '#60a5fa', bg: 'rgba(59,130,246,0.08)', border: 'rgba(59,130,246,0.2)', icon: AlertTriangle },
        ].map(({ label, count, color, bg, border, icon: Icon }) => (
          <div key={label} className="rounded-xl p-4 text-center" style={{ background: bg, border: `1px solid ${border}` }}>
            <Icon className="w-4 h-4 mx-auto mb-1" style={{ color }} />
            <div className="text-2xl font-black" style={{ color }}>{count}</div>
            <div className="text-xs text-slate-500 mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      {loading && incidents.length === 0 ? (
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="w-5 h-5 text-slate-600 animate-spin mr-2" />
          <span className="text-slate-600 text-sm">Loading incidents...</span>
        </div>
      ) : error ? (
        <div className="p-4 rounded-xl bg-red-950/20 border border-red-900/30 text-red-400 text-sm flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />{error}
        </div>
      ) : incidents.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <CheckCircle className="w-10 h-10 text-slate-700 mb-3" />
          <h3 className="text-slate-400 font-semibold">No incidents recorded</h3>
          <p className="text-sm text-slate-600 mt-1">The sentinel grid is monitoring. No hazards detected yet.</p>
        </div>
      ) : (
        <div className="rounded-xl overflow-hidden border border-sentinel-border/60">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-sentinel-border/40" style={{ background: 'rgba(13,18,32,0.8)' }}>
                {['ID', 'Hazard', 'Location', 'Confidence', 'Status', 'Action', 'Time'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-sentinel-border/30">
              {incidents.map((inc) => {
                const st = STATUS_CONFIG[inc.status] || STATUS_CONFIG.pending
                const StIcon = st.icon
                return (
                  <tr key={inc.id} className="hover:bg-slate-800/20 transition-colors group">
                    <td className="px-4 py-3 font-mono text-xs text-slate-500">
                      #{String(inc.id).padStart(4, '0')}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-medium text-white whitespace-nowrap">{inc.hazard_type}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-slate-400">
                        <MapPin className="w-3 h-3 shrink-0" />
                        <span className="whitespace-nowrap">{inc.location_tag}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-amber-400">{inc.confidence}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold ${st.cls}`}>
                        <StIcon className="w-3 h-3" />
                        {st.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">
                      {inc.action_taken}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-xs text-slate-600 whitespace-nowrap">
                        <Clock className="w-3 h-3" />
                        {formatTime(inc.triggered_at)}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
