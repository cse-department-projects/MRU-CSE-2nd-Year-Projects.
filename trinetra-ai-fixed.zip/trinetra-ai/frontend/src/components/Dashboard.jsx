import { useState, useEffect, useCallback, useRef } from 'react'
import { Camera, Bell, Shield, Activity, Zap, AlertTriangle, CheckCircle, TrendingUp } from 'lucide-react'
import Sidebar from './Sidebar'
import StatusBar from './StatusBar'
import CameraPanel from './CameraPanel'
import IncidentLog from './IncidentLog'
import AlertPopup from './AlertPopup'
import { useWebSocket } from '../hooks/useWebSocket'
import { camerasAPI, incidentsAPI, testAPI } from '../api/client'
import { useAuth } from '../context/AuthContext'

// ─── Toast Notification ───────────────────────────────────────────────────────
function Toast({ toasts }) {
  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full">
      {toasts.map((t) => (
        <div key={t.id} className="toast-enter glass rounded-xl p-4 flex items-start gap-3 shadow-xl"
          style={{
            borderLeft: `3px solid ${t.type === 'success' ? '#06b6d4' : t.type === 'error' ? '#dc1a1a' : '#f59e0b'}`,
          }}>
          {t.type === 'success' ? <CheckCircle className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            : t.type === 'error' ? <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
            : <Bell className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />}
          <div>
            <div className="text-sm font-semibold text-white">{t.title}</div>
            {t.message && <div className="text-xs text-slate-400 mt-0.5">{t.message}</div>}
          </div>
        </div>
      ))}
    </div>
  )
}

// ─── Overview/Home Tab ────────────────────────────────────────────────────────
function OverviewTab({ cameras, incidents, onTabChange }) {
  const active = cameras.filter(c => c.status === 'active').length
  const dispatched = incidents.filter(i => i.status === 'dispatched').length
  const cancelled = incidents.filter(i => i.status === 'cancelled').length
  const now = new Date()
  const isToday = (iso) => {
    const d = new Date(iso)
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate()
  }
  const today = incidents.filter(i => isToday(i.triggered_at)).length

  const stats = [
    { label: 'Active Cameras', value: active, total: cameras.length, color: '#06b6d4', icon: Camera, tab: 'cameras' },
    { label: 'Incidents Today', value: today, color: '#f59e0b', icon: Bell, tab: 'incidents' },
    { label: '112 Dispatched', value: dispatched, color: '#dc1a1a', icon: Shield, tab: 'incidents' },
    { label: 'False Alarms', value: cancelled, color: '#22c55e', icon: CheckCircle, tab: 'incidents' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          Sentinel Overview
        </h2>
        <p className="text-sm text-slate-500 mt-0.5">Real-time system health and threat summary</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(({ label, value, total, color, icon: Icon, tab }) => (
          <button
            key={label}
            id={`stat-${label.replace(/\s/g, '-').toLowerCase()}`}
            onClick={() => onTabChange(tab)}
            className="text-left rounded-xl p-5 hover:scale-105 transition-all duration-200 cursor-pointer"
            style={{ background: 'rgba(13,18,32,0.9)', border: `1px solid rgba(${color === '#06b6d4' ? '6,182,212' : color === '#f59e0b' ? '245,158,11' : color === '#dc1a1a' ? '220,26,26' : '34,197,94'},0.2)` }}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{ background: `${color}18` }}>
                <Icon className="w-4.5 h-4.5" style={{ color, width: 18, height: 18 }} />
              </div>
              <TrendingUp className="w-3.5 h-3.5 text-slate-700" />
            </div>
            <div className="text-3xl font-black mb-0.5" style={{ color }}>
              {value}{total !== undefined && <span className="text-slate-600 text-lg font-normal">/{total}</span>}
            </div>
            <div className="text-xs text-slate-500 font-medium">{label}</div>
          </button>
        ))}
      </div>

      {/* Recent incidents */}
      {incidents.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider flex items-center gap-2">
            <Bell className="w-3.5 h-3.5" />
            Recent Incidents
          </h3>
          <div className="space-y-2">
            {incidents.slice(0, 5).map(inc => (
              <div key={inc.id} className="flex items-center gap-3 p-3 rounded-xl"
                style={{ background: 'rgba(13,18,32,0.7)', border: '1px solid rgba(30,45,69,0.5)' }}>
                <span className="text-xl">{inc.hazard_type.match(/^\S+/)?.[0] || '⚠️'}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{inc.hazard_type}</div>
                  <div className="text-xs text-slate-500">{inc.location_tag}</div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                  inc.status === 'dispatched' ? 'badge-dispatched' :
                  inc.status === 'cancelled' ? 'badge-cancelled' : 'badge-pending'
                }`}>
                  {inc.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick actions */}
      <div>
        <h3 className="text-sm font-semibold text-slate-400 mb-3 uppercase tracking-wider flex items-center gap-2">
          <Zap className="w-3.5 h-3.5" />
          Quick Actions
        </h3>
        <div className="flex gap-3 flex-wrap">
          <button id="quick-add-camera" onClick={() => onTabChange('cameras')} className="btn-primary px-4 py-2 text-sm flex items-center gap-2">
            <Camera className="w-4 h-4" /> Register Camera
          </button>
          <button id="quick-view-incidents" onClick={() => onTabChange('incidents')} className="btn-ghost px-4 py-2 text-sm flex items-center gap-2">
            <Bell className="w-4 h-4" /> View Incidents
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Dashboard ─────────────────────────────────────────────────────────────────
export default function Dashboard() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('dashboard')
  const [cameras, setCameras] = useState([])
  const [incidents, setIncidents] = useState([])
  const [notifications, setNotifications] = useState([])
  const [toasts, setToasts] = useState([])

  // Current alert popup state
  // Alerts waiting for the operator. The server runs a countdown PER incident, so a
  // second alert must queue up (never be silently ignored) or it would auto-dispatch unseen.
  const [alertQueue, setAlertQueue] = useState([])
  const [countdowns, setCountdowns] = useState({})
  const activeAlert = alertQueue[0] || null
  const alertCountdown = activeAlert
    ? (countdowns[activeAlert.incident_id] ?? activeAlert.timeout_seconds ?? 10)
    : 10
  const [activeScanners, setActiveScanners] = useState(0)
  const [recentEvent, setRecentEvent] = useState(null)

  const toastIdRef = useRef(0)

  const addToast = useCallback((title, message = '', type = 'info') => {
    const id = ++toastIdRef.current
    setToasts(prev => [...prev, { id, title, message, type }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 5000)
  }, [])

  // Load initial data
  useEffect(() => {
    camerasAPI.list().then(r => setCameras(r.data)).catch(() => {})
    incidentsAPI.list().then(r => setIncidents(r.data)).catch(() => {})
  }, [])

  const dropAlert = useCallback((incidentId) => {
    setAlertQueue(q => q.filter(a => a.incident_id !== incidentId))
  }, [])

  const refreshIncidents = useCallback(() => {
    incidentsAPI.list().then(r => setIncidents(r.data)).catch(() => {})
  }, [])

  // WebSocket message handler — event names/shapes are produced by backend-express
  // (services/realtime.js, services/incidentService.js).
  const handleWsMessage = useCallback((msg) => {
    setRecentEvent(msg)

    switch (msg.event) {
      case 'CONNECTED':
        addToast('Sentinel Grid Active', msg.message, 'success')
        break

      case 'HEARTBEAT':
        setActiveScanners(msg.active_scanners || 0)
        break

      case 'CAMERA_INIT':
        setNotifications(prev => [...prev.slice(-10), msg])
        addToast('Camera Initializing', msg.message, 'info')
        break

      case 'CAMERA_READY':
        setNotifications(prev => [...prev.slice(-10), msg])
        addToast('Camera Registered', msg.message, 'success')
        break

      case 'CAMERA_ERROR':
        setNotifications(prev => [...prev.slice(-10), msg])
        addToast('Camera Not Monitored', msg.message, 'error')
        break

      case 'HAZARD_ALERT':
        setAlertQueue(q => (q.some(a => a.incident_id === msg.incident_id) ? q : [...q, msg]))
        setIncidents(prev => (prev.some(i => i.id === msg.incident_id) ? prev : [{
          id: msg.incident_id,
          hazard_type: msg.hazard_type,
          location_tag: msg.location_tag,
          camera_id: msg.camera_id,
          status: 'pending',
          triggered_at: msg.timestamp,
          action_taken: 'Pending',
          confidence: msg.confidence,
        }, ...prev]))
        break

      case 'TIMER_TICK':
        setCountdowns(c => ({ ...c, [msg.incident_id]: msg.countdown }))
        break

      case 'DISPATCH_CONFIRMED':
        dropAlert(msg.incident_id)
        addToast('112 Dispatched', msg.message, 'error')
        setIncidents(prev => prev.map(i =>
          i.id === msg.incident_id
            ? { ...i, status: 'dispatched', action_taken: 'Auto-Called 112' }
            : i
        ))
        break

      case 'DISPATCH_FAILED':
        // Keep the popup open: the operator must call manually / press "Call 112 Now".
        addToast('112 DISPATCH FAILED', msg.message, 'error')
        break

      case 'INCIDENT_UPDATED':
        // Another tab / device acted on this incident.
        dropAlert(msg.incident_id)
        setIncidents(prev => prev.map(i =>
          i.id === msg.incident_id
            ? { ...i, status: msg.status, action_taken: msg.action_taken }
            : i
        ))
        break

      default:
        break
    }
  }, [addToast, dropAlert])

  const { connectionState, reconnect } = useWebSocket(handleWsMessage)

  const handleAlertCancel = useCallback(() => {
    const id = activeAlert?.incident_id
    if (id) {
      dropAlert(id)
      setIncidents(prev => prev.map(i =>
        i.id === id ? { ...i, status: 'cancelled', action_taken: 'User Dismissed' } : i
      ))
    }
    addToast('Alert Dismissed', 'Event logged as false alarm.', 'info')
  }, [activeAlert, dropAlert, addToast])

  const handleAlertConfirm = useCallback(() => {
    const id = activeAlert?.incident_id
    if (id) {
      dropAlert(id)
      setIncidents(prev => prev.map(i =>
        i.id === id ? { ...i, status: 'dispatched', action_taken: 'User Confirmed & Called 112' } : i
      ))
    }
    addToast('Emergency Dispatched', 'Call to 112 initiated successfully.', 'error')
  }, [activeAlert, dropAlert, addToast])

  // The server says this incident was already handled (auto-dispatch fired, or another tab acted).
  const handleAlertStale = useCallback(() => {
    if (activeAlert) dropAlert(activeAlert.incident_id)
    refreshIncidents()
    addToast('Alert Already Handled', 'This incident was resolved elsewhere.', 'info')
  }, [activeAlert, dropAlert, refreshIncidents, addToast])

  const pendingCount = incidents.filter(i => i.status === 'pending').length

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#080c14' }}>
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} incidentCount={pendingCount} />

      <div className="flex-1 flex flex-col overflow-hidden">
        <StatusBar
          connectionState={connectionState}
          onReconnect={reconnect}
          activeScanners={activeScanners}
          cameraCount={cameras.length}
        />


        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-sentinel-border/40"
          style={{ background: 'rgba(13,18,32,0.6)' }}>
          <div>
            <h1 className="text-lg font-bold text-white">
              {activeTab === 'dashboard' ? 'Sentinel Overview'
                : activeTab === 'cameras' ? 'Camera Network'
                : 'Incident Log'}
            </h1>
            <p className="text-xs text-slate-500 font-mono mt-0.5">
              Welcome, <span className="text-cyan-400">{user?.username}</span> — Trinetra AI Operator
            </p>
          </div>
          {/* Test trigger button — visible in dev/testing only; server blocks it in production */}
          {cameras.length > 0 && (
            <button
              id="test-alert-btn"
              onClick={async () => {
                try {
                  await testAPI.triggerAlert()
                  addToast('Test Alert Triggered', 'Simulated hazard raised — the alert popup and 10 s countdown should appear.', 'info')
                } catch (e) {
                  if (e.response?.status === 403) {
                    addToast(
                      'Blocked in Production',
                      'Set NODE_ENV=development in backend-express/.env to enable test alerts.',
                      'error'
                    )
                  } else if (e.response?.status === 400) {
                    addToast('No Cameras', 'Register at least one camera first.', 'error')
                  } else {
                    addToast('Test Failed', e.response?.data?.detail || 'Backend unreachable.', 'error')
                  }
                }
              }}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-amber-400 hover:bg-amber-900/20 transition-colors border border-amber-900/30 hover:border-amber-800/50"
              title="POST /api/alerts/test — raises a simulated hazard (popup + countdown)"
            >
              <Zap className="w-3.5 h-3.5" />
              Test Alert
              <span className="ml-1 px-1.5 py-0.5 rounded text-amber-600 bg-amber-950/60 font-mono text-[10px] border border-amber-900/40">DEV</span>
            </button>
          )}
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          {activeTab === 'dashboard' && (
            <OverviewTab cameras={cameras} incidents={incidents} onTabChange={setActiveTab} />
          )}
          {activeTab === 'cameras' && (
            <CameraPanel cameras={cameras} onCamerasChange={setCameras} notifications={notifications} />
          )}
          {activeTab === 'incidents' && (
            <IncidentLog recentEvent={recentEvent} />
          )}
        </main>
      </div>

      {/* Alert popup */}
      {activeAlert && (
        <AlertPopup
          key={activeAlert.incident_id}
          alert={activeAlert}
          countdown={alertCountdown}
          onCancel={handleAlertCancel}
          onConfirm={handleAlertConfirm}
          onStale={handleAlertStale}
        />
      )}

      {/* Toasts */}
      <Toast toasts={toasts} />
    </div>
  )
}
