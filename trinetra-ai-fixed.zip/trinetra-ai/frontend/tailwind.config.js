/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Digital Sentinel Theme
        sentinel: {
          bg: '#080c14',
          surface: '#0d1220',
          card: '#111827',
          border: '#1e2d45',
          borderHover: '#2d4a6e',
        },
        crimson: {
          DEFAULT: '#dc1a1a',
          light: '#ff2d2d',
          dark: '#990f0f',
          glow: 'rgba(220, 26, 26, 0.4)',
        },
        amber: {
          alert: '#f59e0b',
          glow: 'rgba(245, 158, 11, 0.4)',
        },
        teal: {
          active: '#06b6d4',
          glow: 'rgba(6, 182, 212, 0.3)',
        },
        slate: {
          text: '#94a3b8',
          muted: '#475569',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      animation: {
        'pulse-crimson': 'pulse-crimson 1.5s ease-in-out infinite',
        'scan-line': 'scan-line 3s linear infinite',
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite',
        'fade-in': 'fade-in 0.5s ease-out',
        'slide-up': 'slide-up 0.4s ease-out',
        'scale-in': 'scale-in 0.3s ease-out',
        'spin-slow': 'spin 4s linear infinite',
        'blink': 'blink 1s step-start infinite',
        'shimmer': 'shimmer 2s linear infinite',
        'alert-flash': 'alert-flash 0.5s ease-in-out infinite',
      },
      keyframes: {
        'pulse-crimson': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(220, 26, 26, 0.7)' },
          '50%': { boxShadow: '0 0 0 10px rgba(220, 26, 26, 0)' },
        },
        'scan-line': {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        'glow-pulse': {
          '0%, 100%': { opacity: '0.6' },
          '50%': { opacity: '1' },
        },
        'fade-in': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        'slide-up': {
          from: { transform: 'translateY(20px)', opacity: '0' },
          to: { transform: 'translateY(0)', opacity: '1' },
        },
        'scale-in': {
          from: { transform: 'scale(0.9)', opacity: '0' },
          to: { transform: 'scale(1)', opacity: '1' },
        },
        'blink': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'alert-flash': {
          '0%, 100%': { borderColor: 'rgba(220, 26, 26, 0.8)' },
          '50%': { borderColor: 'rgba(220, 26, 26, 0.2)' },
        }
      },
      backgroundImage: {
        'grid-pattern': `
          linear-gradient(rgba(6, 182, 212, 0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(6, 182, 212, 0.03) 1px, transparent 1px)
        `,
      },
      backgroundSize: {
        'grid': '40px 40px',
      }
    },
  },
  plugins: [],
}
