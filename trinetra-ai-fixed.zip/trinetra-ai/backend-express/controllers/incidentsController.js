/**
 * controllers/incidentsController.js — Incident log management
 *
 * Incidents are camera-scoped: a user can only see/act on incidents from their
 * own cameras (every query JOINs incident_logs → cameras).
 *
 * State changes use a conditional UPDATE (`... AND status = 'pending'`) and
 * check affectedRows, so a manual action and the 10-second auto-dispatch can
 * never both "win" — exactly one transition happens.
 */

'use strict';

const { pool } = require('../config/db');
const { IS_PROD } = require('../config/env');
const realtime = require('../services/realtime');
const { raiseIncident } = require('../services/incidentService');

const INCIDENT_COLUMNS = `
  il.id, il.camera_id, il.hazard_type, il.status, il.triggered_at,
  il.action_taken, il.location_tag, il.confidence`;

// ── GET /api/incidents ────────────────────────────────────────────────────────
async function list(req, res) {
  try {
    const [incidents] = await pool.query(
      `SELECT ${INCIDENT_COLUMNS}
         FROM incident_logs il
        INNER JOIN cameras c ON c.id = il.camera_id
        WHERE c.user_id = ?
        ORDER BY il.triggered_at DESC`,
      [req.user.sub]
    );
    return res.status(200).json(incidents);
  } catch (err) {
    console.error('[Incidents] list error:', err);
    return res.status(500).json({ detail: 'Failed to retrieve incidents.' });
  }
}

/**
 * Shared implementation of cancel / confirm.
 * @param {'cancelled'|'dispatched'} newStatus
 */
async function transition(req, res, { newStatus, action, verb, okMessage }) {
  const userId = req.user.sub;
  const incidentId = parseInt(req.params.id, 10);
  if (!Number.isInteger(incidentId)) return res.status(404).json({ detail: 'Incident not found.' });

  try {
    const [[incident]] = await pool.query(
      `SELECT il.id, il.status, il.hazard_type, il.location_tag
         FROM incident_logs il
        INNER JOIN cameras c ON c.id = il.camera_id
        WHERE il.id = ? AND c.user_id = ?
        LIMIT 1`,
      [incidentId, userId]
    );
    if (!incident) return res.status(404).json({ detail: 'Incident not found.' });

    if (incident.status !== 'pending') {
      return res.status(400).json({
        detail: `Cannot ${verb} incident — current status is "${incident.status}".`,
      });
    }

    const [result] = await pool.query(
      `UPDATE incident_logs SET status = ?, action_taken = ? WHERE id = ? AND status = 'pending'`,
      [newStatus, action, incidentId]
    );
    if (result.affectedRows !== 1) {
      // Lost the race (auto-dispatch fired a moment ago).
      return res.status(400).json({ detail: `Cannot ${verb} incident — it was just auto-dispatched.` });
    }

    realtime.cancelDispatchTimer(incidentId);
    realtime.broadcastToUser(userId, {
      event: 'INCIDENT_UPDATED',
      incident_id: incidentId,
      status: newStatus,
      action_taken: action,
    });

    if (newStatus === 'dispatched') {
      // ── Mock 112 dispatch ───────────────────────────────────────────────────
      // In production: call a real Twilio or emergency dispatch API here.
      console.warn(
        `[DISPATCH] *** MOCK 112 CALL *** Incident #${incidentId} | ` +
        `${incident.hazard_type} @ ${incident.location_tag} | User ${userId} confirmed`
      );
    } else {
      console.log(`[Incidents] #${incidentId} cancelled by user ${userId}`);
    }

    return res.status(200).json({ detail: okMessage, incident_id: incidentId });

  } catch (err) {
    console.error(`[Incidents] ${verb} error:`, err);
    return res.status(500).json({ detail: `Failed to ${verb} incident.` });
  }
}

// ── POST /api/incidents/:id/cancel ────────────────────────────────────────────
const cancel = (req, res) => transition(req, res, {
  newStatus: 'cancelled',
  action:    'User Dismissed',
  verb:      'cancel',
  okMessage: 'Incident cancelled successfully.',
});

// ── POST /api/incidents/:id/confirm ───────────────────────────────────────────
const confirm = (req, res) => transition(req, res, {
  newStatus: 'dispatched',
  action:    'User Confirmed & Called 112',
  verb:      'confirm',
  okMessage: 'Emergency services notified. Incident marked as dispatched.',
});

// ── POST /api/alerts/test ─────────────────────────────────────────────────────
// Raises a simulated incident on the user's first active camera. It goes
// through the SAME path as a real detection: DB row → HAZARD_ALERT over the
// WebSocket → popup + countdown → auto-dispatch unless the operator reacts.
async function testAlert(req, res) {
  if (IS_PROD) {
    return res.status(403).json({
      detail: 'Test alerts are disabled in production. Set NODE_ENV=development in backend-express/.env to enable.',
    });
  }

  const userId = req.user.sub;

  try {
    const [[camera]] = await pool.query(
      `SELECT id, user_id, device_name, location_tag FROM cameras
        WHERE user_id = ? AND status = 'active'
        ORDER BY id ASC LIMIT 1`,
      [userId]
    );
    if (!camera) {
      return res.status(400).json({ detail: 'No active cameras registered. Add a camera first.' });
    }

    const hazards = ['fire', 'smoke', 'intrusion', 'fall'];
    const alert = await raiseIncident({
      camera,
      hazardType: hazards[Math.floor(Math.random() * hazards.length)],
      confidence: 0.85 + Math.random() * 0.14,
    });

    return res.status(200).json({ status: 'test alert triggered', incident_id: alert.incident_id });

  } catch (err) {
    console.error('[Incidents] testAlert error:', err);
    return res.status(500).json({ detail: 'Failed to create test alert.' });
  }
}

module.exports = { list, cancel, confirm, testAlert };
