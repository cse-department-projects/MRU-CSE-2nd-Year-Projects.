/**
 * controllers/camerasController.js — CRUD for user's CCTV cameras
 *
 * All queries are scoped to the authenticated user (req.user.sub).
 * Registering / activating a camera also starts its RTSP + CV pipeline on the
 * Python engine; removing / deactivating stops it (best-effort, non-blocking).
 */

'use strict';

const { pool } = require('../config/db');
const cvEngine = require('../services/cvEngine');
const realtime = require('../services/realtime');

const CAMERA_COLUMNS = 'id, user_id, device_name, stream_url, location_tag, status, created_at';

/** Start the CV pipeline in the background and tell the dashboard how it went. */
function startPipelineInBackground(camera) {
  realtime.broadcastToUser(camera.user_id, {
    event: 'CAMERA_INIT',
    camera_id: camera.id,
    device_name: camera.device_name,
    message: `Connecting '${camera.device_name}' at ${camera.location_tag} to the CV engine...`,
  });

  cvEngine.startCamera(camera).then((r) => {
    if (r.ok) {
      realtime.broadcastToUser(camera.user_id, {
        event: 'CAMERA_READY',
        camera_id: camera.id,
        device_name: camera.device_name,
        message: `'${camera.device_name}' registered with the CV engine; connecting to its stream.`,
      });
    } else {
      realtime.broadcastToUser(camera.user_id, {
        event: 'CAMERA_ERROR',
        camera_id: camera.id,
        device_name: camera.device_name,
        message: `'${camera.device_name}' saved, but monitoring is NOT running: ${r.detail}. It will retry automatically.`,
      });
    }
  });
}

// ── GET /api/cameras ──────────────────────────────────────────────────────────
async function list(req, res) {
  try {
    const [cameras] = await pool.query(
      `SELECT ${CAMERA_COLUMNS} FROM cameras WHERE user_id = ? ORDER BY created_at DESC`,
      [req.user.sub]
    );
    return res.status(200).json(cameras);
  } catch (err) {
    console.error('[Cameras] list error:', err);
    return res.status(500).json({ detail: 'Failed to retrieve cameras.' });
  }
}

// ── POST /api/cameras ─────────────────────────────────────────────────────────
async function register(req, res) {
  const userId = req.user.sub;
  const { device_name, stream_url, location_tag } = req.body;

  try {
    const [result] = await pool.query(
      `INSERT INTO cameras (user_id, device_name, stream_url, location_tag, status)
       VALUES (?, ?, ?, ?, 'active')`,
      [userId, device_name, stream_url, location_tag]
    );
    const [[camera]] = await pool.query(`SELECT ${CAMERA_COLUMNS} FROM cameras WHERE id = ?`, [result.insertId]);

    console.log(`[Cameras] Registered #${camera.id} "${device_name}" for user ${userId}`);
    startPipelineInBackground(camera);
    realtime.pushHeartbeat(userId).catch(() => {});
    return res.status(201).json(camera);

  } catch (err) {
    console.error('[Cameras] register error:', err);
    return res.status(500).json({ detail: 'Failed to register camera.' });
  }
}

// ── DELETE /api/cameras/:id ───────────────────────────────────────────────────
async function remove(req, res) {
  const userId = req.user.sub;
  const cameraId = parseInt(req.params.id, 10);
  if (!Number.isInteger(cameraId)) return res.status(404).json({ detail: 'Camera not found.' });

  try {
    const [[camera]] = await pool.query(
      'SELECT id FROM cameras WHERE id = ? AND user_id = ? LIMIT 1',
      [cameraId, userId]
    );
    if (!camera) return res.status(404).json({ detail: 'Camera not found.' });

    // Pending incidents of this camera are removed by ON DELETE CASCADE, so
    // their countdowns must not fire against rows that no longer exist.
    const [pending] = await pool.query(
      `SELECT id FROM incident_logs WHERE camera_id = ? AND status = 'pending'`,
      [cameraId]
    );
    pending.forEach((p) => realtime.cancelDispatchTimer(p.id));

    await pool.query('DELETE FROM cameras WHERE id = ?', [cameraId]);
    cvEngine.stopCamera(cameraId);   // fire-and-forget
    realtime.pushHeartbeat(userId).catch(() => {});

    console.log(`[Cameras] Deleted #${cameraId} for user ${userId}`);
    return res.status(204).send();

  } catch (err) {
    console.error('[Cameras] delete error:', err);
    return res.status(500).json({ detail: 'Failed to delete camera.' });
  }
}

// ── PUT /api/cameras/:id/status ───────────────────────────────────────────────
async function toggleStatus(req, res) {
  const userId = req.user.sub;
  const cameraId = parseInt(req.params.id, 10);
  if (!Number.isInteger(cameraId)) return res.status(404).json({ detail: 'Camera not found.' });

  try {
    const [[camera]] = await pool.query(
      'SELECT id, status FROM cameras WHERE id = ? AND user_id = ? LIMIT 1',
      [cameraId, userId]
    );
    if (!camera) return res.status(404).json({ detail: 'Camera not found.' });

    const newStatus = camera.status === 'active' ? 'inactive' : 'active';
    await pool.query('UPDATE cameras SET status = ? WHERE id = ?', [newStatus, cameraId]);

    const [[updated]] = await pool.query(`SELECT ${CAMERA_COLUMNS} FROM cameras WHERE id = ?`, [cameraId]);

    if (newStatus === 'active') startPipelineInBackground(updated);
    else cvEngine.stopCamera(cameraId);
    realtime.pushHeartbeat(userId).catch(() => {});

    console.log(`[Cameras] #${cameraId} toggled to "${newStatus}" by user ${userId}`);
    return res.status(200).json(updated);

  } catch (err) {
    console.error('[Cameras] toggleStatus error:', err);
    return res.status(500).json({ detail: 'Failed to update camera status.' });
  }
}

module.exports = { list, register, remove, toggleStatus };
