/**
 * controllers/authController.js — Register, Login, and Profile handlers
 *
 * Passwords are hashed with bcrypt (cost 12) — never stored in plain text.
 * Response shapes match what the React frontend (AuthContext.jsx) expects.
 */

'use strict';

const bcrypt = require('bcrypt');
const { pool } = require('../config/db');
const { signToken } = require('../middleware/auth');

const BCRYPT_ROUNDS = 12;

// Compared against when the username doesn't exist, so "unknown user" and
// "wrong password" take about the same time (prevents username enumeration).
let dummyHashPromise = null;
const getDummyHash = () => (dummyHashPromise ||= bcrypt.hash('trinetra-dummy-password', BCRYPT_ROUNDS));

function publicUser(u) {
  return { id: u.id, username: u.username, email: u.email, created_at: u.created_at };
}

// ── POST /api/register ────────────────────────────────────────────────────────
async function register(req, res) {
  const { username, email, password } = req.body;

  try {
    const [userRows] = await pool.query('SELECT id FROM users WHERE username = ? LIMIT 1', [username]);
    if (userRows.length > 0) {
      return res.status(400).json({ detail: 'Username already registered.' });
    }
    const [emailRows] = await pool.query('SELECT id FROM users WHERE email = ? LIMIT 1', [email]);
    if (emailRows.length > 0) {
      return res.status(400).json({ detail: 'Email already registered.' });
    }

    const password_hash = await bcrypt.hash(password, BCRYPT_ROUNDS);

    const [result] = await pool.query(
      'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
      [username, email, password_hash]
    );

    const [[newUser]] = await pool.query(
      'SELECT id, username, email, created_at FROM users WHERE id = ?',
      [result.insertId]
    );

    console.log(`[Auth] Registered new user: "${username}" (id=${newUser.id})`);

    return res.status(201).json({
      access_token: signToken(newUser),
      token_type:   'bearer',
      user:         publicUser(newUser),
    });

  } catch (err) {
    // Two simultaneous sign-ups can both pass the checks above; the UNIQUE
    // indexes still catch the loser — report it as a normal 400, not a 500.
    if (err.code === 'ER_DUP_ENTRY') {
      const which = /email/i.test(err.sqlMessage || '') ? 'Email' : 'Username';
      return res.status(400).json({ detail: `${which} already registered.` });
    }
    console.error('[Auth] Register error:', err);
    return res.status(500).json({ detail: 'Internal server error during registration.' });
  }
}

// ── POST /api/login ───────────────────────────────────────────────────────────
async function login(req, res) {
  const { username, password } = req.body;

  try {
    const [rows] = await pool.query(
      'SELECT id, username, email, password_hash, created_at FROM users WHERE username = ? LIMIT 1',
      [username]
    );
    const user = rows[0];

    const valid = await bcrypt.compare(password, user ? user.password_hash : await getDummyHash());
    if (!user || !valid) {
      return res.status(401).json({ detail: 'Invalid username or password.' });
    }

    console.log(`[Auth] Login: "${username}" (id=${user.id})`);

    return res.status(200).json({
      access_token: signToken(user),
      token_type:   'bearer',
      user:         publicUser(user),
    });

  } catch (err) {
    console.error('[Auth] Login error:', err);
    return res.status(500).json({ detail: 'Internal server error during login.' });
  }
}

// ── GET /api/me ───────────────────────────────────────────────────────────────
async function me(req, res) {
  try {
    const [[user]] = await pool.query(
      'SELECT id, username, email, created_at FROM users WHERE id = ? LIMIT 1',
      [req.user.sub]
    );
    if (!user) return res.status(404).json({ detail: 'User not found.' });
    return res.status(200).json(publicUser(user));
  } catch (err) {
    console.error('[Auth] /me error:', err);
    return res.status(500).json({ detail: 'Internal server error.' });
  }
}

module.exports = { register, login, me };
