/**
 * controllers/internalController.js — server-to-server endpoints (CV engine → Express)
 *
 * POST /api/internal/alerts   (header: X-Internal-Key)
 *   Called by the Python CV engine when its detector fires. Creates the
 *   incident, pushes HAZARD_ALERT to the camera owner's dashboard and starts
 *   the 10-second auto-dispatch countdown.
 */

'use strict';

const { pool } = require('../config/db');
const { ALERT_COOLDOWN_SECONDS } = require('../config/env');
const { raiseIncident, hasRecentIncident } = require('../services/incidentService');

async function raiseAlert(req, res) {
  const { camera_id, hazard, confidence } = req.body;

  try {
    const [[camera]] = await pool.query(
      `SELECT id, user_id, device_name, location_tag, status FROM cameras WHERE id = ? LIMIT 1`,
      [camera_id]
    );
    if (!camera) return res.status(404).json({ detail: `Camera #${camera_id} not found.` });

    if (camera.status !== 'active') {
      return res.status(202).json({ suppressed: 'camera_inactive' });
    }

    // The detector can fire on every frame (~5/s). One incident per camera per
    // cooldown window is enough — the operator is already being alerted.
    if (await hasRecentIncident(camera.id, ALERT_COOLDOWN_SECONDS)) {
      return res.status(202).json({ suppressed: 'cooldown' });
    }

    const alert = await raiseIncident({ camera, hazardType: hazard, confidence });
    return res.status(201).json({ incident_id: alert.incident_id });

  } catch (err) {
    console.error('[Internal] raiseAlert error:', err);
    return res.status(500).json({ detail: 'Failed to record alert.' });
  }
}

module.exports = { raiseAlert };
