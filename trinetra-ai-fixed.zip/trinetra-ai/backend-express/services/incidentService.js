/**
 * services/incidentService.js — create an incident, alert the operator, start the countdown.
 *
 * Single entry point used by BOTH the manual "Test Alert" button and the
 * Python CV engine (via POST /api/internal/alerts), so they behave identically.
 */

'use strict';

const { pool } = require('../config/db');
const { ALERT_TIMEOUT_SECONDS } = require('../config/env');
const realtime = require('./realtime');

const HAZARD_LABELS = {
  fire:        '🔥 Fire Detected',
  smoke:       '💨 Smoke Detected',
  intrusion:   '🚨 Intrusion Detected',
  fall:        '🫸 Fall Detected',
  crowd_surge: '👥 Crowd Surge Detected',
};

function hazardLabel(code) {
  const key = String(code || '').toLowerCase();
  if (HAZARD_LABELS[key]) return HAZARD_LABELS[key];
  const pretty = key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  return `⚠️ ${pretty || 'Hazard'} Detected`;
}

/** Accepts 0–1 or 0–100 (or a ready-made "93.1%" string) → "93.1%". */
function confidenceLabel(value) {
  if (typeof value === 'string' && value.trim()) return value.trim().slice(0, 20);
  const n = Number(value);
  if (!Number.isFinite(n)) return 'N/A';
  const pct = Math.min(Math.max(n <= 1 ? n * 100 : n, 0), 100);
  return `${pct.toFixed(1)}%`;
}

/** True if this camera already raised an incident within the last `seconds`. */
async function hasRecentIncident(cameraId, seconds) {
  if (seconds <= 0) return false;
  const [rows] = await pool.query(
    `SELECT 1 FROM incident_logs
      WHERE camera_id = ? AND triggered_at > (UTC_TIMESTAMP() - INTERVAL ? SECOND)
      LIMIT 1`,
    [cameraId, seconds]
  );
  return rows.length > 0;
}

/**
 * @param {object} p
 * @param {{id:number,user_id:number,device_name:string,location_tag:string}} p.camera
 * @param {string} p.hazardType   machine code ("fire") or display label
 * @param {number|string} [p.confidence]
 * @returns {Promise<object>} the HAZARD_ALERT payload
 */
async function raiseIncident({ camera, hazardType, confidence }) {
  // Display labels ("🔥 Fire Detected") contain spaces; machine codes ("fire") don't.
  const raw   = String(hazardType);
  const label = /\s/.test(raw) ? raw : hazardLabel(raw);
  const conf = confidenceLabel(confidence);

  const [result] = await pool.query(
    `INSERT INTO incident_logs (camera_id, hazard_type, status, action_taken, location_tag, confidence)
     VALUES (?, ?, 'pending', 'Pending', ?, ?)`,
    [camera.id, label.slice(0, 100), camera.location_tag, conf]
  );

  const alert = {
    event:           'HAZARD_ALERT',
    incident_id:     result.insertId,
    hazard_type:     label,
    location_tag:    camera.location_tag,
    camera_id:       camera.id,
    device_name:     camera.device_name,
    confidence:      conf,
    severity:        'CRITICAL',
    timestamp:       new Date().toISOString(),
    timeout_seconds: ALERT_TIMEOUT_SECONDS,
  };

  const delivered = realtime.broadcastToUser(camera.user_id, alert);
  realtime.startDispatchTimer(camera.user_id, alert);

  console.warn(
    `[Incident] #${alert.incident_id} ${label} @ ${camera.location_tag} ` +
    `(user ${camera.user_id}, ${delivered} dashboard(s) notified, ${ALERT_TIMEOUT_SECONDS}s to respond)`
  );
  return alert;
}

module.exports = { raiseIncident, hasRecentIncident, hazardLabel, confidenceLabel };
