/**
 * services/realtime.js — WebSocket fan-out + server-side auto-dispatch timers
 *
 * This is the real-time layer the React dashboard depends on. It owns:
 *   - the registry of connected WebSocket clients (per user)
 *   - the 10-second "operator must react or 112 is called" countdown
 *
 * The countdown runs on the SERVER, so it keeps going if the browser tab is
 * closed or the page is refreshed (a refreshed dashboard gets the active alert
 * replayed on reconnect).
 *
 * Events pushed to the browser (shapes match what Dashboard.jsx consumes):
 *   HAZARD_ALERT, TIMER_TICK, DISPATCH_CONFIRMED, DISPATCH_FAILED,
 *   INCIDENT_UPDATED, CAMERA_INIT, CAMERA_READY, CAMERA_ERROR, HEARTBEAT
 */

'use strict';

const { pool } = require('../config/db');
const { ALERT_TIMEOUT_SECONDS } = require('../config/env');

// Keys are ALWAYS strings: a JWT `sub` may be a number, and Map keys 5 !== '5'.
const wsClients = new Map();   // String(userId) -> Set<WebSocket>
const timers    = new Map();   // incidentId     -> timer state

const OPEN = 1; // WebSocket.OPEN (avoid importing ws here)
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const uid = (userId) => String(userId);

// ── Client registry ───────────────────────────────────────────────────────────

function addClient(userId, ws) {
  const key = uid(userId);
  if (!wsClients.has(key)) wsClients.set(key, new Set());
  wsClients.get(key).add(ws);
  return wsClients.get(key).size;
}

function removeClient(userId, ws) {
  const key = uid(userId);
  const set = wsClients.get(key);
  if (!set) return;
  set.delete(ws);
  if (set.size === 0) wsClients.delete(key);
}

/** Send a JSON event to every open socket of one user. Returns delivery count. */
function broadcastToUser(userId, payload) {
  const set = wsClients.get(uid(userId));
  if (!set) return 0;
  const message = JSON.stringify(payload);
  let delivered = 0;
  for (const ws of set) {
    if (ws.readyState === OPEN) {
      ws.send(message);
      delivered += 1;
    }
  }
  return delivered;
}

/** Re-send any still-counting-down alerts to a (re)connecting socket. */
function replayActiveAlerts(userId, ws) {
  for (const state of timers.values()) {
    if (uid(state.userId) !== uid(userId)) continue;
    if (ws.readyState !== OPEN) return;
    ws.send(JSON.stringify(state.alert));
    ws.send(JSON.stringify({
      event: 'TIMER_TICK',
      incident_id: state.alert.incident_id,
      countdown: state.lastCountdown,
    }));
  }
}

// ── Auto-dispatch countdown ───────────────────────────────────────────────────

/**
 * Atomically flip a still-pending incident to dispatched. The
 * `AND status = 'pending'` guard means that if the operator confirmed or
 * cancelled first, this is a no-op instead of overwriting their decision.
 */
async function autoDispatch(state) {
  const incidentId = state.alert.incident_id;

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const [result] = await pool.query(
        `UPDATE incident_logs
            SET status = 'dispatched', action_taken = 'Auto-Called 112'
          WHERE id = ? AND status = 'pending'`,
        [incidentId]
      );
      if (result.affectedRows !== 1) return false;   // user acted first

      // ── Mock 112 dispatch ─────────────────────────────────────────────────
      // In production, call a real Twilio / emergency-dispatch API here.
      console.warn(
        `[DISPATCH] *** MOCK 112 CALL (auto) *** Incident #${incidentId} | ` +
        `${state.alert.hazard_type} @ ${state.alert.location_tag} | no operator response`
      );

      broadcastToUser(state.userId, {
        event: 'DISPATCH_CONFIRMED',
        incident_id: incidentId,
        message: `Emergency 112 auto-dispatched for ${state.alert.hazard_type} at ${state.alert.location_tag}.`,
        call_sid: `MOCK-${incidentId}-${Date.now()}`,
      });
      return true;
    } catch (err) {
      console.error(`[Timer] Auto-dispatch for #${incidentId} failed (attempt ${attempt}/3):`, err.message);
      if (attempt < 3) await sleep(1000);
    }
  }

  broadcastToUser(state.userId, {
    event: 'DISPATCH_FAILED',
    incident_id: incidentId,
    message: 'Automatic 112 dispatch FAILED (database error). Call emergency services manually!',
  });
  return false;
}

/**
 * Start the countdown for a freshly created incident.
 * @param {number} userId  owner of the camera
 * @param {object} alert   the HAZARD_ALERT payload that was broadcast
 */
function startDispatchTimer(userId, alert) {
  const incidentId = alert.incident_id;
  if (timers.has(incidentId)) return;

  const state = {
    userId,
    alert,
    remaining: ALERT_TIMEOUT_SECONDS,
    lastCountdown: ALERT_TIMEOUT_SECONDS,
    handle: null,
  };
  timers.set(incidentId, state);

  const tick = () => {
    if (timers.get(incidentId) !== state) return;      // cancelled meanwhile

    if (state.remaining > 0) {
      state.lastCountdown = state.remaining;
      broadcastToUser(userId, {
        event: 'TIMER_TICK',
        incident_id: incidentId,
        countdown: state.remaining,
      });
      state.remaining -= 1;
      state.handle = setTimeout(tick, 1000);
      return;
    }

    timers.delete(incidentId);
    autoDispatch(state).catch((err) => console.error('[Timer] autoDispatch crashed:', err));
  };

  tick();
}

/** Stop the countdown (operator confirmed / cancelled, or camera deleted). */
function cancelDispatchTimer(incidentId) {
  const state = timers.get(incidentId);
  if (!state) return false;
  clearTimeout(state.handle);
  timers.delete(incidentId);
  return true;
}

// ── Scanner count / heartbeat ─────────────────────────────────────────────────

async function activeScannerCount(userId) {
  try {
    const [[row]] = await pool.query(
      `SELECT COUNT(*) AS n FROM cameras WHERE user_id = ? AND status = 'active'`,
      [userId]
    );
    return Number(row.n) || 0;
  } catch {
    return 0;
  }
}

/** Push a fresh HEARTBEAT (with the up-to-date active-camera count) to a user's dashboards. */
async function pushHeartbeat(userId) {
  broadcastToUser(userId, {
    event:           'HEARTBEAT',
    active_scanners: await activeScannerCount(userId),
    timestamp:       new Date().toISOString(),
  });
}

function activeTimerCount() { return timers.size; }

function stopAllTimers() {
  for (const state of timers.values()) clearTimeout(state.handle);
  timers.clear();
}

module.exports = {
  addClient,
  removeClient,
  broadcastToUser,
  replayActiveAlerts,
  startDispatchTimer,
  cancelDispatchTimer,
  activeTimerCount,
  activeScannerCount,
  pushHeartbeat,
  stopAllTimers,
  clientCount: (userId) => wsClients.get(uid(userId))?.size || 0,
};
