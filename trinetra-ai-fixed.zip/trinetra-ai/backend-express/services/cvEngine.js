/**
 * services/cvEngine.js — client for the Python RTSP + CV engine (port 8001)
 *
 * Express is the single source of truth for cameras (MySQL). This module
 * pushes that state to the CV engine: start a stream when a camera is
 * registered / activated, stop it when removed / deactivated, and a periodic
 * reconcile so the engine heals itself after a restart.
 *
 * Every call is best-effort: the CV engine being down must never break the
 * dashboard, so failures are returned as { ok:false, detail } — never thrown.
 */

'use strict';

const { CV_ENGINE_URL, INTERNAL_API_KEY } = require('../config/env');

const enabled = () => Boolean(INTERNAL_API_KEY);

async function call(method, path, body) {
  const res = await fetch(`${CV_ENGINE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Internal-Key': INTERNAL_API_KEY },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(5000),
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty body (204) */ }
  return { status: res.status, data };
}

function describeFailure(status, data) {
  const detail = data && data.detail;
  if (Array.isArray(detail) && detail[0]?.msg) return `CV engine rejected the camera: ${detail[0].msg}`;
  if (typeof detail === 'string') return `CV engine: ${detail}`;
  return `CV engine returned HTTP ${status}`;
}

function describeError(err) {
  return `CV engine unreachable at ${CV_ENGINE_URL} (${err.cause?.code || err.message})`;
}

async function startCamera(camera) {
  if (!enabled()) return { ok: false, detail: 'CV integration disabled (INTERNAL_API_KEY not set).' };
  try {
    const { status, data } = await call('POST', '/api/cameras', {
      camera_id: camera.id,
      stream_url: camera.stream_url,
    });
    if (status === 201 || status === 409) return { ok: true, status };   // 409 = already running
    return { ok: false, status, detail: describeFailure(status, data) };
  } catch (err) {
    return { ok: false, detail: describeError(err) };
  }
}

async function stopCamera(cameraId) {
  if (!enabled()) return { ok: false, detail: 'CV integration disabled.' };
  try {
    const { status } = await call('DELETE', `/api/cameras/${cameraId}`);
    return { ok: status === 204 || status === 404, status };
  } catch (err) {
    return { ok: false, detail: describeError(err) };
  }
}

async function listRunning() {
  try {
    const { status, data } = await call('GET', '/api/cameras');
    if (status !== 200 || !data) return null;
    return data.active_cameras || [];
  } catch {
    return null;
  }
}

let lastSummary = '';

/**
 * Make the CV engine match the database: start every active camera that isn't
 * running, stop any running stream whose camera is gone / inactive.
 */
async function syncActiveCameras(pool) {
  if (!enabled()) return;

  const running = await listRunning();
  if (running === null) {
    const summary = 'unreachable';
    if (summary !== lastSummary) console.warn(`[CV] ${describeError({ message: 'no response' })} — will retry every 60s`);
    lastSummary = summary;
    return;
  }

  const [rows] = await pool.query(`SELECT id, stream_url FROM cameras WHERE status = 'active'`);
  const wanted = new Set(rows.map((r) => r.id));
  const started = [];
  const failed = [];

  for (const cam of rows) {
    if (running.includes(cam.id)) continue;
    const r = await startCamera(cam);
    (r.ok ? started : failed).push(cam.id);
  }
  const stopped = [];
  for (const id of running) {
    if (!wanted.has(id)) { await stopCamera(id); stopped.push(id); }
  }

  const summary = `ok started=${started} failed=${failed} stopped=${stopped}`;
  if ((started.length || failed.length || stopped.length) && summary !== lastSummary) {
    console.log(`[CV] Sync: started [${started}] failed [${failed}] stopped [${stopped}]`);
  }
  lastSummary = summary;
}

function startSyncLoop(pool, intervalMs = 60_000) {
  if (!enabled()) {
    console.warn('[CV] INTERNAL_API_KEY not set — CV engine integration is OFF (Test Alert still works).');
    return null;
  }
  const run = () => syncActiveCameras(pool).catch((e) => console.error('[CV] sync error:', e.message));
  const first = setTimeout(run, 5000);
  const loop = setInterval(run, intervalMs);
  if (first.unref) first.unref();
  if (loop.unref) loop.unref();
  return loop;
}

module.exports = { startCamera, stopCamera, listRunning, syncActiveCameras, startSyncLoop };
