/**
 * routes/internal.js — /api/internal/* (server-to-server, X-Internal-Key)
 */

'use strict';

const { Router } = require('express');
const { body }   = require('express-validator');
const validate   = require('../middleware/validate');
const { requireInternalKey } = require('../middleware/internalAuth');
const ctrl = require('../controllers/internalController');

const router = Router();

const alertRules = [
  body('camera_id').isInt({ min: 1 }).withMessage('camera_id must be a positive integer.').toInt(),
  body('hazard').isString().matches(/^[a-z_]{1,32}$/).withMessage('hazard must be a lowercase code like "fire".'),
  body('confidence').optional().isFloat({ min: 0, max: 100 }).withMessage('confidence must be 0–1 or 0–100.').toFloat(),
];

router.post('/alerts', requireInternalKey, alertRules, validate, ctrl.raiseAlert);

module.exports = router;
