/**
 * routes/auth.js — /api/* and /auth/* (legacy alias) routes
 */

'use strict';

const { Router } = require('express');
const { body }   = require('express-validator');
const validate   = require('../middleware/validate');
const rateLimit  = require('../middleware/rateLimit');
const { requireAuth } = require('../middleware/auth');
const ctrl = require('../controllers/authController');

const router = Router();

// Slow down password guessing / bulk sign-ups from one address.
const envInt = (name, fallback) => {
  const n = parseInt(process.env[name] || '', 10);
  return Number.isNaN(n) ? fallback : n;
};
const loginLimiter    = rateLimit({ windowMs: 15 * 60_000, max: envInt('RATE_LIMIT_LOGIN_MAX', 20),    message: 'Too many login attempts. Try again in a few minutes.' });
const registerLimiter = rateLimit({ windowMs: 60 * 60_000, max: envInt('RATE_LIMIT_REGISTER_MAX', 20), message: 'Too many sign-ups from this address. Try again later.' });

const registerRules = [
  body('username').trim().notEmpty().withMessage('Username is required.')
    .isLength({ min: 3, max: 80 }).withMessage('Username must be 3–80 characters.'),
  body('email').trim().isEmail().withMessage('Valid email is required.')
    .isLength({ max: 255 }).withMessage('Email is too long.')
    .customSanitizer((v) => String(v).toLowerCase()),
  // bcrypt silently ignores everything after 72 bytes — cap it explicitly.
  body('password').isLength({ min: 6, max: 72 }).withMessage('Password must be 6–72 characters.'),
];

const loginRules = [
  body('username').trim().notEmpty().withMessage('Username is required.'),
  body('password').notEmpty().withMessage('Password is required.'),
];

router.post('/register', registerLimiter, registerRules, validate, ctrl.register);
router.post('/login',    loginLimiter,    loginRules,    validate, ctrl.login);
router.get('/me', requireAuth, ctrl.me);

module.exports = router;
