/**
 * routes/cameras.js — /cameras and /api/cameras routes
 */

'use strict';

const { Router } = require('express');
const { body }   = require('express-validator');
const validate   = require('../middleware/validate');
const { requireAuth } = require('../middleware/auth');
const ctrl = require('../controllers/camerasController');

const router = Router();

const ALLOWED_PROTOCOLS = ['rtsp:', 'rtsps:', 'rtmp:', 'http:', 'https:'];

function isValidStreamUrl(value) {
  try {
    return ALLOWED_PROTOCOLS.includes(new URL(value).protocol);
  } catch {
    return false;
  }
}

// Limits mirror the VARCHAR sizes in the schema (otherwise MySQL strict mode → 500).
const registerRules = [
  body('device_name').trim().notEmpty().withMessage('device_name is required.')
    .isLength({ max: 150 }).withMessage('device_name must be at most 150 characters.'),
  body('stream_url').trim().notEmpty().withMessage('stream_url is required.')
    .isLength({ max: 500 }).withMessage('stream_url must be at most 500 characters.')
    .custom(isValidStreamUrl).withMessage('stream_url must be a valid rtsp://, rtsps://, rtmp://, http:// or https:// URL.'),
  body('location_tag').trim().notEmpty().withMessage('location_tag is required.')
    .isLength({ max: 150 }).withMessage('location_tag must be at most 150 characters.'),
];

router.get('/',           requireAuth,                          ctrl.list);
router.post('/',          requireAuth, registerRules, validate, ctrl.register);
router.delete('/:id',     requireAuth,                          ctrl.remove);
router.put('/:id/status', requireAuth,                          ctrl.toggleStatus);

module.exports = router;
