/**
 * routes/incidents.js — /incidents and /api/incidents routes
 */

'use strict';

const { Router } = require('express');
const { requireAuth } = require('../middleware/auth');
const ctrl = require('../controllers/incidentsController');

const router = Router();

router.get('/',                requireAuth, ctrl.list);
router.post('/:id/cancel',     requireAuth, ctrl.cancel);
router.post('/:id/confirm',    requireAuth, ctrl.confirm);

// Test alert — also mounted at /api/alerts/test in server.js
router.post('/test',           requireAuth, ctrl.testAlert);

module.exports = router;
