/**
 * scripts/init-env.js — create backend-express/.env with strong random secrets.
 *
 *   npm run init-env
 *
 * Copies .env.example → .env (never overwrites an existing .env) and fills in
 * JWT_SECRET and INTERNAL_API_KEY with fresh 256-bit random values. You only
 * need to set DB_PASSWORD afterwards.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.join(__dirname, '..');
const target = path.join(root, '.env');
const example = path.join(root, '.env.example');

if (fs.existsSync(target)) {
  console.log('[init-env] .env already exists — leaving it untouched.');
  process.exit(0);
}

let text = fs.readFileSync(example, 'utf8');
const rand = () => crypto.randomBytes(32).toString('hex');
text = text
  .replace(/^JWT_SECRET=.*$/m, `JWT_SECRET=${rand()}`)
  .replace(/^INTERNAL_API_KEY=.*$/m, `INTERNAL_API_KEY=${rand()}`);

fs.writeFileSync(target, text, { mode: 0o600 });
console.log('[init-env] Created backend-express/.env with fresh random secrets.');
console.log('[init-env] Next: open it and set DB_PASSWORD to your MySQL password.');
