/**
 * middleware/rateLimit.js — tiny in-memory fixed-window rate limiter.
 *
 * Used on /login and /register to slow down password guessing. Single-process
 * only (fine for this deployment); swap for express-rate-limit + Redis if you
 * ever run multiple instances.
 */

'use strict';

function rateLimit({ windowMs, max, message }) {
  const hits = new Map();   // key -> { count, resetAt }

  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of hits) if (entry.resetAt <= now) hits.delete(key);
  }, Math.max(windowMs, 1000));
  if (sweep.unref) sweep.unref();

  return function limiter(req, res, next) {
    const key = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    let entry = hits.get(key);
    if (!entry || entry.resetAt <= now) {
      entry = { count: 0, resetAt: now + windowMs };
      hits.set(key, entry);
    }
    entry.count += 1;
    if (entry.count > max) {
      res.set('Retry-After', String(Math.ceil((entry.resetAt - now) / 1000)));
      return res.status(429).json({ detail: message || 'Too many requests. Try again later.' });
    }
    return next();
  };
}

module.exports = rateLimit;
