/**
 * middleware/validate.js — express-validator error aggregator
 *
 * Call this after a validation chain. If any rule fails, it returns a
 * structured 422 error listing every field problem.
 */

'use strict';

const { validationResult } = require('express-validator');

function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      detail: 'Validation failed.',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  return next();
}

module.exports = validate;
