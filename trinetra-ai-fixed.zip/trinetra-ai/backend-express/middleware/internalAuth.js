/**
 * middleware/internalAuth.js — server-to-server authentication
 *
 * The Python CV engine calls Express with the shared INTERNAL_API_KEY in the
 * `X-Internal-Key` header. Compared in constant time.
 */

'use strict';

const crypto = require('crypto');
const { INTERNAL_API_KEY } = require('../config/env');

function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function requireInternalKey(req, res, next) {
  if (!INTERNAL_API_KEY) {
    return res.status(503).json({
      detail: 'Internal API disabled: INTERNAL_API_KEY is not configured in backend-express/.env',
    });
  }
  const provided = req.headers['x-internal-key'];
  if (!provided || !safeEqual(provided, INTERNAL_API_KEY)) {
    return res.status(401).json({ detail: 'Invalid internal key.' });
  }
  return next();
}

module.exports = { requireInternalKey };
