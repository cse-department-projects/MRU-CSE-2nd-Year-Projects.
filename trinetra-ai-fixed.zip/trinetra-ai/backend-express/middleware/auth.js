/**
 * middleware/auth.js — JWT authentication middleware
 *
 * Validates the Bearer token in the Authorization header and attaches the
 * decoded payload to req.user. The signing secret comes from config/env.js,
 * which refuses to start without a strong JWT_SECRET (no insecure fallback).
 */

'use strict';

const jwt = require('jsonwebtoken');
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config/env');

/** Verify a raw JWT string. Throws on invalid / expired tokens. */
function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
}

function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      detail: 'Missing or malformed Authorization header. Expected: Bearer <token>',
    });
  }

  const token = authHeader.slice(7).trim();

  try {
    req.user = verifyToken(token);   // { sub: userId, username, email, iat, exp }
    return next();
  } catch (err) {
    const message =
      err.name === 'TokenExpiredError'
        ? 'Token has expired. Please log in again.'
        : 'Invalid token. Authentication failed.';
    return res.status(401).json({ detail: message });
  }
}

/** Generate a signed JWT for a user row. */
function signToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, email: user.email },
    JWT_SECRET,
    { algorithm: 'HS256', expiresIn: JWT_EXPIRES_IN }
  );
}

module.exports = { requireAuth, signToken, verifyToken };
