/**
 * config/env.js — Central, validated configuration.
 *
 * Loads .env, then validates secrets ONCE at startup. The server refuses to
 * start with a missing / weak JWT secret instead of silently falling back to
 * a well-known default (which would let anyone forge login tokens).
 *
 * Generate a fresh .env with strong random secrets:   npm run init-env
 */

'use strict';

require('dotenv').config();

const WEAK_MARKERS = ['change_me', 'changeme', 'your_secret', 'fallback', 'replace_in_production', 'secret123'];

function fail(message) {
  console.error('');
  console.error(`[Config] ❌  ${message}`);
  console.error('[Config]     Run  npm run init-env  inside backend-express/ to generate a safe .env');
  console.error('');
  process.exit(1);
}

function isWeak(value) {
  const v = String(value || '').toLowerCase();
  return v.length < 32 || WEAK_MARKERS.some((m) => v.includes(m));
}

const JWT_SECRET = process.env.JWT_SECRET || '';
if (isWeak(JWT_SECRET)) {
  fail('JWT_SECRET is missing, shorter than 32 characters, or still a placeholder.');
}

// Shared secret between Express and the Python CV engine (server-to-server only).
// Optional: without it the CV integration is disabled (everything else still works).
const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || '';
if (INTERNAL_API_KEY && isWeak(INTERNAL_API_KEY)) {
  fail('INTERNAL_API_KEY is set but weak (min 32 chars, no placeholder text).');
}

function intInRange(name, fallback, min, max) {
  const n = parseInt(process.env[name] || '', 10);
  if (Number.isNaN(n)) return fallback;
  return Math.min(Math.max(n, min), max);
}

module.exports = {
  JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  INTERNAL_API_KEY,
  CV_ENGINE_URL: (process.env.CV_ENGINE_URL || 'http://127.0.0.1:8001').replace(/\/+$/, ''),
  // Seconds the operator has to react before 112 is auto-dispatched.
  ALERT_TIMEOUT_SECONDS: intInRange('ALERT_TIMEOUT_SECONDS', 10, 3, 120),
  // Minimum gap between two automatic (CV-engine) incidents for the same camera.
  ALERT_COOLDOWN_SECONDS: intInRange('ALERT_COOLDOWN_SECONDS', 60, 0, 3600),
  IS_PROD: process.env.NODE_ENV === 'production',
};
