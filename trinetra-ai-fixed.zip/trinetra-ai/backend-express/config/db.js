/**
 * config/db.js — MySQL connection pool using mysql2/promise
 *
 * Automatically:
 *  - Connects to MySQL server
 *  - Creates the database `trinetra_ai` if it does not exist
 *  - Creates tables (users, cameras, incident_logs) if they do not exist
 *  - Initializes connection pool and exports it for the app
 */

'use strict';

require('dotenv').config();
const mysql = require('mysql2/promise');

const host     = process.env.DB_HOST     || 'localhost';
const port     = parseInt(process.env.DB_PORT || '3306', 10);
const user     = process.env.DB_USER     || 'root';
const password = process.env.DB_PASSWORD || '';
const database = process.env.DB_NAME     || 'trinetra_ai';

// ── Build pool configuration ──────────────────────────────────────────────────
const poolConfig = {
  host,
  port,
  user,
  password,
  database,
  connectionLimit:    parseInt(process.env.DB_POOL_LIMIT || '10', 10),
  waitForConnections: true,
  queueLimit:         0,
  enableKeepAlive:    true,
  keepAliveInitialDelay: 10000,
  dateStrings:        false,
  supportBigNumbers:  true,
  bigNumberStrings:   false,
  timezone:           '+00:00',
};

// Create the shared pool singleton
const pool = mysql.createPool(poolConfig);

// Force every pooled session to UTC. Without this, `DEFAULT CURRENT_TIMESTAMP`
// uses the MySQL server's local zone (e.g. IST) while the driver above reads
// DATETIME values as UTC, which shifts every timestamp by the zone offset.
pool.on('connection', (conn) => {
  conn.query("SET time_zone = '+00:00'", (err) => {
    if (err) console.error('[DB] Could not set session time_zone to UTC:', err.message);
  });
});

let isInitialized = false;

/**
 * Initializes database and tables if missing, then tests connection pool.
 * Executed strictly ONCE on startup.
 */
async function testConnection() {
  if (isInitialized) return;
  let rootConn;
  try {
    // 1. Connect without selecting database to ensure DB exists
    rootConn = await mysql.createConnection({ host, port, user, password });
    
    await rootConn.query(
      `CREATE DATABASE IF NOT EXISTS \`${database}\`
       CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    await rootConn.query(`USE \`${database}\``);

    // 2. Auto-create required tables if not present
    await rootConn.query(`
      CREATE TABLE IF NOT EXISTS users (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        username      VARCHAR(80)     NOT NULL,
        email         VARCHAR(255)    NOT NULL,
        password_hash VARCHAR(255)    NOT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_users_username (username),
        UNIQUE KEY uq_users_email    (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await rootConn.query(`
      CREATE TABLE IF NOT EXISTS cameras (
        id           INT UNSIGNED                   NOT NULL AUTO_INCREMENT,
        user_id      INT UNSIGNED                   NOT NULL,
        device_name  VARCHAR(150)                   NOT NULL,
        stream_url   VARCHAR(500)                   NOT NULL,
        location_tag VARCHAR(150)                   NOT NULL,
        status       ENUM('active','inactive')      NOT NULL DEFAULT 'active',
        created_at   DATETIME                       NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_cameras_user_id (user_id),
        CONSTRAINT fk_cameras_user
          FOREIGN KEY (user_id) REFERENCES users (id)
          ON DELETE CASCADE ON UPDATE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await rootConn.query(`
      CREATE TABLE IF NOT EXISTS incident_logs (
        id           INT UNSIGNED                                                              NOT NULL AUTO_INCREMENT,
        camera_id    INT UNSIGNED                                                              NOT NULL,
        hazard_type  VARCHAR(100)                                                              NOT NULL,
        status       ENUM('pending','dispatched','cancelled')                                  NOT NULL DEFAULT 'pending',
        triggered_at DATETIME                                                                  NOT NULL DEFAULT CURRENT_TIMESTAMP,
        action_taken ENUM('Pending','Auto-Called 112','User Confirmed & Called 112','User Dismissed')
                                                                                              NOT NULL DEFAULT 'Pending',
        location_tag VARCHAR(150)                                                              NOT NULL,
        confidence   VARCHAR(20)                                                               NOT NULL DEFAULT 'N/A',
        PRIMARY KEY (id),
        KEY idx_incidents_camera_id (camera_id),
        KEY idx_incidents_status    (status),
        KEY idx_incidents_triggered (triggered_at DESC),
        CONSTRAINT fk_incidents_camera
          FOREIGN KEY (camera_id) REFERENCES cameras (id)
          ON DELETE CASCADE ON UPDATE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await rootConn.end();
    rootConn = null;

    // 3. Test pool connection
    const conn = await pool.getConnection();
    const [[{ version }]] = await conn.query('SELECT VERSION() AS version');
    conn.release();

    isInitialized = true;

    console.log(`[DB] ✅  MySQL connected successfully`);
    console.log(`[DB]     Host     : ${poolConfig.host}:${poolConfig.port}`);
    console.log(`[DB]     Database : ${poolConfig.database}`);
    console.log(`[DB]     Version  : MySQL ${version}`);
    console.log(`[DB]     Pool     : ${poolConfig.connectionLimit} max connections`);
    console.log(`[DB]     Schema   : Tables (users, cameras, incident_logs) verified`);
  } catch (err) {
    console.error('[DB] ❌  MySQL connection FAILED');
    console.error(`[DB]     Host     : ${poolConfig.host}:${poolConfig.port}`);
    console.error(`[DB]     Database : ${poolConfig.database}`);
    console.error(`[DB]     Reason   : ${err.message}`);
    console.error('[DB]     Check that MySQL service is running and .env credentials are correct.');
    process.exit(1);
  } finally {
    if (rootConn) {
      try { await rootConn.end(); } catch (_) {}
    }
  }
}

module.exports = { pool, testConnection };
