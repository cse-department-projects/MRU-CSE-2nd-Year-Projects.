/**
 * server.js — Trinetra AI Express + MySQL Backend
 *
 * Entry point. Bootstraps Express, connects to MySQL, mounts the API routes and
 * the real-time WebSocket channel (/ws/alerts).
 *
 * Start:
 *   node server.js          (production)
 *   nodemon server.js       (development — auto-restart on file change)
 *
 * First run: `npm run init-env` creates .env with strong random secrets.
 */

'use strict';

// Load + validate configuration BEFORE anything else reads process.env.
const { IS_PROD } = require('./config/env');

const express = require('express');
const cors    = require('cors');
const morgan  = require('morgan');
const http    = require('http');
const { WebSocketServer } = require('ws');
const { pool, testConnection } = require('./config/db');

const authRoutes      = require('./routes/auth');
const camerasRoutes   = require('./routes/cameras');
const incidentsRoutes = require('./routes/incidents');
const internalRoutes  = require('./routes/internal');
const { requireAuth, verifyToken } = require('./middleware/auth');
const incidentsCtrl   = require('./controllers/incidentsController');
const realtime        = require('./services/realtime');
const cvEngine        = require('./services/cvEngine');

const app = express();
app.disable('x-powered-by');

// ── Basic security headers ────────────────────────────────────────────────────
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options':        'DENY',
    'Referrer-Policy':        'no-referrer',
  });
  next();
});

// ── CORS ──────────────────────────────────────────────────────────────────────
// Browsers enforce this. Requests from the Vite dev proxy are same-origin from
// the browser's point of view, so a LAN demo works without extra config; list
// extra origins in CORS_ORIGINS (comma separated) if you call the API directly.
const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: (origin, callback) => callback(null, !origin || allowedOrigins.includes(origin)),
  credentials:    true,
  allowedHeaders: ['Content-Type', 'Authorization'],
  methods:        ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(IS_PROD ? 'combined' : 'dev'));
}

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api',  authRoutes);       // POST /api/register  POST /api/login  GET /api/me
app.use('/auth', authRoutes);       // legacy alias

app.use('/cameras',     camerasRoutes);
app.use('/api/cameras', camerasRoutes);

app.use('/incidents',     incidentsRoutes);
app.use('/api/incidents', incidentsRoutes);

app.use('/api/internal', internalRoutes);   // CV engine → Express (X-Internal-Key)

// Manual test alert (dev only — blocked when NODE_ENV=production)
app.post('/api/alerts/test',    requireAuth, incidentsCtrl.testAlert);
app.post('/test/trigger-alert', requireAuth, incidentsCtrl.testAlert);

app.get('/health', (req, res) => {
  res.json({
    status:    'operational',
    timestamp: new Date().toISOString(),
    engine:    'Trinetra AI Express + MySQL v2.1',
    database:  'MySQL (mysql2/promise pool)',
  });
});

app.use((req, res) => {
  res.status(404).json({ detail: `Route not found: ${req.method} ${req.path}` });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  console.error('[Server] Unhandled error:', err);
  res.status(500).json({ detail: 'Internal server error.' });
});

// ─────────────────────────────────────────────────────────────────────────────
// WebSocket — real-time alert push (/ws/alerts?token=<JWT>)
// ─────────────────────────────────────────────────────────────────────────────

const server = http.createServer(app);
const wss    = new WebSocketServer({ server, path: '/ws/alerts', maxPayload: 4096 });

wss.on('connection', async (ws, req) => {
  const url   = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const token = url.searchParams.get('token');

  let userId;
  try {
    userId = verifyToken(token).sub;
  } catch {
    ws.close(4001, 'Invalid or missing token');
    return;
  }

  const count = realtime.addClient(userId, ws);
  console.log(`[WS] User #${userId} connected. Active sockets: ${count}`);

  ws.send(JSON.stringify({
    event:   'CONNECTED',
    message: 'Sentinel grid active.',
    user_id: userId,
  }));

  // A refreshed / reconnected dashboard must still see an alert that is mid-countdown.
  realtime.replayActiveAlerts(userId, ws);

  const sendHeartbeat = async () => {
    if (ws.readyState !== ws.OPEN) return;
    ws.send(JSON.stringify({
      event:           'HEARTBEAT',
      active_scanners: await realtime.activeScannerCount(userId),
      timestamp:       new Date().toISOString(),
    }));
  };
  sendHeartbeat();
  const hb = setInterval(sendHeartbeat, 25_000);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);
      if (msg.type === 'ping') ws.send(JSON.stringify({ event: 'PONG' }));
    } catch { /* ignore malformed messages */ }
  });

  ws.on('close', () => {
    clearInterval(hb);
    realtime.removeClient(userId, ws);
    console.log(`[WS] User #${userId} disconnected.`);
  });

  ws.on('error', (err) => console.error('[WS] socket error:', err.message));
});

// ─────────────────────────────────────────────────────────────────────────────
// Startup — test DB first, then bind the HTTP server
// ─────────────────────────────────────────────────────────────────────────────

async function start() {
  const PORT = parseInt(process.env.PORT || '8000', 10);
  const HOST = process.env.HOST || '0.0.0.0';

  await testConnection();   // exits with a clear message if MySQL is unreachable

  server.listen(PORT, HOST, () => {
    console.log('');
    console.log('[Server] ✅  Trinetra AI Express Backend running');
    console.log(`[Server]     HTTP  : http://${HOST}:${PORT}`);
    console.log(`[Server]     WS    : ws://${HOST}:${PORT}/ws/alerts`);
    console.log(`[Server]     Env   : ${process.env.NODE_ENV || 'development'}`);
    console.log('');
  });

  cvEngine.startSyncLoop(pool);
}

if (require.main === module) {
  start();
}

module.exports = { app, server, wss, start };
