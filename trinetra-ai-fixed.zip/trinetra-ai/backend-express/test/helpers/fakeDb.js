/**
 * test/helpers/fakeDb.js — tiny in-memory stand-in for the mysql2 pool.
 *
 * Lets the test-suite run the REAL controllers / services / WebSocket code
 * without a MySQL server. It understands exactly the statements the app issues;
 * an unknown statement throws so a new query can't silently go untested.
 */

'use strict';

const norm = (sql) => sql.replace(/\s+/g, ' ').trim();

class FakePool {
  constructor() { this.reset(); }

  reset() {
    this.users = [];
    this.cameras = [];
    this.incidents = [];
    this.seq = { users: 0, cameras: 0, incidents: 0 };
  }

  async query(rawSql, params = []) {
    const sql = norm(rawSql);
    const p = params;

    // ── users ──────────────────────────────────────────────────────────────
    if (sql === 'SELECT id FROM users WHERE username = ? LIMIT 1')
      return [this.users.filter((u) => u.username === p[0]).map((u) => ({ id: u.id }))];
    if (sql === 'SELECT id FROM users WHERE email = ? LIMIT 1')
      return [this.users.filter((u) => u.email === p[0]).map((u) => ({ id: u.id }))];
    if (sql.startsWith('INSERT INTO users')) {
      const id = ++this.seq.users;
      this.users.push({ id, username: p[0], email: p[1], password_hash: p[2], created_at: new Date() });
      return [{ insertId: id, affectedRows: 1 }];
    }
    if (sql.startsWith('SELECT id, username, email, password_hash, created_at FROM users WHERE username'))
      return [this.users.filter((u) => u.username === p[0])];
    if (sql.startsWith('SELECT id, username, email, created_at FROM users WHERE id'))
      return [this.users.filter((u) => u.id === Number(p[0])).map(({ password_hash, ...rest }) => rest)];

    // ── cameras ────────────────────────────────────────────────────────────
    if (sql.startsWith('INSERT INTO cameras')) {
      const id = ++this.seq.cameras;
      this.cameras.push({ id, user_id: p[0], device_name: p[1], stream_url: p[2], location_tag: p[3], status: 'active', created_at: new Date() });
      return [{ insertId: id, affectedRows: 1 }];
    }
    if (sql.startsWith('SELECT id, user_id, device_name, stream_url, location_tag, status, created_at FROM cameras WHERE user_id'))
      return [this.cameras.filter((c) => c.user_id === p[0])];
    if (sql.startsWith('SELECT id, user_id, device_name, stream_url, location_tag, status, created_at FROM cameras WHERE id'))
      return [this.cameras.filter((c) => c.id === Number(p[0]))];
    if (sql === 'SELECT id FROM cameras WHERE id = ? AND user_id = ? LIMIT 1')
      return [this.cameras.filter((c) => c.id === p[0] && c.user_id === p[1]).map((c) => ({ id: c.id }))];
    if (sql === 'SELECT id, status FROM cameras WHERE id = ? AND user_id = ? LIMIT 1')
      return [this.cameras.filter((c) => c.id === p[0] && c.user_id === p[1]).map((c) => ({ id: c.id, status: c.status }))];
    if (sql === 'UPDATE cameras SET status = ? WHERE id = ?') {
      const c = this.cameras.find((x) => x.id === p[1]); if (c) c.status = p[0];
      return [{ affectedRows: c ? 1 : 0 }];
    }
    if (sql === 'DELETE FROM cameras WHERE id = ?') {
      this.cameras = this.cameras.filter((c) => c.id !== p[0]);
      this.incidents = this.incidents.filter((i) => i.camera_id !== p[0]);   // ON DELETE CASCADE
      return [{ affectedRows: 1 }];
    }
    if (sql.startsWith('SELECT id, user_id, device_name, location_tag FROM cameras WHERE user_id = ?')) {
      return [this.cameras.filter((c) => c.user_id === p[0] && c.status === 'active').sort((a, b) => a.id - b.id).slice(0, 1)];
    }
    if (sql.startsWith('SELECT id, user_id, device_name, location_tag, status FROM cameras WHERE id'))
      return [this.cameras.filter((c) => c.id === Number(p[0])).slice(0, 1)];
    if (sql.startsWith('SELECT COUNT(*) AS n FROM cameras'))
      return [[{ n: this.cameras.filter((c) => c.user_id === p[0] && c.status === 'active').length }]];
    if (sql === "SELECT id, stream_url FROM cameras WHERE status = 'active'")
      return [this.cameras.filter((c) => c.status === 'active').map((c) => ({ id: c.id, stream_url: c.stream_url }))];

    // ── incidents ──────────────────────────────────────────────────────────
    if (sql.startsWith('INSERT INTO incident_logs')) {
      const id = ++this.seq.incidents;
      this.incidents.push({
        id, camera_id: p[0], hazard_type: p[1], status: 'pending', triggered_at: new Date(),
        action_taken: 'Pending', location_tag: p[2], confidence: p[3],
      });
      return [{ insertId: id, affectedRows: 1 }];
    }
    if (sql.startsWith('SELECT 1 FROM incident_logs WHERE camera_id = ? AND triggered_at >')) {
      const cutoff = Date.now() - p[1] * 1000;
      return [this.incidents.filter((i) => i.camera_id === p[0] && i.triggered_at.getTime() > cutoff).map(() => ({ 1: 1 }))];
    }
    if (sql === "SELECT id FROM incident_logs WHERE camera_id = ? AND status = 'pending'")
      return [this.incidents.filter((i) => i.camera_id === p[0] && i.status === 'pending').map((i) => ({ id: i.id }))];
    if (sql.startsWith('SELECT il.id, il.status, il.hazard_type, il.location_tag FROM incident_logs il')) {
      const rows = this.incidents.filter((i) => {
        const cam = this.cameras.find((c) => c.id === i.camera_id);
        return i.id === p[0] && cam && cam.user_id === p[1];
      });
      return [rows];
    }
    if (sql === 'UPDATE incident_logs SET status = ?, action_taken = ? WHERE id = ? AND status = \'pending\'') {
      const i = this.incidents.find((x) => x.id === p[2] && x.status === 'pending');
      if (i) { i.status = p[0]; i.action_taken = p[1]; }
      return [{ affectedRows: i ? 1 : 0 }];
    }
    if (sql === "UPDATE incident_logs SET status = 'dispatched', action_taken = 'Auto-Called 112' WHERE id = ? AND status = 'pending'") {
      const i = this.incidents.find((x) => x.id === p[0] && x.status === 'pending');
      if (i) { i.status = 'dispatched'; i.action_taken = 'Auto-Called 112'; }
      return [{ affectedRows: i ? 1 : 0 }];
    }
    if (sql.startsWith('SELECT il.id, il.camera_id, il.hazard_type')) {
      const rows = this.incidents.filter((i) => this.cameras.find((c) => c.id === i.camera_id)?.user_id === p[0]);
      return [rows];
    }

    throw new Error(`FakePool: unhandled SQL → ${sql}`);
  }
}

function installFakeDb() {
  const dbPath = require.resolve('../../config/db');
  const pool = new FakePool();
  require.cache[dbPath] = {
    id: dbPath, filename: dbPath, loaded: true,
    exports: { pool, testConnection: async () => {} },
  };
  return pool;
}

/** bcrypt is a native module; a trivial stand-in keeps the suite fast and portable. */
function installFakeBcrypt() {
  const id = require.resolve('bcrypt');
  require.cache[id] = {
    id, filename: id, loaded: true,
    exports: {
      hash: async (pw) => `fake$${pw}`,
      compare: async (pw, hash) => hash === `fake$${pw}`,
    },
  };
}

module.exports = { installFakeDb, installFakeBcrypt, FakePool };
