/**
 * test/realtime.test.js — end-to-end tests for the alert → countdown → dispatch flow.
 *
 * Runs the real Express app + WebSocket server against an in-memory fake DB and
 * a mock CV engine. No MySQL / network needed:   npm test
 */

'use strict';

// ── Test configuration (must be set BEFORE the app is required) ──────────────
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'a'.repeat(64);
process.env.INTERNAL_API_KEY = 'b'.repeat(64);
process.env.ALERT_TIMEOUT_SECONDS = '3';
process.env.ALERT_COOLDOWN_SECONDS = '60';
process.env.RATE_LIMIT_REGISTER_MAX = '1000';   // the suite creates many users from one IP
const CV_PORT = 18991;
process.env.CV_ENGINE_URL = `http://127.0.0.1:${CV_PORT}`;

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { installFakeDb, installFakeBcrypt } = require('./helpers/fakeDb');

const db = installFakeDb();
installFakeBcrypt();

const WebSocket = require('ws');
const { server } = require('../server');
const realtime = require('../services/realtime');

let base;
let wsBase;
const cvCalls = [];
let cvServer;

// ── helpers ───────────────────────────────────────────────────────────────────
async function api(method, path, { token, body, headers } = {}) {
  const res = await fetch(base + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* 204 */ }
  return { status: res.status, data };
}

async function register(username) {
  const r = await api('POST', '/api/register', {
    body: { username, email: `${username}@example.com`, password: 'secret123' },
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return { token: r.data.access_token, id: r.data.user.id };
}

function connectWs(token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`${wsBase}/ws/alerts?token=${encodeURIComponent(token)}`);
    ws.messages = [];
    ws.on('message', (d) => ws.messages.push(JSON.parse(d.toString())));
    ws.on('open', () => resolve(ws));
    ws.on('error', reject);
  });
}

async function waitFor(ws, predicate, timeoutMs = 6000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const hit = ws.messages.find(predicate);
    if (hit) return hit;
    await new Promise((r) => setTimeout(r, 25));
  }
  throw new Error(`timeout waiting for message; got: ${JSON.stringify(ws.messages.map((m) => m.event))}`);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function addCamera(token, name = 'Cam') {
  const r = await api('POST', '/api/cameras', {
    token,
    body: { device_name: name, stream_url: 'rtsp://admin:pw@192.168.1.10:554/stream1', location_tag: 'Lobby' },
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data;
}

// ── setup / teardown ──────────────────────────────────────────────────────────
test.before(async () => {
  cvServer = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      cvCalls.push({ method: req.method, url: req.url, key: req.headers['x-internal-key'], body: raw ? JSON.parse(raw) : null });
      res.statusCode = req.method === 'POST' ? 201 : 204;
      res.setHeader('Content-Type', 'application/json');
      res.end(req.method === 'POST' ? '{"status":"starting"}' : '');
    });
  });
  await new Promise((r) => cvServer.listen(CV_PORT, '127.0.0.1', r));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const { port } = server.address();
  base = `http://127.0.0.1:${port}`;
  wsBase = `ws://127.0.0.1:${port}`;
});

test.after(async () => {
  realtime.stopAllTimers();
  server.closeAllConnections?.();
  await new Promise((r) => server.close(r));
  await new Promise((r) => cvServer.close(r));
});

// ── tests ─────────────────────────────────────────────────────────────────────
test('protected routes reject missing / forged tokens', async () => {
  assert.equal((await api('GET', '/api/incidents')).status, 401);
  assert.equal((await api('GET', '/api/incidents', { token: 'not.a.jwt' })).status, 401);
});

test('register validates input and rejects duplicates cleanly', async () => {
  const weak = await api('POST', '/api/register', { body: { username: 'bob', email: 'bob@example.com', password: '123' } });
  assert.equal(weak.status, 422);
  const tooLong = await api('POST', '/api/register', { body: { username: 'bob', email: 'bob@example.com', password: 'x'.repeat(73) } });
  assert.equal(tooLong.status, 422);

  await register('dupuser');
  const dup = await api('POST', '/api/register', { body: { username: 'dupuser', email: 'other@example.com', password: 'secret123' } });
  assert.equal(dup.status, 400);
  assert.match(dup.data.detail, /Username already registered/);
});

test('camera validation rejects bad URLs and over-long fields', async () => {
  const { token } = await register('camval');
  const bad = await api('POST', '/api/cameras', { token, body: { device_name: 'x', stream_url: 'file:///etc/passwd', location_tag: 'y' } });
  assert.equal(bad.status, 422);
  const junk = await api('POST', '/api/cameras', { token, body: { device_name: 'x', stream_url: 'not a url', location_tag: 'y' } });
  assert.equal(junk.status, 422);
  const long = await api('POST', '/api/cameras', { token, body: { device_name: 'x'.repeat(151), stream_url: 'rtsp://h/s', location_tag: 'y' } });
  assert.equal(long.status, 422);
});

test('WebSocket rejects bad tokens with close code 4001', async () => {
  const code = await new Promise((resolve) => {
    const ws = new WebSocket(`${wsBase}/ws/alerts?token=garbage`);
    ws.on('close', (c) => resolve(c));
    ws.on('error', () => {});
  });
  assert.equal(code, 4001);
});

test('registering a camera tells the CV engine (with the shared key) and notifies the dashboard', async () => {
  const { token } = await register('camuser');
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');
  cvCalls.length = 0;

  const cam = await addCamera(token, 'Front Door');

  const init = await waitFor(ws, (m) => m.event === 'CAMERA_INIT');
  assert.equal(init.camera_id, cam.id);
  await waitFor(ws, (m) => m.event === 'CAMERA_READY');

  const call = cvCalls.find((c) => c.method === 'POST' && c.url === '/api/cameras');
  assert.ok(call, 'CV engine should have received POST /api/cameras');
  assert.equal(call.key, 'b'.repeat(64));
  assert.equal(call.body.camera_id, cam.id);
  assert.match(call.body.stream_url, /^rtsp:\/\//);

  // Dashboard's "active scanners" counter refreshes immediately (not after 25 s).
  await waitFor(ws, (m) => m.event === 'HEARTBEAT' && m.active_scanners === 1);
  ws.close();
});

test('Test Alert → popup event + countdown ticks → server auto-dispatches 112', async () => {
  const { token } = await register('autouser');
  await addCamera(token);
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');

  const r = await api('POST', '/api/alerts/test', { token });
  assert.equal(r.status, 200);

  const alert = await waitFor(ws, (m) => m.event === 'HAZARD_ALERT');
  assert.equal(alert.incident_id, r.data.incident_id);
  assert.equal(alert.device_name, 'Cam');
  assert.equal(alert.location_tag, 'Lobby');
  assert.equal(alert.timeout_seconds, 3);
  assert.match(alert.confidence, /^\d+\.\d%$/);

  const done = await waitFor(ws, (m) => m.event === 'DISPATCH_CONFIRMED', 8000);
  assert.equal(done.incident_id, alert.incident_id);

  const ticks = ws.messages.filter((m) => m.event === 'TIMER_TICK').map((m) => m.countdown);
  assert.deepEqual(ticks, [3, 2, 1]);

  const row = db.incidents.find((i) => i.id === alert.incident_id);
  assert.equal(row.status, 'dispatched');
  assert.equal(row.action_taken, 'Auto-Called 112');

  // Operator reacts too late → rejected, state untouched.
  const late = await api('POST', `/incidents/${alert.incident_id}/cancel`, { token });
  assert.equal(late.status, 400);
  assert.equal(db.incidents.find((i) => i.id === alert.incident_id).status, 'dispatched');
  ws.close();
});

test('operator cancel stops the countdown (no auto-dispatch later)', async () => {
  const { token } = await register('canceluser');
  await addCamera(token);
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');

  await api('POST', '/api/alerts/test', { token });
  const alert = await waitFor(ws, (m) => m.event === 'HAZARD_ALERT');

  const c = await api('POST', `/incidents/${alert.incident_id}/cancel`, { token });
  assert.equal(c.status, 200);
  const upd = await waitFor(ws, (m) => m.event === 'INCIDENT_UPDATED');
  assert.equal(upd.status, 'cancelled');

  await sleep(4000);   // > ALERT_TIMEOUT_SECONDS
  assert.ok(!ws.messages.some((m) => m.event === 'DISPATCH_CONFIRMED'), 'must not auto-dispatch after cancel');
  const row = db.incidents.find((i) => i.id === alert.incident_id);
  assert.equal(row.status, 'cancelled');
  assert.equal(row.action_taken, 'User Dismissed');
  assert.equal(realtime.activeTimerCount(), 0);
  ws.close();
});

test('operator confirm dispatches immediately and stops the timer', async () => {
  const { token } = await register('confirmuser');
  await addCamera(token);
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');

  await api('POST', '/api/alerts/test', { token });
  const alert = await waitFor(ws, (m) => m.event === 'HAZARD_ALERT');
  const c = await api('POST', `/incidents/${alert.incident_id}/confirm`, { token });
  assert.equal(c.status, 200);

  await sleep(3800);
  assert.ok(!ws.messages.some((m) => m.event === 'DISPATCH_CONFIRMED'), 'no second (auto) dispatch');
  const row = db.incidents.find((i) => i.id === alert.incident_id);
  assert.equal(row.status, 'dispatched');
  assert.equal(row.action_taken, 'User Confirmed & Called 112');

  const again = await api('POST', `/incidents/${alert.incident_id}/confirm`, { token });
  assert.equal(again.status, 400);
  ws.close();
});

test('a reloaded dashboard gets the in-progress alert replayed', async () => {
  const { token } = await register('replayuser');
  await addCamera(token);
  const ws1 = await connectWs(token);
  await waitFor(ws1, (m) => m.event === 'CONNECTED');
  await api('POST', '/api/alerts/test', { token });
  const alert = await waitFor(ws1, (m) => m.event === 'HAZARD_ALERT');
  ws1.close();                                   // user refreshes the page…
  await sleep(200);

  const ws2 = await connectWs(token);            // …and reconnects mid-countdown
  const replay = await waitFor(ws2, (m) => m.event === 'HAZARD_ALERT');
  assert.equal(replay.incident_id, alert.incident_id);
  await waitFor(ws2, (m) => m.event === 'TIMER_TICK');
  await waitFor(ws2, (m) => m.event === 'DISPATCH_CONFIRMED', 8000);   // timer kept running server-side
  ws2.close();
});

test('users are isolated: no cross-user alerts, no cross-user actions', async () => {
  const a = await register('isoA');
  const b = await register('isoB');
  await addCamera(a.token, 'A-cam');
  const wsA = await connectWs(a.token);
  const wsB = await connectWs(b.token);
  await waitFor(wsA, (m) => m.event === 'CONNECTED');
  await waitFor(wsB, (m) => m.event === 'CONNECTED');

  await api('POST', '/api/alerts/test', { token: a.token });
  const alert = await waitFor(wsA, (m) => m.event === 'HAZARD_ALERT');
  await sleep(300);
  assert.ok(!wsB.messages.some((m) => m.event === 'HAZARD_ALERT'), 'B must not see A\'s alert');

  const hijack = await api('POST', `/incidents/${alert.incident_id}/confirm`, { token: b.token });
  assert.equal(hijack.status, 404);
  const list = await api('GET', '/incidents', { token: b.token });
  assert.deepEqual(list.data, []);
  await api('POST', `/incidents/${alert.incident_id}/cancel`, { token: a.token });
  wsA.close(); wsB.close();
});

test('CV engine alerts: key required, validated, cooldown-limited', async () => {
  const { token } = await register('cvuser');
  const cam = await addCamera(token, 'Garage');
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');

  const noKey = await api('POST', '/api/internal/alerts', { body: { camera_id: cam.id, hazard: 'fire', confidence: 0.9 } });
  assert.equal(noKey.status, 401);
  const badKey = await api('POST', '/api/internal/alerts', { headers: { 'X-Internal-Key': 'x'.repeat(64) }, body: { camera_id: cam.id, hazard: 'fire' } });
  assert.equal(badKey.status, 401);

  const key = { 'X-Internal-Key': 'b'.repeat(64) };
  const badHazard = await api('POST', '/api/internal/alerts', { headers: key, body: { camera_id: cam.id, hazard: 'Fire!!' } });
  assert.equal(badHazard.status, 422);
  const ghost = await api('POST', '/api/internal/alerts', { headers: key, body: { camera_id: 99999, hazard: 'fire' } });
  assert.equal(ghost.status, 404);

  const ok = await api('POST', '/api/internal/alerts', { headers: key, body: { camera_id: cam.id, hazard: 'fire', confidence: 0.931 } });
  assert.equal(ok.status, 201);
  const alert = await waitFor(ws, (m) => m.event === 'HAZARD_ALERT');
  assert.equal(alert.hazard_type, '🔥 Fire Detected');
  assert.equal(alert.confidence, '93.1%');
  assert.equal(alert.device_name, 'Garage');

  const again = await api('POST', '/api/internal/alerts', { headers: key, body: { camera_id: cam.id, hazard: 'fire', confidence: 0.95 } });
  assert.equal(again.status, 202);
  assert.equal(again.data.suppressed, 'cooldown');
  assert.equal(db.incidents.filter((i) => i.camera_id === cam.id).length, 1, 'flood must collapse to one incident');

  await api('POST', `/incidents/${alert.incident_id}/cancel`, { token });
  ws.close();
});

test('deleting a camera cancels its pending countdown and stops the CV stream', async () => {
  const { token } = await register('deluser');
  const cam = await addCamera(token);
  const ws = await connectWs(token);
  await waitFor(ws, (m) => m.event === 'CONNECTED');
  await api('POST', '/api/alerts/test', { token });
  await waitFor(ws, (m) => m.event === 'HAZARD_ALERT');
  cvCalls.length = 0;

  const del = await api('DELETE', `/cameras/${cam.id}`, { token });
  assert.equal(del.status, 204);
  await sleep(4000);
  assert.ok(!ws.messages.some((m) => m.event === 'DISPATCH_CONFIRMED'), 'timer must die with the camera');
  assert.ok(cvCalls.some((c) => c.method === 'DELETE' && c.url === `/api/cameras/${cam.id}`));
  assert.equal(realtime.activeTimerCount(), 0);
  ws.close();
});

test('login is rate-limited (brute-force guard)', async () => {
  await register('ratelimited');
  let last;
  for (let i = 0; i < 25; i += 1) {
    last = await api('POST', '/api/login', { body: { username: 'ratelimited', password: 'wrong' } });
  }
  assert.equal(last.status, 429);
});
