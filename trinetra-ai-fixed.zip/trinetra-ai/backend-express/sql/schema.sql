-- =====================================================================
-- Trinetra AI — MySQL Schema
-- Run this file once to initialize the database:
--   mysql -u root -p < schema.sql
-- =====================================================================

-- Create and select the database
CREATE DATABASE IF NOT EXISTS trinetra_ai
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE trinetra_ai;

-- ── users ─────────────────────────────────────────────────────────────
-- Stores all registered operators / admins
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  username      VARCHAR(80)     NOT NULL,
  email         VARCHAR(255)    NOT NULL,
  password_hash VARCHAR(255)    NOT NULL,
  created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_email    (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── cameras ───────────────────────────────────────────────────────────
-- Each row is a camera registered by a user
CREATE TABLE IF NOT EXISTS cameras (
  id           INT UNSIGNED                   NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED                   NOT NULL,
  device_name  VARCHAR(150)                   NOT NULL,
  stream_url   VARCHAR(500)                   NOT NULL,
  location_tag VARCHAR(150)                   NOT NULL,
  status       ENUM('active','inactive')      NOT NULL DEFAULT 'active',
  created_at   DATETIME                       NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_cameras_user_id (user_id),
  CONSTRAINT fk_cameras_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── incident_logs ─────────────────────────────────────────────────────
-- Every hazard detection event raised by the CV engine or test trigger
CREATE TABLE IF NOT EXISTS incident_logs (
  id           INT UNSIGNED                                                              NOT NULL AUTO_INCREMENT,
  camera_id    INT UNSIGNED                                                              NOT NULL,
  hazard_type  VARCHAR(100)                                                              NOT NULL,
  status       ENUM('pending','dispatched','cancelled')                                  NOT NULL DEFAULT 'pending',
  triggered_at DATETIME                                                                  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  action_taken ENUM('Pending','Auto-Called 112','User Confirmed & Called 112','User Dismissed')
                                                                                        NOT NULL DEFAULT 'Pending',
  location_tag VARCHAR(150)                                                              NOT NULL,
  confidence   VARCHAR(20)                                                               NOT NULL DEFAULT 'N/A',

  PRIMARY KEY (id),
  KEY idx_incidents_camera_id (camera_id),
  KEY idx_incidents_status    (status),
  KEY idx_incidents_triggered (triggered_at DESC),
  CONSTRAINT fk_incidents_camera
    FOREIGN KEY (camera_id) REFERENCES cameras (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
